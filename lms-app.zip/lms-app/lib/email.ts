// lib/email.ts
import nodemailer from 'nodemailer';

const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST || 'smtp.resend.com',
  port: parseInt(process.env.EMAIL_PORT || '465'),
  secure: true,
  auth: {
    user: process.env.EMAIL_USER || 'resend',
    pass: process.env.EMAIL_PASSWORD || '',
  },
});

const FROM = `LearnForge <${process.env.EMAIL_FROM || 'noreply@learnforge.com'}>`;
const BASE_URL = process.env.NEXT_PUBLIC_URL || 'https://learnforge.com';

export async function sendVerificationEmail(email: string, name: string, token: string) {
  const verifyUrl = `${BASE_URL}/auth/verify-email?token=${token}`;
  await transporter.sendMail({
    from: FROM,
    to: email,
    subject: 'Verify your LearnForge account',
    html: `
      <div style="font-family: system-ui, sans-serif; max-width: 480px; margin: 0 auto; padding: 40px 20px;">
        <div style="text-align: center; margin-bottom: 32px;">
          <div style="background: #22c55e; width: 48px; height: 48px; border-radius: 12px; display: inline-flex; align-items: center; justify-content: center; margin-bottom: 12px;">
            <span style="color: white; font-weight: bold; font-size: 20px;">LF</span>
          </div>
          <h1 style="margin: 0; font-size: 24px; font-weight: 700;">Welcome to LearnForge!</h1>
        </div>
        <p style="color: #6b7280; margin-bottom: 24px;">Hi ${name}, please verify your email address to get started.</p>
        <a href="${verifyUrl}"
           style="display: block; background: #22c55e; color: white; text-align: center; padding: 14px 24px; border-radius: 12px; text-decoration: none; font-weight: 600; margin-bottom: 24px;">
          Verify Email Address
        </a>
        <p style="color: #9ca3af; font-size: 13px;">This link expires in 24 hours. If you didn't create an account, you can ignore this email.</p>
      </div>
    `,
  });
}

export async function sendPasswordResetEmail(email: string, name: string, token: string) {
  const resetUrl = `${BASE_URL}/auth/reset-password?token=${token}`;
  await transporter.sendMail({
    from: FROM,
    to: email,
    subject: 'Reset your LearnForge password',
    html: `
      <div style="font-family: system-ui, sans-serif; max-width: 480px; margin: 0 auto; padding: 40px 20px;">
        <h1 style="font-size: 22px; font-weight: 700; margin-bottom: 8px;">Reset your password</h1>
        <p style="color: #6b7280; margin-bottom: 24px;">Hi ${name}, click below to reset your password. This link expires in 1 hour.</p>
        <a href="${resetUrl}"
           style="display: block; background: #22c55e; color: white; text-align: center; padding: 14px 24px; border-radius: 12px; text-decoration: none; font-weight: 600; margin-bottom: 24px;">
          Reset Password
        </a>
        <p style="color: #9ca3af; font-size: 13px;">If you didn't request a password reset, please ignore this email.</p>
      </div>
    `,
  });
}

export async function sendCertificateEmail(
  email: string,
  name: string,
  courseTitle: string,
  verificationId: string,
  pdfUrl?: string
) {
  const verifyUrl = `${BASE_URL}/certificates/verify/${verificationId}`;
  await transporter.sendMail({
    from: FROM,
    to: email,
    subject: `🎉 Your certificate for "${courseTitle}" is ready!`,
    html: `
      <div style="font-family: system-ui, sans-serif; max-width: 480px; margin: 0 auto; padding: 40px 20px;">
        <h1 style="font-size: 22px; font-weight: 700; margin-bottom: 8px;">Congratulations, ${name}! 🎓</h1>
        <p style="color: #6b7280; margin-bottom: 16px;">You've successfully completed <strong>${courseTitle}</strong>. Your verified certificate is ready!</p>
        <a href="${verifyUrl}"
           style="display: block; background: #22c55e; color: white; text-align: center; padding: 14px 24px; border-radius: 12px; text-decoration: none; font-weight: 600; margin-bottom: 16px;">
          View Certificate
        </a>
        ${pdfUrl ? `<a href="${pdfUrl}" style="display: block; border: 1px solid #e5e7eb; color: #374151; text-align: center; padding: 14px 24px; border-radius: 12px; text-decoration: none; font-weight: 600; margin-bottom: 24px;">Download PDF</a>` : ''}
        <p style="color: #9ca3af; font-size: 13px;">Verification ID: ${verificationId}</p>
      </div>
    `,
    ...(pdfUrl ? {
      attachments: [{ filename: `certificate-${verificationId}.pdf`, path: pdfUrl }],
    } : {}),
  });
}

export async function sendDeadlineReminder(
  email: string,
  name: string,
  assignmentTitle: string,
  courseTitle: string,
  dueDate: Date
) {
  const { format } = await import('date-fns');
  await transporter.sendMail({
    from: FROM,
    to: email,
    subject: `⏰ Reminder: "${assignmentTitle}" is due soon`,
    html: `
      <div style="font-family: system-ui, sans-serif; max-width: 480px; margin: 0 auto; padding: 40px 20px;">
        <h1 style="font-size: 22px; font-weight: 700; margin-bottom: 8px;">Upcoming deadline</h1>
        <p style="color: #6b7280;">Hi ${name}, your assignment <strong>${assignmentTitle}</strong> in <strong>${courseTitle}</strong> is due on <strong>${format(dueDate, 'MMMM d, yyyy')}</strong>.</p>
        <a href="${BASE_URL}/dashboard/my-courses"
           style="display: block; background: #22c55e; color: white; text-align: center; padding: 14px 24px; border-radius: 12px; text-decoration: none; font-weight: 600; margin-top: 24px;">
          Submit Assignment
        </a>
      </div>
    `,
  });
}
