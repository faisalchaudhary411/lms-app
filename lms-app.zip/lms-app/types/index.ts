// ============================================================
// CORE TYPES
// ============================================================

export type UserRole = 'STUDENT' | 'INSTRUCTOR' | 'ADMIN' | 'ENTERPRISE_ADMIN';

export type CourseLevel = 'BEGINNER' | 'INTERMEDIATE' | 'ADVANCED' | 'ALL_LEVELS';

export type CourseStatus = 'DRAFT' | 'PENDING_REVIEW' | 'PUBLISHED' | 'ARCHIVED';

export type LessonType =
  | 'VIDEO'
  | 'READING'
  | 'QUIZ'
  | 'ASSIGNMENT'
  | 'CODING'
  | 'LAB'
  | 'LIVE';

export type SubscriptionPlan = 'FREE' | 'BASIC' | 'PRO' | 'ENTERPRISE';

export type PaymentStatus = 'PENDING' | 'COMPLETED' | 'FAILED' | 'REFUNDED';

export type AssignmentStatus =
  | 'NOT_SUBMITTED'
  | 'SUBMITTED'
  | 'GRADED'
  | 'RESUBMISSION_REQUIRED';

export type NotificationType =
  | 'COURSE_UPDATE'
  | 'DEADLINE_REMINDER'
  | 'NEW_ANNOUNCEMENT'
  | 'ASSIGNMENT_GRADED'
  | 'CERTIFICATE_EARNED'
  | 'REPLY_TO_POST'
  | 'ENROLLMENT_CONFIRMED'
  | 'LIVE_CLASS_STARTING';

// ============================================================
// USER TYPES
// ============================================================

export interface User {
  id: string;
  name: string;
  email: string;
  image?: string;
  role: UserRole;
  bio?: string;
  headline?: string;
  website?: string;
  twitter?: string;
  linkedin?: string;
  github?: string;
  language: string;
  timezone: string;
  subscriptionPlan: SubscriptionPlan;
  subscriptionExpiry?: Date;
  learningStreak: number;
  xpPoints: number;
  totalXp: number;
  level: number;
  emailVerified?: Date;
  twoFactorEnabled: boolean;
  darkMode: boolean;
  createdAt: Date;
  updatedAt: Date;
  // Relations
  enrollments?: Enrollment[];
  certificates?: Certificate[];
  achievements?: Achievement[];
  notifications?: Notification[];
  wishlist?: Course[];
  instructorProfile?: InstructorProfile;
  enterpriseOrg?: EnterpriseOrg;
}

export interface InstructorProfile {
  id: string;
  userId: string;
  user?: User;
  bio: string;
  headline: string;
  expertise: string[];
  totalStudents: number;
  totalCourses: number;
  totalReviews: number;
  avgRating: number;
  totalRevenue: number;
  payoutEnabled: boolean;
  payoutAccountId?: string;
  isVerified: boolean;
  followers: number;
  createdAt: Date;
  courses?: Course[];
}

// ============================================================
// COURSE TYPES
// ============================================================

export interface Course {
  id: string;
  title: string;
  slug: string;
  description: string;
  shortDescription: string;
  thumbnail: string;
  previewVideo?: string;
  price: number;
  discountPrice?: number;
  isFree: boolean;
  status: CourseStatus;
  level: CourseLevel;
  language: string;
  duration: number; // in minutes
  totalLessons: number;
  totalStudents: number;
  avgRating: number;
  totalReviews: number;
  outcomes: string[];
  requirements: string[];
  tags: string[];
  hasCertificate: boolean;
  isDownloadable: boolean;
  categoryId: string;
  category?: Category;
  instructorId: string;
  instructor?: InstructorProfile;
  sections?: Section[];
  reviews?: Review[];
  createdAt: Date;
  updatedAt: Date;
  publishedAt?: Date;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  icon: string;
  description?: string;
  parentId?: string;
  parent?: Category;
  children?: Category[];
  courses?: Course[];
  courseCount: number;
}

export interface Section {
  id: string;
  courseId: string;
  title: string;
  description?: string;
  order: number;
  lessons?: Lesson[];
  duration: number;
}

export interface Lesson {
  id: string;
  sectionId: string;
  title: string;
  description?: string;
  type: LessonType;
  videoUrl?: string;
  videoDuration?: number;
  content?: string;
  resources?: Resource[];
  quiz?: Quiz;
  order: number;
  isPreview: boolean;
  isDownloadable: boolean;
  createdAt: Date;
}

export interface Resource {
  id: string;
  lessonId: string;
  title: string;
  type: 'PDF' | 'LINK' | 'FILE' | 'CODE';
  url: string;
  size?: number;
}

// ============================================================
// ENROLLMENT & PROGRESS
// ============================================================

export interface Enrollment {
  id: string;
  userId: string;
  user?: User;
  courseId: string;
  course?: Course;
  progress: number; // 0-100
  completedLessons: string[];
  currentLessonId?: string;
  currentPosition?: number; // video position in seconds
  isCompleted: boolean;
  completedAt?: Date;
  certificateId?: string;
  certificate?: Certificate;
  enrolledAt: Date;
  lastAccessedAt: Date;
  totalTimeSpent: number; // in minutes
}

export interface LessonProgress {
  id: string;
  userId: string;
  lessonId: string;
  enrollmentId: string;
  isCompleted: boolean;
  videoPosition: number;
  completedAt?: Date;
  notes?: Note[];
}

export interface Note {
  id: string;
  userId: string;
  lessonId: string;
  timestamp: number; // video timestamp
  content: string;
  createdAt: Date;
}

// ============================================================
// QUIZ & ASSESSMENT
// ============================================================

export interface Quiz {
  id: string;
  lessonId?: string;
  courseId?: string;
  title: string;
  description?: string;
  timeLimit?: number; // in minutes
  passingScore: number; // percentage
  maxAttempts: number;
  randomizeQuestions: boolean;
  showResults: boolean;
  questions?: Question[];
  isFinal: boolean;
}

export interface Question {
  id: string;
  quizId: string;
  text: string;
  type: 'MCQ' | 'TRUE_FALSE' | 'SHORT_ANSWER' | 'CODE';
  options?: QuestionOption[];
  correctAnswer: string;
  explanation?: string;
  points: number;
  order: number;
}

export interface QuestionOption {
  id: string;
  questionId: string;
  text: string;
  isCorrect: boolean;
}

export interface QuizAttempt {
  id: string;
  userId: string;
  quizId: string;
  answers: QuizAnswer[];
  score: number;
  isPassed: boolean;
  timeTaken: number; // seconds
  completedAt: Date;
}

export interface QuizAnswer {
  questionId: string;
  answer: string;
  isCorrect: boolean;
  pointsEarned: number;
}

// ============================================================
// ASSIGNMENTS
// ============================================================

export interface Assignment {
  id: string;
  lessonId: string;
  title: string;
  description: string;
  instructions: string;
  rubric?: RubricItem[];
  maxScore: number;
  dueDate?: Date;
  allowResubmission: boolean;
  maxResubmissions: number;
  isPeerReview: boolean;
  peerReviewCount: number;
}

export interface RubricItem {
  id: string;
  criterion: string;
  description: string;
  maxPoints: number;
}

export interface AssignmentSubmission {
  id: string;
  userId: string;
  assignmentId: string;
  files: SubmissionFile[];
  text?: string;
  status: AssignmentStatus;
  score?: number;
  feedback?: string;
  rubricScores?: { criterionId: string; points: number }[];
  submittedAt: Date;
  gradedAt?: Date;
  gradedBy?: string;
  attempt: number;
}

export interface SubmissionFile {
  id: string;
  name: string;
  url: string;
  size: number;
  type: string;
}

// ============================================================
// CERTIFICATES & ACHIEVEMENTS
// ============================================================

export interface Certificate {
  id: string;
  userId: string;
  user?: User;
  courseId: string;
  course?: Course;
  verificationId: string;
  issuedAt: Date;
  pdfUrl?: string;
  skills: string[];
}

export interface Achievement {
  id: string;
  userId: string;
  badgeId: string;
  badge?: Badge;
  earnedAt: Date;
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  xpReward: number;
  condition: string;
}

// ============================================================
// COMMUNITY
// ============================================================

export interface Discussion {
  id: string;
  courseId: string;
  lessonId?: string;
  userId: string;
  user?: User;
  title: string;
  content: string;
  upvotes: number;
  isPinned: boolean;
  isAnnouncement: boolean;
  isResolved: boolean;
  replies?: Reply[];
  replyCount: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface Reply {
  id: string;
  discussionId: string;
  userId: string;
  user?: User;
  content: string;
  upvotes: number;
  isInstructorReply: boolean;
  isBestAnswer: boolean;
  createdAt: Date;
}

export interface StudyGroup {
  id: string;
  courseId: string;
  name: string;
  description: string;
  maxMembers: number;
  members?: User[];
  memberCount: number;
  createdAt: Date;
}

// ============================================================
// REVIEWS & RATINGS
// ============================================================

export interface Review {
  id: string;
  userId: string;
  user?: User;
  courseId: string;
  rating: number; // 1-5
  title?: string;
  content: string;
  helpfulCount: number;
  isVerifiedPurchase: boolean;
  instructorResponse?: string;
  createdAt: Date;
  updatedAt: Date;
}

// ============================================================
// PAYMENTS
// ============================================================

export interface Order {
  id: string;
  userId: string;
  user?: User;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  couponCode?: string;
  paymentMethod: string;
  paymentIntentId?: string;
  status: PaymentStatus;
  refundedAt?: Date;
  refundReason?: string;
  createdAt: Date;
}

export interface OrderItem {
  id: string;
  orderId: string;
  courseId: string;
  course?: Course;
  price: number;
  discountPrice?: number;
}

export interface Coupon {
  id: string;
  code: string;
  discountType: 'PERCENTAGE' | 'FIXED';
  discountValue: number;
  maxUses: number;
  usedCount: number;
  validFrom: Date;
  validTo: Date;
  courseIds?: string[];
  isActive: boolean;
  createdAt: Date;
}

export interface Subscription {
  id: string;
  userId: string;
  plan: SubscriptionPlan;
  stripeSubscriptionId: string;
  status: 'ACTIVE' | 'CANCELED' | 'PAST_DUE' | 'TRIALING';
  currentPeriodStart: Date;
  currentPeriodEnd: Date;
  cancelAtPeriodEnd: boolean;
  createdAt: Date;
}

// ============================================================
// NOTIFICATIONS
// ============================================================

export interface Notification {
  id: string;
  userId: string;
  type: NotificationType;
  title: string;
  message: string;
  link?: string;
  isRead: boolean;
  createdAt: Date;
}

// ============================================================
// LEARNING PATHS
// ============================================================

export interface LearningPath {
  id: string;
  title: string;
  slug: string;
  description: string;
  thumbnail: string;
  type: 'SPECIALIZATION' | 'CERTIFICATE' | 'DEGREE' | 'BOOTCAMP' | 'CAREER_TRACK';
  courses?: Course[];
  courseIds: string[];
  estimatedDuration: number;
  difficulty: CourseLevel;
  outcomes: string[];
  price: number;
  isSubscriptionOnly: boolean;
  totalEnrollments: number;
  avgRating: number;
  createdAt: Date;
}

// ============================================================
// ENTERPRISE
// ============================================================

export interface EnterpriseOrg {
  id: string;
  name: string;
  slug: string;
  logo?: string;
  domain: string;
  plan: 'TEAM' | 'BUSINESS' | 'ENTERPRISE';
  maxSeats: number;
  usedSeats: number;
  adminId: string;
  admin?: User;
  members?: EnterpriseOrgMember[];
  teams?: EnterpriseTeam[];
  createdAt: Date;
}

export interface EnterpriseOrgMember {
  id: string;
  orgId: string;
  userId: string;
  user?: User;
  role: 'ADMIN' | 'MANAGER' | 'MEMBER';
  teamId?: string;
  joinedAt: Date;
}

export interface EnterpriseTeam {
  id: string;
  orgId: string;
  name: string;
  description?: string;
  managerId: string;
  manager?: User;
  members?: EnterpriseOrgMember[];
  assignedPaths?: LearningPath[];
  createdAt: Date;
}

// ============================================================
// LIVE CLASSES
// ============================================================

export interface LiveClass {
  id: string;
  courseId: string;
  instructorId: string;
  title: string;
  description: string;
  scheduledAt: Date;
  duration: number; // minutes
  zoomMeetingId?: string;
  zoomJoinUrl?: string;
  maxParticipants: number;
  registeredCount: number;
  isRecorded: boolean;
  recordingUrl?: string;
  status: 'SCHEDULED' | 'LIVE' | 'ENDED' | 'CANCELLED';
}

// ============================================================
// ANALYTICS
// ============================================================

export interface CourseAnalytics {
  courseId: string;
  period: 'DAY' | 'WEEK' | 'MONTH' | 'ALL';
  totalEnrollments: number;
  newEnrollments: number;
  completionRate: number;
  avgProgress: number;
  totalRevenue: number;
  avgRating: number;
  totalReviews: number;
  videoWatchTime: number;
  quizCompletionRate: number;
  dropOffPoints: { lessonId: string; dropRate: number }[];
  enrollmentOverTime: { date: string; count: number }[];
  revenueOverTime: { date: string; amount: number }[];
  deviceBreakdown: { device: string; percentage: number }[];
  countryBreakdown: { country: string; count: number }[];
}

export interface StudentAnalytics {
  userId: string;
  totalCoursesEnrolled: number;
  totalCoursesCompleted: number;
  totalTimeSpent: number;
  avgDailyLearning: number;
  currentStreak: number;
  longestStreak: number;
  totalXp: number;
  level: number;
  skillsLearned: string[];
  weeklyProgress: { day: string; minutes: number }[];
  courseProgress: { courseId: string; title: string; progress: number }[];
}

// ============================================================
// API RESPONSE TYPES
// ============================================================

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
  hasNext: boolean;
  hasPrev: boolean;
}

export interface SearchFilters {
  query?: string;
  category?: string;
  level?: CourseLevel;
  price?: 'FREE' | 'PAID';
  rating?: number;
  duration?: string;
  language?: string;
  tags?: string[];
  sortBy?: 'RELEVANCE' | 'NEWEST' | 'HIGHEST_RATED' | 'MOST_POPULAR' | 'PRICE_LOW' | 'PRICE_HIGH';
  page?: number;
  limit?: number;
}

// ============================================================
// SESSION & AUTH
// ============================================================

export interface Session {
  id: string;
  userId: string;
  device: string;
  browser: string;
  ip: string;
  location: string;
  isActive: boolean;
  lastActive: Date;
  createdAt: Date;
}

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
  expiresAt: Date;
}
