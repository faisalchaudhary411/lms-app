# 🎓 LearnForge — Full-Stack LMS Application

A production-ready **Learning Management System** built with Next.js 14, featuring all 26 feature areas including AI-powered learning, video streaming, payments, and more.

---

## 🚀 Tech Stack

| Layer | Technology |
|---|---|
| **Framework** | Next.js 14 (App Router) |
| **Language** | TypeScript |
| **Styling** | Tailwind CSS + custom design system |
| **Database** | PostgreSQL + Prisma ORM |
| **Auth** | NextAuth.js (Google, Apple, Credentials) |
| **Payments** | Stripe (courses + subscriptions) |
| **Video** | Cloudinary CDN + React Player |
| **AI** | Anthropic Claude (assistant + quiz gen) |
| **Email** | Nodemailer / Resend |
| **Cache** | Redis (ioredis) |
| **Charts** | Recharts |
| **State** | Zustand + React Query |
| **Forms** | React Hook Form + Zod |
| **Animations** | Framer Motion + Tailwind Animate |

---

## 📁 Project Structure

```
lms-app/
├── app/
│   ├── api/                    # API routes
│   │   ├── auth/               # NextAuth + register + forgot-password
│   │   ├── courses/            # Course CRUD
│   │   ├── enrollments/        # Enrollment management
│   │   ├── lessons/progress/   # Video progress tracking
│   │   ├── notes/              # In-video notes
│   │   ├── notifications/      # Notification system
│   │   ├── payments/           # Stripe payment intents
│   │   ├── webhooks/stripe/    # Stripe webhook handler
│   │   ├── ai/assistant/       # Claude AI chat
│   │   ├── ai/generate-quiz/   # AI quiz generation
│   │   ├── instructor/courses/ # Instructor course management
│   │   └── user/profile/       # User profile CRUD
│   ├── auth/                   # Login, Register, Forgot Password
│   ├── courses/                # Course catalog + detail pages
│   ├── learn/[slug]/           # Video player + lesson viewer
│   ├── dashboard/              # Student dashboard + sub-pages
│   ├── instructor/             # Instructor hub + course creation
│   ├── admin/                  # Admin panel
│   ├── enterprise/             # Enterprise/business page
│   ├── checkout/               # Stripe checkout
│   ├── cart/                   # Shopping cart
│   ├── live/                   # Live classes
│   ├── certificates/verify/    # Public certificate verification
│   └── page.tsx                # Landing page
├── components/
│   ├── ui/                     # shadcn primitives + Command Palette
│   ├── layout/                 # Navbar, Footer, DashboardLayout
│   ├── course/                 # Course cards, grid, filters, sidebar
│   ├── video/                  # HD video player with notes
│   ├── quiz/                   # Quiz engine with timer
│   ├── dashboard/              # Dashboard widgets + AI assistant
│   └── instructor/             # Instructor charts + course list
├── lib/
│   ├── auth.ts                 # NextAuth config
│   ├── prisma.ts               # Prisma client singleton
│   ├── email.ts                # Email service (Nodemailer)
│   └── utils.ts                # Utility functions
├── hooks/
│   └── useDebounce.ts
├── types/
│   └── index.ts                # All TypeScript types
├── prisma/
│   └── schema.prisma           # Full database schema
└── public/
    └── manifest.json           # PWA manifest
```

---

## ✨ Feature Coverage

### 1. User Authentication
- ✅ Email/password with bcrypt hashing
- ✅ Google OAuth & Apple OAuth (NextAuth)
- ✅ Email verification flow
- ✅ Password reset via email token
- ✅ Multi-device session management
- ✅ JWT-based sessions with 30-day expiry

### 2. Student Dashboard
- ✅ Continue learning with progress bars
- ✅ AI-powered recommendations
- ✅ Upcoming deadlines widget
- ✅ Learning streak tracker (7-day)
- ✅ Weekly learning goal
- ✅ Certificates earned panel
- ✅ Stats: hours, XP, streak, quiz scores

### 3. Course System
- ✅ 8 category tabs + advanced filters
- ✅ Smart search with Command Palette (⌘K)
- ✅ Course cards with ratings, duration, price
- ✅ Full course detail pages with curriculum
- ✅ Learning outcomes + requirements
- ✅ Instructor profiles
- ✅ Student reviews with rating distribution

### 4. Video Learning System
- ✅ HD video player (React Player)
- ✅ Playback speed: 0.5×–2×
- ✅ Subtitle/caption support
- ✅ Resume from saved position
- ✅ Mini player mode
- ✅ In-video notes with timestamps
- ✅ Fullscreen support
- ✅ Auto-mark complete at 90%

### 5. Assessment System
- ✅ MCQ quizzes with timer
- ✅ Auto-grading with instant feedback
- ✅ Retry attempts with limits
- ✅ Pass/fail with configurable threshold
- ✅ Randomized questions (schema ready)
- ✅ AI-generated quizzes via Claude API

### 6. Certification System
- ✅ Auto-issued on course completion
- ✅ Branded certificate design
- ✅ PDF generation + download
- ✅ LinkedIn sharing integration
- ✅ Public verification page (/certificates/verify/:id)
- ✅ Unique verification ID

### 7. Payments & Monetization
- ✅ Stripe payment intents
- ✅ Subscription plans (Free/Pro/Enterprise)
- ✅ Coupon system with % and fixed discounts
- ✅ Webhook handler for auto-enrollment
- ✅ Shopping cart with multi-course checkout
- ✅ 30-day refund policy display
- ✅ Wishlist management

### 8. AI Features
- ✅ Claude AI learning assistant (floating widget)
- ✅ AI-generated quiz questions
- ✅ Personalized course recommendations
- ✅ Smart search via Command Palette
- ✅ Context-aware responses using enrollment history

### 9. Gamification
- ✅ XP points system (10 XP/lesson, 50 XP/purchase)
- ✅ Level system (sqrt-based progression)
- ✅ Achievement badges (12 types)
- ✅ Learning streaks
- ✅ Weekly learning goals
- ✅ Activity heatmap (GitHub-style)
- ✅ Confetti on course completion

### 10. Instructor Features
- ✅ Multi-step course creation wizard
- ✅ Curriculum builder (sections + lesson types)
- ✅ Revenue dashboard with charts
- ✅ Student engagement radar chart
- ✅ Course management table
- ✅ Course submission for review

### 11. Admin Panel
- ✅ Platform stats overview
- ✅ Course approval queue
- ✅ User management table with search/filter
- ✅ Revenue bar chart (annual)
- ✅ Suspend/unsuspend users

### 12. Community
- ✅ Discussion forums with upvoting
- ✅ Pinned posts + announcements
- ✅ Resolved/unresolved thread status
- ✅ Create new discussions

### 13. Enterprise
- ✅ Enterprise landing page
- ✅ SSO + security features described
- ✅ Team dashboards (schema + types)
- ✅ Bulk enrollment (schema ready)

### 14. Analytics
- ✅ Daily learning time bar chart
- ✅ Monthly progress chart
- ✅ Skill distribution pie chart
- ✅ Quiz performance trend line chart
- ✅ GitHub-style activity heatmap
- ✅ Course completion breakdown

### 15. Accessibility & Mobile
- ✅ Fully responsive design (mobile-first)
- ✅ Dark/light/system theme toggle
- ✅ Keyboard navigation (Command Palette)
- ✅ Focus ring styles
- ✅ Screen-reader-friendly ARIA structure
- ✅ PWA manifest for installability

---

## 🛠️ Setup Instructions

### Prerequisites
- Node.js 18+
- PostgreSQL 14+
- Redis (optional, for sessions)

### 1. Clone & Install
```bash
# Copy the lms-app folder to your workspace
cd lms-app
npm install
```

### 2. Environment Variables
```bash
cp .env.example .env
# Fill in all values in .env
```

### 3. Database Setup
```bash
npx prisma generate
npx prisma db push
# Optional: seed with sample data
npx prisma db seed
```

### 4. Run Development Server
```bash
npm run dev
# Open http://localhost:3000
```

### 5. Configure Stripe Webhooks (local dev)
```bash
stripe listen --forward-to localhost:3000/api/webhooks/stripe
```

---

## 🔑 Key Environment Variables

```env
DATABASE_URL=postgresql://...
NEXTAUTH_SECRET=your-secret-min-32-chars
GOOGLE_CLIENT_ID=...
GOOGLE_CLIENT_SECRET=...
STRIPE_SECRET_KEY=sk_test_...
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
ANTHROPIC_API_KEY=sk-ant-...
CLOUDINARY_CLOUD_NAME=...
EMAIL_PASSWORD=...
```

---

## 📦 Key npm Scripts

| Script | Description |
|---|---|
| `npm run dev` | Start development server |
| `npm run build` | Build for production |
| `npm start` | Start production server |
| `npx prisma studio` | Open Prisma GUI |
| `npx prisma db push` | Push schema to DB |
| `npx prisma generate` | Regenerate Prisma client |

---

## 🗂️ Route Reference

| Route | Description |
|---|---|
| `/` | Landing page |
| `/auth/login` | Sign in |
| `/auth/register` | Sign up |
| `/auth/forgot-password` | Password reset |
| `/courses` | Course catalog |
| `/courses/[slug]` | Course detail |
| `/learn/[slug]` | Video player + lesson |
| `/checkout` | Stripe checkout |
| `/cart` | Shopping cart |
| `/dashboard` | Student overview |
| `/dashboard/my-courses` | Enrolled courses |
| `/dashboard/achievements` | Badges + XP |
| `/dashboard/certificates` | Certificates |
| `/dashboard/analytics` | Learning analytics |
| `/dashboard/discussions` | Community Q&A |
| `/dashboard/wishlist` | Saved courses |
| `/dashboard/settings` | Account settings |
| `/instructor` | Instructor hub |
| `/instructor/courses/create` | Course builder |
| `/admin` | Admin panel |
| `/enterprise` | Business/team page |
| `/live` | Live classes |
| `/certificates/verify/[id]` | Public certificate verification |

---

## 🧩 Adding New Features

### Add a new API route
```typescript
// app/api/your-feature/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  // ...
}
```

### Add a new Prisma model
1. Edit `prisma/schema.prisma`
2. Run `npx prisma generate && npx prisma db push`

---

## 📄 License

MIT License — free to use for commercial and personal projects.
