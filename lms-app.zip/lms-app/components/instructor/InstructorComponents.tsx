'use client';

import { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import {
  BarChart2, Users, Star, Edit, Eye, Trash2, MoreHorizontal,
  CheckCircle2, Clock, BookOpen, TrendingUp, MessageSquare
} from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis,
  PolarRadiusAxis, Radar
} from 'recharts';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';

/* ── Student Engagement ── */
const ENG_DATA = [
  { subject: 'Video Completion', A: 85 },
  { subject: 'Quiz Scores', A: 78 },
  { subject: 'Assignments', A: 72 },
  { subject: 'Discussion', A: 65 },
  { subject: 'Review Rate', A: 88 },
  { subject: 'Completion', A: 71 },
];

export function StudentEngagement() {
  return (
    <div className="bg-card border rounded-xl p-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="font-display font-bold">Student Engagement</h3>
          <p className="text-sm text-muted-foreground mt-0.5">Across all your courses</p>
        </div>
        <Badge className="bg-primary/10 text-primary border-0">Good</Badge>
      </div>
      <ResponsiveContainer width="100%" height={240}>
        <RadarChart data={ENG_DATA} cx="50%" cy="50%" outerRadius="70%">
          <PolarGrid stroke="hsl(var(--border))" />
          <PolarAngleAxis dataKey="subject" tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} />
          <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
          <Radar name="Engagement" dataKey="A" stroke="hsl(142, 71%, 45%)" fill="hsl(142, 71%, 45%)" fillOpacity={0.2} />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
}

/* ── Instructor Course List ── */
const MOCK_INS_COURSES = [
  { id: '1', slug: 'complete-react-developer', title: 'The Complete React Developer Course', thumbnail: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=120&h=68&fit=crop', status: 'PUBLISHED', students: 4823, rating: 4.7, revenue: 5240, updatedAt: new Date('2024-05-15') },
  { id: '2', slug: 'advanced-react-patterns', title: 'Advanced React Patterns & Architecture', thumbnail: 'https://images.unsplash.com/photo-1627398242454-45a1465c2479?w=120&h=68&fit=crop', status: 'PUBLISHED', students: 2187, rating: 4.8, revenue: 3120, updatedAt: new Date('2024-04-20') },
  { id: '3', slug: 'react-testing', title: 'React Testing Masterclass', thumbnail: 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=120&h=68&fit=crop', status: 'PENDING_REVIEW', students: 0, rating: 0, revenue: 0, updatedAt: new Date('2024-05-28') },
  { id: '4', slug: 'nextjs-pro', title: 'Next.js 14 Pro Course', thumbnail: 'https://images.unsplash.com/photo-1558655146-9f40138edfeb?w=120&h=68&fit=crop', status: 'DRAFT', students: 0, rating: 0, revenue: 0, updatedAt: new Date('2024-05-30') },
];

const STATUS_STYLES: Record<string, string> = {
  PUBLISHED: 'text-primary bg-primary/10 border-primary/20',
  PENDING_REVIEW: 'text-amber-500 bg-amber-500/10 border-amber-500/20',
  DRAFT: 'text-muted-foreground bg-secondary border-border',
  ARCHIVED: 'text-destructive bg-destructive/10 border-destructive/20',
};

export function InstructorCourseList() {
  const [courses, setCourses] = useState(MOCK_INS_COURSES);

  return (
    <div className="bg-card border rounded-xl overflow-hidden">
      <div className="flex items-center justify-between p-6 border-b">
        <h3 className="font-display font-bold">My Courses</h3>
        <Button size="sm" asChild>
          <Link href="/instructor/courses/create">+ New Course</Link>
        </Button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b bg-secondary/20">
              <th className="text-left px-6 py-3 text-xs font-semibold text-muted-foreground">Course</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground">Status</th>
              <th className="text-right px-4 py-3 text-xs font-semibold text-muted-foreground">Students</th>
              <th className="text-right px-4 py-3 text-xs font-semibold text-muted-foreground">Rating</th>
              <th className="text-right px-4 py-3 text-xs font-semibold text-muted-foreground">Revenue</th>
              <th className="px-4 py-3"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border/50">
            {courses.map((course) => (
              <tr key={course.id} className="hover:bg-secondary/20 transition-colors">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <div className="relative w-16 h-10 rounded-lg overflow-hidden bg-secondary shrink-0">
                      <Image src={course.thumbnail} alt={course.title} fill className="object-cover" />
                    </div>
                    <p className="font-medium text-sm line-clamp-2 max-w-xs">{course.title}</p>
                  </div>
                </td>
                <td className="px-4 py-4">
                  <span className={cn('text-xs font-medium px-2 py-0.5 rounded-full border', STATUS_STYLES[course.status] || '')}>
                    {course.status.replace('_', ' ')}
                  </span>
                </td>
                <td className="px-4 py-4 text-right">
                  {course.students > 0 ? (
                    <span className="flex items-center justify-end gap-1"><Users className="w-3.5 h-3.5 text-muted-foreground" />{course.students.toLocaleString()}</span>
                  ) : <span className="text-muted-foreground">—</span>}
                </td>
                <td className="px-4 py-4 text-right">
                  {course.rating > 0 ? (
                    <span className="flex items-center justify-end gap-1 text-amber-500 font-semibold"><Star className="w-3 h-3 fill-amber-500" />{course.rating}</span>
                  ) : <span className="text-muted-foreground">—</span>}
                </td>
                <td className="px-4 py-4 text-right font-medium">
                  {course.revenue > 0 ? <span className="text-primary">${course.revenue.toLocaleString()}</span> : <span className="text-muted-foreground">—</span>}
                </td>
                <td className="px-4 py-4">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="w-8 h-8">
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem asChild>
                        <Link href={`/instructor/courses/${course.id}/edit`}>
                          <Edit className="mr-2 w-4 h-4" />Edit Course
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link href={`/courses/${course.slug}`}>
                          <Eye className="mr-2 w-4 h-4" />Preview
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link href={`/instructor/courses/${course.id}/analytics`}>
                          <BarChart2 className="mr-2 w-4 h-4" />Analytics
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem className="text-destructive focus:text-destructive">
                        <Trash2 className="mr-2 w-4 h-4" />Archive
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ── Admin Revenue Overview ── */
const REV_DATA = [
  { month: 'Jan', revenue: 84200 }, { month: 'Feb', revenue: 97800 }, { month: 'Mar', revenue: 113400 },
  { month: 'Apr', revenue: 142600 }, { month: 'May', revenue: 168900 }, { month: 'Jun', revenue: 198400 },
  { month: 'Jul', revenue: 221700 }, { month: 'Aug', revenue: 247300 }, { month: 'Sep', revenue: 268900 },
  { month: 'Oct', revenue: 245600 }, { month: 'Nov', revenue: 284000 }, { month: 'Dec', revenue: 312400 },
];

export function AdminRevenueOverview() {
  return (
    <div className="bg-card border rounded-xl p-6">
      <div className="flex items-center justify-between mb-5">
        <div>
          <h3 className="font-display font-bold">Platform Revenue</h3>
          <p className="text-sm text-muted-foreground mt-0.5">Annual overview</p>
        </div>
        <div className="text-right">
          <p className="text-2xl font-bold">$2.18M</p>
          <p className="text-sm text-primary flex items-center gap-1 justify-end"><TrendingUp className="w-3.5 h-3.5" />+27.3% YoY</p>
        </div>
      </div>
      <ResponsiveContainer width="100%" height={200}>
        <BarChart data={REV_DATA} margin={{ top: 0, right: 0, left: -30, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
          <XAxis dataKey="month" tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} />
          <YAxis tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} tickFormatter={(v) => `$${v / 1000}k`} />
          <Tooltip formatter={(v: any) => [`$${v.toLocaleString()}`, 'Revenue']} contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '12px', fontSize: '12px' }} />
          <Bar dataKey="revenue" fill="hsl(142, 71%, 45%)" radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

/* ── Admin Layout ── */
import { DashboardLayout } from '@/components/layout/DashboardLayout';
export function AdminLayout({ children }: { children: React.ReactNode }) {
  return <DashboardLayout>{children}</DashboardLayout>;
}
