'use client';

import { useState } from 'react';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Area, AreaChart
} from 'recharts';
import { DollarSign, TrendingUp } from 'lucide-react';
import { cn } from '@/lib/utils';

const MONTHLY_DATA = [
  { month: 'Jan', revenue: 2100, enrollments: 45 },
  { month: 'Feb', revenue: 2800, enrollments: 62 },
  { month: 'Mar', revenue: 2400, enrollments: 51 },
  { month: 'Apr', revenue: 3600, enrollments: 78 },
  { month: 'May', revenue: 3200, enrollments: 71 },
  { month: 'Jun', revenue: 4100, enrollments: 89 },
  { month: 'Jul', revenue: 3800, enrollments: 84 },
  { month: 'Aug', revenue: 4500, enrollments: 97 },
  { month: 'Sep', revenue: 5200, enrollments: 112 },
  { month: 'Oct', revenue: 4900, enrollments: 107 },
  { month: 'Nov', revenue: 6100, enrollments: 134 },
  { month: 'Dec', revenue: 5800, enrollments: 124 },
];

const WEEKLY_DATA = [
  { month: 'Mon', revenue: 420, enrollments: 9 },
  { month: 'Tue', revenue: 580, enrollments: 12 },
  { month: 'Wed', revenue: 390, enrollments: 8 },
  { month: 'Thu', revenue: 710, enrollments: 15 },
  { month: 'Fri', revenue: 650, enrollments: 14 },
  { month: 'Sat', revenue: 890, enrollments: 19 },
  { month: 'Sun', revenue: 760, enrollments: 17 },
];

type Period = 'weekly' | 'monthly';
type Metric = 'revenue' | 'enrollments';

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-card border rounded-xl p-3 shadow-lg text-sm">
        <p className="font-semibold mb-1">{label}</p>
        {payload.map((entry: any) => (
          <p key={entry.name} style={{ color: entry.color }}>
            {entry.name === 'revenue' ? `$${entry.value.toLocaleString()}` : `${entry.value} enrollments`}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

export function RevenueChart() {
  const [period, setPeriod] = useState<Period>('monthly');
  const [metric, setMetric] = useState<Metric>('revenue');

  const data = period === 'monthly' ? MONTHLY_DATA : WEEKLY_DATA;

  const total = data.reduce((sum, d) => sum + (metric === 'revenue' ? d.revenue : d.enrollments), 0);

  return (
    <div className="bg-card border rounded-xl p-6">
      {/* Header */}
      <div className="flex items-start justify-between mb-6">
        <div>
          <h3 className="font-display font-bold">Revenue & Enrollments</h3>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold">
              {metric === 'revenue' ? `$${total.toLocaleString()}` : total}
            </span>
            <span className="text-sm text-primary flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              +18%
            </span>
          </div>
        </div>

        <div className="flex flex-col gap-2 items-end">
          {/* Period toggle */}
          <div className="flex rounded-lg border overflow-hidden text-xs">
            {(['weekly', 'monthly'] as Period[]).map((p) => (
              <button
                key={p}
                onClick={() => setPeriod(p)}
                className={cn(
                  'px-3 py-1.5 transition-colors capitalize',
                  period === p ? 'bg-primary text-primary-foreground' : 'hover:bg-secondary'
                )}
              >
                {p}
              </button>
            ))}
          </div>

          {/* Metric toggle */}
          <div className="flex rounded-lg border overflow-hidden text-xs">
            {(['revenue', 'enrollments'] as Metric[]).map((m) => (
              <button
                key={m}
                onClick={() => setMetric(m)}
                className={cn(
                  'px-3 py-1.5 transition-colors capitalize',
                  metric === m ? 'bg-secondary font-medium' : 'text-muted-foreground hover:text-foreground'
                )}
              >
                {m}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Chart */}
      <ResponsiveContainer width="100%" height={220}>
        <AreaChart data={data} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
          <defs>
            <linearGradient id="colorGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="hsl(142, 71%, 45%)" stopOpacity={0.3} />
              <stop offset="95%" stopColor="hsl(142, 71%, 45%)" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
          <XAxis
            dataKey="month"
            tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }}
            axisLine={false}
            tickLine={false}
          />
          <YAxis
            tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }}
            axisLine={false}
            tickLine={false}
            tickFormatter={(v) => metric === 'revenue' ? `$${v >= 1000 ? `${v / 1000}k` : v}` : String(v)}
          />
          <Tooltip content={<CustomTooltip />} />
          <Area
            type="monotone"
            dataKey={metric}
            stroke="hsl(142, 71%, 45%)"
            strokeWidth={2.5}
            fill="url(#colorGradient)"
            dot={false}
            activeDot={{ r: 5, fill: 'hsl(142, 71%, 45%)' }}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
