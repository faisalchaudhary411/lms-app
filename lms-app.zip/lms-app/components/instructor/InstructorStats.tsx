'use client';

import { DollarSign, Users, Star, BookOpen, TrendingUp, Eye } from 'lucide-react';

const STATS = [
  {
    label: 'Total Revenue',
    value: '$12,847',
    change: '+18% this month',
    positive: true,
    icon: DollarSign,
    color: 'text-emerald-500',
    bg: 'bg-emerald-500/10',
  },
  {
    label: 'Total Students',
    value: '4,923',
    change: '+124 this week',
    positive: true,
    icon: Users,
    color: 'text-blue-500',
    bg: 'bg-blue-500/10',
  },
  {
    label: 'Avg Rating',
    value: '4.8',
    change: '+0.1 improvement',
    positive: true,
    icon: Star,
    color: 'text-amber-500',
    bg: 'bg-amber-500/10',
  },
  {
    label: 'Published Courses',
    value: '7',
    change: '2 in review',
    positive: null,
    icon: BookOpen,
    color: 'text-violet-500',
    bg: 'bg-violet-500/10',
  },
  {
    label: 'Completion Rate',
    value: '72%',
    change: '+5% from last month',
    positive: true,
    icon: TrendingUp,
    color: 'text-primary',
    bg: 'bg-primary/10',
  },
  {
    label: 'Total Views',
    value: '89.2K',
    change: 'This month',
    positive: null,
    icon: Eye,
    color: 'text-pink-500',
    bg: 'bg-pink-500/10',
  },
];

export function InstructorStats() {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
      {STATS.map((stat, i) => (
        <div
          key={stat.label}
          className="bg-card border rounded-xl p-4 hover:border-primary/30 transition-all animate-fade-up"
          style={{ animationDelay: `${i * 50}ms` }}
        >
          <div className={`w-8 h-8 ${stat.bg} rounded-lg flex items-center justify-center mb-3`}>
            <stat.icon className={`w-4 h-4 ${stat.color}`} />
          </div>
          <div className="text-xl font-display font-bold">{stat.value}</div>
          <div className="text-xs text-muted-foreground">{stat.label}</div>
          {stat.change && (
            <div className={`text-xs mt-1 font-medium ${
              stat.positive === true ? 'text-primary' :
              stat.positive === false ? 'text-destructive' :
              'text-muted-foreground'
            }`}>
              {stat.change}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
