'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import dynamic from 'next/dynamic';
import {
  Play, Pause, Volume2, VolumeX, Maximize2, Minimize2,
  Settings, ChevronLeft, ChevronRight, Download, MessageSquare,
  BookOpen, PenLine, Clock, List, Subtitles, X, Plus, Check,
  SkipBack, SkipForward
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { cn } from '@/lib/utils';
import { formatDuration } from '@/lib/utils';

const ReactPlayer = dynamic(() => import('react-player/lazy'), { ssr: false });

interface VideoPlayerProps {
  videoUrl: string;
  title: string;
  lessonId: string;
  onComplete?: () => void;
  savedPosition?: number;
  subtitles?: { lang: string; label: string; url: string }[];
  isDownloadable?: boolean;
}

interface Note {
  id: string;
  timestamp: number;
  content: string;
  createdAt: Date;
}

export function VideoPlayer({
  videoUrl,
  title,
  lessonId,
  onComplete,
  savedPosition = 0,
  subtitles = [],
  isDownloadable = false,
}: VideoPlayerProps) {
  const playerRef = useRef<any>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const controlsTimeoutRef = useRef<NodeJS.Timeout>();

  const [playing, setPlaying] = useState(false);
  const [volume, setVolume] = useState(0.8);
  const [muted, setMuted] = useState(false);
  const [played, setPlayed] = useState(0);
  const [duration, setDuration] = useState(0);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [miniPlayer, setMiniPlayer] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showNotes, setShowNotes] = useState(false);
  const [notes, setNotes] = useState<Note[]>([]);
  const [noteText, setNoteText] = useState('');
  const [selectedSubtitle, setSelectedSubtitle] = useState('');
  const [completionTracked, setCompletionTracked] = useState(false);

  // Auto-hide controls
  const handleMouseMove = useCallback(() => {
    setShowControls(true);
    clearTimeout(controlsTimeoutRef.current);
    if (playing) {
      controlsTimeoutRef.current = setTimeout(() => setShowControls(false), 3000);
    }
  }, [playing]);

  // Track progress and save position
  const handleProgress = ({ played: p, playedSeconds }: { played: number; playedSeconds: number }) => {
    setPlayed(p);

    // Save position to API
    if (Math.floor(playedSeconds) % 10 === 0) {
      saveProgress(playedSeconds);
    }

    // Mark complete at 90%
    if (p > 0.9 && !completionTracked) {
      setCompletionTracked(true);
      onComplete?.();
    }
  };

  const saveProgress = async (position: number) => {
    try {
      await fetch('/api/lessons/progress', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ lessonId, position }),
      });
    } catch {}
  };

  // Resume from saved position
  useEffect(() => {
    if (savedPosition > 0 && playerRef.current) {
      playerRef.current.seekTo(savedPosition, 'seconds');
    }
  }, [savedPosition]);

  const handleSeek = (value: number[]) => {
    const newPlayed = value[0] / 100;
    setPlayed(newPlayed);
    playerRef.current?.seekTo(newPlayed, 'fraction');
  };

  const skipBackward = () => playerRef.current?.seekTo(Math.max(0, played * duration - 10), 'seconds');
  const skipForward = () => playerRef.current?.seekTo(Math.min(duration, played * duration + 10), 'seconds');

  const addNote = () => {
    if (!noteText.trim()) return;
    const note: Note = {
      id: Date.now().toString(),
      timestamp: played * duration,
      content: noteText,
      createdAt: new Date(),
    };
    setNotes((prev) => [...prev, note]);
    setNoteText('');

    // Save to API
    fetch('/api/notes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ lessonId, timestamp: note.timestamp, content: note.content }),
    }).catch(() => {});
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const SPEEDS = [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];

  return (
    <div
      ref={containerRef}
      className={cn(
        'relative bg-black rounded-xl overflow-hidden group',
        miniPlayer
          ? 'fixed bottom-6 right-6 w-80 h-48 z-50 shadow-2xl rounded-xl'
          : 'w-full aspect-video'
      )}
      onMouseMove={handleMouseMove}
      onMouseLeave={() => playing && setShowControls(false)}
    >
      {/* Player */}
      <ReactPlayer
        ref={playerRef}
        url={videoUrl}
        width="100%"
        height="100%"
        playing={playing}
        volume={muted ? 0 : volume}
        playbackRate={playbackRate}
        onProgress={handleProgress}
        onDuration={setDuration}
        onEnded={() => {
          setPlaying(false);
          onComplete?.();
        }}
        config={{
          file: {
            attributes: {
              crossOrigin: 'anonymous',
            },
            tracks: subtitles.map((s) => ({
              kind: 'subtitles',
              src: s.url,
              srcLang: s.lang,
              label: s.label,
              default: s.lang === selectedSubtitle,
            })),
          },
        }}
      />

      {/* Click to play/pause */}
      <div
        className="absolute inset-0 cursor-pointer"
        onClick={() => setPlaying(!playing)}
        onDoubleClick={toggleFullscreen}
      />

      {/* Controls overlay */}
      <div
        className={cn(
          'absolute inset-0 flex flex-col justify-end transition-opacity duration-300',
          showControls || !playing ? 'opacity-100' : 'opacity-0'
        )}
      >
        {/* Gradient */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />

        {/* Top controls */}
        <div className="absolute top-4 left-4 right-4 flex items-center justify-between z-10">
          <h3 className="text-white text-sm font-medium truncate max-w-xs">{title}</h3>
          <div className="flex items-center gap-2">
            {isDownloadable && (
              <Button
                variant="ghost"
                size="icon"
                className="w-8 h-8 text-white/80 hover:text-white hover:bg-white/10"
                onClick={(e) => { e.stopPropagation(); }}
              >
                <Download className="w-4 h-4" />
              </Button>
            )}
            <Button
              variant="ghost"
              size="icon"
              className="w-8 h-8 text-white/80 hover:text-white hover:bg-white/10"
              onClick={(e) => { e.stopPropagation(); setShowNotes(!showNotes); }}
            >
              <PenLine className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="w-8 h-8 text-white/80 hover:text-white hover:bg-white/10"
              onClick={(e) => { e.stopPropagation(); setMiniPlayer(!miniPlayer); }}
            >
              {miniPlayer ? <Maximize2 className="w-4 h-4" /> : <Minimize2 className="w-4 h-4" />}
            </Button>
          </div>
        </div>

        {/* Bottom controls */}
        <div className="relative z-10 p-4 space-y-2">
          {/* Progress bar */}
          <div className="flex items-center gap-2">
            <span className="text-white/80 text-xs font-mono min-w-10">
              {formatDuration(played * duration)}
            </span>
            <div className="flex-1" onClick={(e) => e.stopPropagation()}>
              <Slider
                value={[played * 100]}
                onValueChange={handleSeek}
                max={100}
                step={0.1}
                className="cursor-pointer"
              />
            </div>
            <span className="text-white/80 text-xs font-mono min-w-10 text-right">
              {formatDuration(duration)}
            </span>
          </div>

          {/* Control buttons */}
          <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
            {/* Play/Pause */}
            <Button
              variant="ghost"
              size="icon"
              className="w-9 h-9 text-white hover:bg-white/10"
              onClick={() => setPlaying(!playing)}
            >
              {playing ? <Pause className="w-5 h-5 fill-white" /> : <Play className="w-5 h-5 fill-white" />}
            </Button>

            {/* Skip */}
            <Button
              variant="ghost"
              size="icon"
              className="w-8 h-8 text-white/80 hover:bg-white/10"
              onClick={skipBackward}
            >
              <SkipBack className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="w-8 h-8 text-white/80 hover:bg-white/10"
              onClick={skipForward}
            >
              <SkipForward className="w-4 h-4" />
            </Button>

            {/* Volume */}
            <Button
              variant="ghost"
              size="icon"
              className="w-8 h-8 text-white/80 hover:bg-white/10"
              onClick={() => setMuted(!muted)}
            >
              {muted || volume === 0 ? (
                <VolumeX className="w-4 h-4" />
              ) : (
                <Volume2 className="w-4 h-4" />
              )}
            </Button>
            <div className="w-20">
              <Slider
                value={[muted ? 0 : volume * 100]}
                onValueChange={(v) => { setVolume(v[0] / 100); setMuted(false); }}
                max={100}
                className="cursor-pointer"
              />
            </div>

            <div className="flex-1" />

            {/* Speed */}
            <div className="relative">
              <Button
                variant="ghost"
                className="h-7 px-2 text-white/80 hover:bg-white/10 text-xs font-mono"
                onClick={() => setShowSettings(!showSettings)}
              >
                {playbackRate}x
              </Button>
              {showSettings && (
                <div className="absolute bottom-full right-0 mb-2 bg-black/90 rounded-lg p-2 min-w-24">
                  <p className="text-white/50 text-xs mb-2 px-2">Speed</p>
                  {SPEEDS.map((s) => (
                    <button
                      key={s}
                      className={cn(
                        'flex items-center gap-2 w-full text-left px-2 py-1.5 text-xs rounded hover:bg-white/10 transition-colors',
                        playbackRate === s ? 'text-primary' : 'text-white/80'
                      )}
                      onClick={() => { setPlaybackRate(s); setShowSettings(false); }}
                    >
                      {playbackRate === s && <Check className="w-3 h-3" />}
                      <span className={cn(playbackRate !== s && 'ml-5')}>{s}x</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Subtitles */}
            {subtitles.length > 0 && (
              <Button
                variant="ghost"
                size="icon"
                className={cn(
                  'w-8 h-8 hover:bg-white/10',
                  selectedSubtitle ? 'text-primary' : 'text-white/80'
                )}
                onClick={() => setSelectedSubtitle(selectedSubtitle ? '' : subtitles[0].lang)}
              >
                <Subtitles className="w-4 h-4" />
              </Button>
            )}

            {/* Fullscreen */}
            <Button
              variant="ghost"
              size="icon"
              className="w-8 h-8 text-white/80 hover:bg-white/10"
              onClick={toggleFullscreen}
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </Button>
          </div>
        </div>
      </div>

      {/* Notes panel (overlay) */}
      {showNotes && (
        <div
          className="absolute right-0 top-0 bottom-0 w-80 bg-black/90 backdrop-blur-sm z-20 p-4 flex flex-col"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-white font-semibold text-sm">Notes</h4>
            <button
              onClick={() => setShowNotes(false)}
              className="text-white/60 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* New note */}
          <div className="mb-4">
            <div className="text-xs text-white/50 mb-1">
              At {formatDuration(played * duration)}
            </div>
            <textarea
              value={noteText}
              onChange={(e) => setNoteText(e.target.value)}
              placeholder="Add a note..."
              className="w-full bg-white/10 text-white text-xs rounded-lg p-2 resize-none h-20 outline-none placeholder:text-white/40 border border-white/10 focus:border-primary/50"
            />
            <Button
              size="sm"
              className="w-full mt-2 h-7 text-xs"
              onClick={addNote}
              disabled={!noteText.trim()}
            >
              <Plus className="w-3 h-3 mr-1" /> Add Note
            </Button>
          </div>

          {/* Notes list */}
          <div className="flex-1 overflow-y-auto space-y-2 scrollbar-hide">
            {notes.length === 0 ? (
              <p className="text-white/40 text-xs text-center py-4">
                No notes yet. Add your first note!
              </p>
            ) : (
              notes.map((note) => (
                <div key={note.id} className="bg-white/10 rounded-lg p-3">
                  <div className="flex items-center justify-between mb-1">
                    <button
                      className="text-primary text-xs font-mono hover:underline"
                      onClick={() => playerRef.current?.seekTo(note.timestamp, 'seconds')}
                    >
                      {formatDuration(note.timestamp)}
                    </button>
                  </div>
                  <p className="text-white/80 text-xs leading-relaxed">{note.content}</p>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
