'use client';

// ─────────────────────────────────────────────────────────────────────────────
// CourseHero
// ─────────────────────────────────────────────────────────────────────────────
import Image from 'next/image';
import Link from 'next/link';
import { Star, Users, Clock, Globe, Award, PlayCircle, ChevronDown, ChevronUp } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useState } from 'react';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

export function CourseHero({ course, session, isEnrolled }: { course: any; session: any; isEnrolled: boolean }) {
  const hours = Math.round(course.durationMinutes / 60);
  const discountPct = course.discountPrice
    ? Math.round(((course.price - course.discountPrice) / course.price) * 100)
    : 0;

  return (
    <div className="bg-gradient-to-b from-gray-950 to-gray-900 dark:from-gray-950 dark:to-gray-900 text-white">
      <div className="container mx-auto px-4 max-w-7xl py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-5">
            {/* Breadcrumb */}
            <nav className="flex items-center gap-2 text-xs text-gray-400">
              <Link href="/courses" className="hover:text-white">Courses</Link>
              <span>/</span>
              <Link href={`/courses?category=${course.category.slug}`} className="hover:text-white">
                {course.category.name}
              </Link>
            </nav>

            <h1 className="text-3xl font-display font-bold leading-tight">{course.title}</h1>
            <p className="text-gray-300 text-base leading-relaxed">{course.shortDescription}</p>

            {/* Meta */}
            <div className="flex flex-wrap items-center gap-4 text-sm">
              {discountPct > 0 && (
                <Badge className="bg-amber-500 text-black font-bold">Bestseller</Badge>
              )}
              <div className="flex items-center gap-1">
                <span className="text-amber-400 font-bold">{course.avgRating}</span>
                <div className="flex gap-0.5">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className={cn('w-3.5 h-3.5',
                      i < Math.round(course.avgRating) ? 'fill-amber-400 text-amber-400' : 'text-gray-600'
                    )} />
                  ))}
                </div>
                <span className="text-gray-400">({course.totalReviews.toLocaleString()} ratings)</span>
              </div>
              <span className="flex items-center gap-1 text-gray-300">
                <Users className="w-3.5 h-3.5" />
                {course.totalStudents.toLocaleString()} students
              </span>
            </div>

            <div className="flex flex-wrap gap-4 text-sm text-gray-300">
              <span className="flex items-center gap-1.5">
                <Clock className="w-4 h-4" /> {hours} hours total
              </span>
              <span className="flex items-center gap-1.5">
                <PlayCircle className="w-4 h-4" /> {course.totalLessons} lessons
              </span>
              <span className="flex items-center gap-1.5">
                <Globe className="w-4 h-4" /> {course.language}
              </span>
              <span className="flex items-center gap-1.5">
                <Award className="w-4 h-4" /> Certificate
              </span>
            </div>

            <p className="text-xs text-gray-400">
              Created by <Link href="#instructor" className="text-primary hover:underline">{course.instructor.user.name}</Link>
              {' '}· Last updated {format(new Date(course.updatedAt), 'MMM yyyy')}
            </p>

            {/* Mobile CTA */}
            <div className="lg:hidden">
              <div className="flex items-baseline gap-3 mb-3">
                <span className="text-3xl font-bold">${(course.discountPrice ?? course.price).toFixed(2)}</span>
                {course.discountPrice && (
                  <span className="text-xl line-through text-gray-500">${course.price.toFixed(2)}</span>
                )}
              </div>
              <Button size="lg" className="w-full" asChild>
                <Link href={isEnrolled ? `/learn/${course.slug}` : `/checkout?courseId=${course.id}`}>
                  {isEnrolled ? 'Continue Learning' : 'Enroll Now'}
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// CourseCurriculum
// ─────────────────────────────────────────────────────────────────────────────
import { Play, FileText, HelpCircle, BookOpen, Code, ChevronRight } from 'lucide-react';

const LESSON_ICONS: Record<string, any> = {
  VIDEO: Play, READING: FileText, QUIZ: HelpCircle, ASSIGNMENT: BookOpen, CODING: Code,
};
const LESSON_COLORS: Record<string, string> = {
  VIDEO: 'text-blue-500', READING: 'text-emerald-500', QUIZ: 'text-amber-500',
  ASSIGNMENT: 'text-violet-500', CODING: 'text-pink-500',
};

export function CourseCurriculum({
  sections,
  isEnrolled,
}: {
  sections: any[];
  isEnrolled: boolean;
}) {
  const [expanded, setExpanded] = useState<Set<string>>(new Set([sections[0]?.id]));
  const totalLessons = sections.reduce((s, sec) => s + sec.lessons.length, 0);
  const totalDuration = sections.reduce((s, sec) =>
    s + sec.lessons.reduce((ls: number, l: any) => ls + (l.videoDuration || 0), 0), 0);

  const toggle = (id: string) => {
    setExpanded((prev) => {
      const n = new Set(prev);
      n.has(id) ? n.delete(id) : n.add(id);
      return n;
    });
  };

  const formatDur = (s: number) => {
    const m = Math.floor(s / 60);
    return m >= 60 ? `${Math.floor(m / 60)}h ${m % 60}m` : `${m}m`;
  };

  return (
    <section>
      <h2 className="text-xl font-display font-bold mb-2">Course Curriculum</h2>
      <p className="text-sm text-muted-foreground mb-4">
        {sections.length} sections • {totalLessons} lessons • {formatDur(totalDuration)} total length
      </p>
      <div className="border rounded-xl overflow-hidden">
        {sections.map((section, si) => {
          const isOpen = expanded.has(section.id);
          return (
            <div key={section.id}>
              <button
                onClick={() => toggle(section.id)}
                className="w-full flex items-center gap-3 p-4 bg-secondary/30 hover:bg-secondary/50 text-left transition-colors"
              >
                {isOpen ? <ChevronUp className="w-4 h-4 shrink-0" /> : <ChevronDown className="w-4 h-4 shrink-0" />}
                <span className="flex-1 font-medium text-sm">
                  {si + 1}. {section.title}
                </span>
                <span className="text-xs text-muted-foreground shrink-0">
                  {section.lessons.length} lessons
                </span>
              </button>
              {isOpen && (
                <div className="divide-y divide-border/50">
                  {section.lessons.map((lesson: any) => {
                    const Icon = LESSON_ICONS[lesson.type] || Play;
                    const color = LESSON_COLORS[lesson.type] || 'text-muted-foreground';
                    return (
                      <div
                        key={lesson.id}
                        className={cn(
                          'flex items-center gap-3 px-6 py-3 text-sm',
                          lesson.isPreview && 'cursor-pointer hover:bg-secondary/30'
                        )}
                      >
                        <Icon className={cn('w-4 h-4 shrink-0', color)} />
                        <span className={cn('flex-1', !isEnrolled && !lesson.isPreview && 'text-muted-foreground')}>
                          {lesson.title}
                        </span>
                        {lesson.isPreview && (
                          <Badge variant="outline" className="text-[10px] text-primary border-primary/30">Preview</Badge>
                        )}
                        {lesson.videoDuration && (
                          <span className="text-xs text-muted-foreground">{formatDur(lesson.videoDuration)}</span>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// CourseInstructor
// ─────────────────────────────────────────────────────────────────────────────
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

export function CourseInstructor({ instructor }: { instructor: any }) {
  return (
    <section id="instructor">
      <h2 className="text-xl font-display font-bold mb-5">Your Instructor</h2>
      <div className="bg-card border rounded-xl p-6">
        <div className="flex items-start gap-4">
          <Avatar className="w-16 h-16">
            <AvatarImage src={instructor.user.image} />
            <AvatarFallback className="bg-primary/20 text-primary font-bold text-xl">
              {instructor.user.name[0]}
            </AvatarFallback>
          </Avatar>
          <div>
            <h3 className="font-display font-bold text-lg">{instructor.user.name}</h3>
            <p className="text-sm text-muted-foreground">{instructor.user.headline}</p>
            <div className="flex gap-4 mt-2 text-sm text-muted-foreground">
              <span className="flex items-center gap-1">
                <Star className="w-3.5 h-3.5 text-amber-400" />
                {instructor.avgRating} Instructor Rating
              </span>
              <span className="flex items-center gap-1">
                <Users className="w-3.5 h-3.5" />
                {instructor.totalStudents.toLocaleString()} Students
              </span>
              <span className="flex items-center gap-1">
                <BookOpen className="w-3.5 h-3.5" />
                {instructor.totalCourses} Courses
              </span>
            </div>
          </div>
        </div>
        <p className="text-sm text-muted-foreground leading-relaxed mt-4">{instructor.bio}</p>
      </div>
    </section>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// CourseReviews
// ─────────────────────────────────────────────────────────────────────────────
export function CourseReviews({
  courseId,
  avgRating,
  totalReviews,
}: {
  courseId: string;
  avgRating: number;
  totalReviews: number;
}) {
  const MOCK_REVIEWS = [
    { id: '1', user: { name: 'Alex P.', image: '' }, rating: 5, title: 'Excellent course!', content: 'Best React course I have taken. The instructor explains everything clearly and the projects are very practical.', createdAt: new Date('2024-04-10'), helpfulCount: 42 },
    { id: '2', user: { name: 'Maria S.', image: '' }, rating: 4, title: 'Very comprehensive', content: 'Great coverage of all React concepts. Would love more advanced topics but overall excellent.', createdAt: new Date('2024-03-22'), helpfulCount: 28 },
    { id: '3', user: { name: 'James K.', image: '' }, rating: 5, title: 'Worth every penny', content: 'Changed my career! Got a job as a React developer within 3 months of completing this course.', createdAt: new Date('2024-02-15'), helpfulCount: 65 },
  ];

  return (
    <section>
      <h2 className="text-xl font-display font-bold mb-5">Student Reviews</h2>
      <div className="flex items-center gap-8 mb-6 p-6 bg-secondary/30 rounded-xl">
        <div className="text-center">
          <div className="text-5xl font-display font-bold text-amber-400">{avgRating}</div>
          <div className="flex gap-0.5 justify-center mt-1">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className={cn('w-4 h-4', i < Math.round(avgRating) ? 'fill-amber-400 text-amber-400' : 'text-gray-400')} />
            ))}
          </div>
          <div className="text-xs text-muted-foreground mt-1">Course Rating</div>
        </div>
        <div className="flex-1 space-y-2">
          {[5, 4, 3, 2, 1].map((star) => {
            const pct = star === 5 ? 70 : star === 4 ? 20 : star === 3 ? 7 : star === 2 ? 2 : 1;
            return (
              <div key={star} className="flex items-center gap-3 text-sm">
                <div className="flex gap-0.5 shrink-0">
                  {[...Array(star)].map((_, i) => <Star key={i} className="w-3 h-3 fill-amber-400 text-amber-400" />)}
                </div>
                <div className="flex-1 h-2 bg-border rounded-full overflow-hidden">
                  <div className="h-full bg-amber-400 rounded-full" style={{ width: `${pct}%` }} />
                </div>
                <span className="text-xs text-muted-foreground w-8">{pct}%</span>
              </div>
            );
          })}
        </div>
      </div>
      <div className="space-y-4">
        {MOCK_REVIEWS.map((review) => (
          <div key={review.id} className="p-5 bg-card border rounded-xl">
            <div className="flex items-center gap-3 mb-3">
              <Avatar className="w-9 h-9">
                <AvatarFallback className="bg-primary/20 text-primary font-bold text-sm">
                  {review.user.name[0]}
                </AvatarFallback>
              </Avatar>
              <div>
                <p className="font-medium text-sm">{review.user.name}</p>
                <div className="flex gap-0.5">
                  {[...Array(review.rating)].map((_, i) => (
                    <Star key={i} className="w-3 h-3 fill-amber-400 text-amber-400" />
                  ))}
                </div>
              </div>
              <span className="ml-auto text-xs text-muted-foreground">
                {format(review.createdAt, 'MMM d, yyyy')}
              </span>
            </div>
            {review.title && <p className="font-semibold text-sm mb-1">{review.title}</p>}
            <p className="text-sm text-muted-foreground leading-relaxed">{review.content}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// CourseDiscussions (stub)
// ─────────────────────────────────────────────────────────────────────────────
export function CourseDiscussions({ courseId, session, isEnrolled }: any) {
  return (
    <section id="discussion">
      <h2 className="text-xl font-display font-bold mb-5">Discussions</h2>
      <div className="bg-card border rounded-xl p-6 text-center">
        {isEnrolled ? (
          <p className="text-muted-foreground text-sm">Discussions load after enrollment.</p>
        ) : (
          <p className="text-muted-foreground text-sm">Enroll to access course discussions and Q&A.</p>
        )}
      </div>
    </section>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// RelatedCourses (stub)
// ─────────────────────────────────────────────────────────────────────────────
export function RelatedCourses({ courseId, categoryId }: any) {
  return (
    <section>
      <h2 className="text-xl font-display font-bold mb-5">Students also bought</h2>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="bg-card border rounded-xl overflow-hidden hover:border-primary/30 transition-all">
            <div className="aspect-video bg-secondary shimmer" />
            <div className="p-3 space-y-1">
              <div className="h-3 bg-secondary rounded shimmer" />
              <div className="h-3 bg-secondary rounded w-2/3 shimmer" />
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
