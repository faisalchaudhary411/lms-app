'use client';

import { useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  Play, Star, Users, Clock, Globe, Award, Download, Check,
  Heart, Share2, ShoppingCart, Zap, Lock, Tv, Smartphone,
  BarChart2, ChevronDown
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';
import toast from 'react-hot-toast';

interface CourseSidebarProps {
  course: any;
  session: any;
  isEnrolled: boolean;
}

export function CourseSidebar({ course, session, isEnrolled }: CourseSidebarProps) {
  const router = useRouter();
  const [wishlisted, setWishlisted] = useState(false);
  const [addingToCart, setAddingToCart] = useState(false);
  const [couponCode, setCouponCode] = useState('');
  const [showCoupon, setShowCoupon] = useState(false);
  const [appliedCoupon, setAppliedCoupon] = useState<null | { code: string; discount: number }>(null);

  const discount = appliedCoupon
    ? course.discountPrice - (course.discountPrice * appliedCoupon.discount) / 100
    : course.discountPrice ?? course.price;

  const originalPrice = course.price;
  const discountPercent = Math.round(((originalPrice - discount) / originalPrice) * 100);

  const handleEnroll = async () => {
    if (!session) {
      router.push('/auth/login?callbackUrl=' + encodeURIComponent(window.location.pathname));
      return;
    }
    if (course.isFree) {
      try {
        await fetch('/api/enrollments', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ courseId: course.id }),
        });
        toast.success('Enrolled successfully! 🎉');
        router.push(`/learn/${course.slug}`);
      } catch {
        toast.error('Enrollment failed. Please try again.');
      }
    } else {
      router.push(`/checkout?courseId=${course.id}${appliedCoupon ? `&coupon=${appliedCoupon.code}` : ''}`);
    }
  };

  const addToCart = async () => {
    setAddingToCart(true);
    try {
      await fetch('/api/cart', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ courseId: course.id }),
      });
      toast.success('Added to cart!');
    } catch {
      toast.error('Failed to add to cart');
    } finally {
      setAddingToCart(false);
    }
  };

  const applyCoupon = async () => {
    if (!couponCode.trim()) return;
    try {
      const res = await fetch(`/api/coupons/validate?code=${couponCode}&courseId=${course.id}`);
      const data = await res.json();
      if (data.valid) {
        setAppliedCoupon({ code: couponCode, discount: data.discount });
        toast.success(`Coupon applied! ${data.discount}% off`);
      } else {
        toast.error('Invalid or expired coupon');
      }
    } catch {
      toast.error('Could not validate coupon');
    }
  };

  const hours = Math.round(course.durationMinutes / 60);

  const INCLUDES = [
    { icon: Tv, text: `${hours} hours on-demand video` },
    { icon: Download, text: course.isDownloadable ? 'Downloadable resources' : '15 articles' },
    { icon: Smartphone, text: 'Access on mobile & desktop' },
    { icon: Award, text: 'Certificate of completion' },
    { icon: Globe, text: 'Full lifetime access' },
  ];

  if (isEnrolled) {
    return (
      <div className="bg-card border rounded-2xl overflow-hidden shadow-xl">
        <div className="p-6">
          <div className="flex items-center gap-3 mb-4 p-3 bg-primary/10 rounded-xl border border-primary/20">
            <Check className="w-5 h-5 text-primary shrink-0" />
            <div>
              <p className="text-sm font-semibold text-primary">You&apos;re enrolled</p>
              <p className="text-xs text-muted-foreground">Continue your learning journey</p>
            </div>
          </div>
          <Button size="lg" className="w-full gap-2" asChild>
            <Link href={`/learn/${course.slug}`}>
              <Play className="w-4 h-4 fill-current" />
              Continue Learning
            </Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card border rounded-2xl overflow-hidden shadow-xl">
      {/* Preview video thumbnail */}
      <div className="relative aspect-video bg-secondary group cursor-pointer">
        <Image
          src={course.thumbnail}
          alt={course.title}
          fill
          className="object-cover"
        />
        <div className="absolute inset-0 bg-black/40 flex items-center justify-center group-hover:bg-black/50 transition-colors">
          <div className="w-14 h-14 bg-white/90 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg">
            <Play className="w-6 h-6 text-black fill-black ml-1" />
          </div>
        </div>
        <div className="absolute bottom-3 left-1/2 -translate-x-1/2 bg-black/60 text-white text-xs px-2 py-1 rounded-full">
          Preview this course
        </div>
      </div>

      <div className="p-6 space-y-4">
        {/* Price */}
        <div>
          {course.isFree ? (
            <div className="text-3xl font-display font-bold text-primary">Free</div>
          ) : (
            <div className="flex items-baseline gap-3">
              <span className="text-3xl font-display font-bold">
                ${discount.toFixed(2)}
              </span>
              {originalPrice > discount && (
                <>
                  <span className="text-lg text-muted-foreground line-through">
                    ${originalPrice.toFixed(2)}
                  </span>
                  <Badge className="bg-red-500/10 text-red-500 border-red-500/20">
                    {discountPercent}% off
                  </Badge>
                </>
              )}
            </div>
          )}
          {!course.isFree && (
            <p className="text-xs text-red-500 font-medium mt-1 flex items-center gap-1">
              <Zap className="w-3 h-3" />
              2 days left at this price!
            </p>
          )}
        </div>

        {/* CTA buttons */}
        <div className="space-y-2">
          <Button size="lg" className="w-full text-base h-12" onClick={handleEnroll}>
            {course.isFree ? 'Enroll for Free' : 'Buy Now'}
          </Button>
          {!course.isFree && (
            <Button
              size="lg"
              variant="outline"
              className="w-full"
              onClick={addToCart}
              disabled={addingToCart}
            >
              <ShoppingCart className="w-4 h-4 mr-2" />
              Add to Cart
            </Button>
          )}
        </div>

        <p className="text-center text-xs text-muted-foreground">
          30-Day Money-Back Guarantee
        </p>

        <Separator />

        {/* Course includes */}
        <div>
          <h4 className="text-sm font-semibold mb-3">This course includes:</h4>
          <ul className="space-y-2">
            {INCLUDES.map((item, i) => (
              <li key={i} className="flex items-center gap-2.5 text-sm">
                <item.icon className="w-4 h-4 text-muted-foreground shrink-0" />
                <span className="text-muted-foreground">{item.text}</span>
              </li>
            ))}
          </ul>
        </div>

        <Separator />

        {/* Share & Wishlist */}
        <div className="flex gap-2">
          <Button
            variant="ghost"
            size="sm"
            className={cn('flex-1 gap-2', wishlisted && 'text-red-500')}
            onClick={() => {
              setWishlisted(!wishlisted);
              toast.success(wishlisted ? 'Removed from wishlist' : 'Added to wishlist!');
            }}
          >
            <Heart className={cn('w-4 h-4', wishlisted && 'fill-red-500')} />
            {wishlisted ? 'Wishlisted' : 'Wishlist'}
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="flex-1 gap-2"
            onClick={() => {
              navigator.clipboard.writeText(window.location.href);
              toast.success('Link copied!');
            }}
          >
            <Share2 className="w-4 h-4" />
            Share
          </Button>
        </div>

        {/* Coupon */}
        {!course.isFree && (
          <div>
            <button
              onClick={() => setShowCoupon(!showCoupon)}
              className="flex items-center gap-1.5 text-sm text-primary hover:underline"
            >
              Have a coupon?
              <ChevronDown className={cn('w-3.5 h-3.5 transition-transform', showCoupon && 'rotate-180')} />
            </button>
            {showCoupon && (
              <div className="mt-2 flex gap-2">
                <input
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                  placeholder="Enter coupon code"
                  className="flex-1 px-3 py-2 text-sm bg-background border rounded-lg outline-none focus:ring-2 ring-primary/30"
                />
                <Button size="sm" onClick={applyCoupon}>Apply</Button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
