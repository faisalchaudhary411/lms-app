'use client';
import Image from 'next/image';
import Link from 'next/link';
import { useRouter, usePathname } from 'next/navigation';
import { Star, Users, Clock, Award, Heart, Play, Search } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { cn, formatMinutes, buildSearchUrl } from '@/lib/utils';
import { useState } from 'react';

/* ── CourseCard ── */
export function CourseCard({ course }: { course: any }) {
  const [wishlisted, setWishlisted] = useState(false);
  const discountPct = course.discountPrice ? Math.round(((course.price - course.discountPrice) / course.price) * 100) : 0;
  return (
    <Link href={`/courses/${course.slug}`} className="course-card group block">
      <div className="relative aspect-video overflow-hidden bg-secondary">
        {course.thumbnail ? (
          <Image src={course.thumbnail} alt={course.title} fill className="object-cover group-hover:scale-105 transition-transform duration-300" />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-primary/20 to-emerald-500/20 flex items-center justify-center">
            <Play className="w-8 h-8 text-primary" />
          </div>
        )}
        {discountPct > 0 && <Badge className="absolute top-2 left-2 bg-red-500 text-white border-0 text-[10px]">{discountPct}% OFF</Badge>}
        {course.isFree && <Badge className="absolute top-2 left-2 bg-primary text-primary-foreground border-0 text-[10px]">FREE</Badge>}
        <button onClick={(e) => { e.preventDefault(); setWishlisted(!wishlisted); }} className="absolute top-2 right-2 w-7 h-7 rounded-full bg-background/80 backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
          <Heart className={cn('w-3.5 h-3.5', wishlisted ? 'fill-red-500 text-red-500' : 'text-muted-foreground')} />
        </button>
      </div>
      <div className="p-4">
        <h3 className="font-semibold text-sm leading-snug line-clamp-2 group-hover:text-primary transition-colors mb-1">{course.title}</h3>
        <p className="text-xs text-muted-foreground line-clamp-1 mb-2">{course.instructor?.user?.name}</p>
        <div className="flex items-center gap-1.5 mb-2">
          <span className="text-xs font-bold text-amber-500">{course.avgRating?.toFixed(1)}</span>
          <div className="flex gap-0.5">{[...Array(5)].map((_, i) => <Star key={i} className={cn('w-2.5 h-2.5', i < Math.round(course.avgRating || 0) ? 'fill-amber-400 text-amber-400' : 'text-muted-foreground/30')} />)}</div>
          <span className="text-[10px] text-muted-foreground">({(course.totalReviews || 0).toLocaleString()})</span>
        </div>
        <div className="flex items-center gap-3 text-[10px] text-muted-foreground mb-2">
          <span className="flex items-center gap-1"><Clock className="w-2.5 h-2.5" />{formatMinutes(course.durationMinutes || 0)}</span>
          <span className="flex items-center gap-1"><Users className="w-2.5 h-2.5" />{(course.totalStudents || 0).toLocaleString()}</span>
          {course.hasCertificate && <span className="flex items-center gap-1 text-primary"><Award className="w-2.5 h-2.5" />Cert</span>}
        </div>
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-baseline gap-1.5">
            {course.isFree ? <span className="text-sm font-bold text-primary">Free</span> : <>
              <span className="text-sm font-bold">${(course.discountPrice ?? course.price).toFixed(2)}</span>
              {course.discountPrice && <span className="text-xs text-muted-foreground line-through">${course.price.toFixed(2)}</span>}
            </>}
          </div>
          <Badge variant="outline" className="text-[10px] px-1.5 capitalize">{(course.level || '').replace('_', ' ').toLowerCase()}</Badge>
        </div>
      </div>
    </Link>
  );
}

/* ── Mock data ── */
const MOCK_COURSES = Array.from({ length: 12 }, (_, i) => ({
  id: String(i + 1), slug: `course-${i + 1}`,
  title: ['Complete React Developer', 'Python for Data Science & ML', 'AWS Cloud Practitioner', 'UI/UX Design Masterclass', 'Full-Stack Next.js 14', 'Docker & Kubernetes', 'Machine Learning A-Z', 'Complete JavaScript', 'iOS Dev with Swift', 'Android with Kotlin', 'Figma Advanced', 'SQL & Database Design'][i],
  thumbnail: `https://images.unsplash.com/photo-${['1633356122544-f134324a6cee','1526379095098-d400fd0bf935','1451187580459-43490279c0fa','1558655146-9f40138edfeb','1627398242454-45a1465c2479','1605745341112-85968b19335b','1509228468518-180b8ef8ade0','1461749280684-dccba630e2f6','1512941937669-90a1b58e7e9c','1607252650355-f7fd0460ccdb','1561070791-2526d30994b5','1544383835-bda2bc66a55d'][i]}?w=400&h=225&fit=crop`,
  price: [89.99,94.99,79.99,74.99,99.99,89.99,119.99,94.99,84.99,84.99,69.99,54.99][i],
  discountPrice: [14.99,16.99,12.99,13.99,17.99,14.99,19.99,15.99,14.99,13.99,11.99,9.99][i],
  isFree: i === 11, level: ['BEGINNER','INTERMEDIATE','BEGINNER','ALL_LEVELS','INTERMEDIATE','ADVANCED','INTERMEDIATE','BEGINNER','INTERMEDIATE','INTERMEDIATE','ADVANCED','BEGINNER'][i],
  durationMinutes: [4380,3720,1800,2160,3060,2700,4500,5220,3300,3000,1620,900][i],
  totalStudents: [94823,82145,71230,65421,58300,43210,112400,178500,52100,48900,34500,28900][i],
  avgRating: [4.7,4.6,4.8,4.5,4.7,4.6,4.8,4.9,4.5,4.6,4.7,4.4][i],
  totalReviews: [18432,12847,9231,8745,7823,5621,24387,42156,6783,5892,4321,3456][i],
  hasCertificate: true, tags: [],
  instructor: { user: { name: ['Andrew Mead','Sarah Johnson','Mike Chen','Emma Wilson','Chris Lee','Alex Kumar','Dr. Smith','Colt Steele','iOS Hut','Mark Moeykens','Daniel Scott','DB Masters'][i] } },
}));

export function CourseGrid({ searchParams }: { searchParams?: any }) {
  return (
    <div>
      <p className="text-sm text-muted-foreground mb-4">12 courses found</p>
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5">
        {MOCK_COURSES.map((c) => <CourseCard key={c.id} course={c as any} />)}
      </div>
    </div>
  );
}

/* ── CourseFilters ── */
const LEVELS = [{ value: 'BEGINNER', label: 'Beginner' }, { value: 'INTERMEDIATE', label: 'Intermediate' }, { value: 'ADVANCED', label: 'Advanced' }];
const RATINGS = [{ value: '4.5', label: '4.5 & up' }, { value: '4.0', label: '4.0 & up' }, { value: '3.5', label: '3.5 & up' }];
const DURATIONS = [{ value: '0-1', label: 'Under 1 hour' }, { value: '1-3', label: '1–3 hours' }, { value: '3-6', label: '3–6 hours' }, { value: '6+', label: '6+ hours' }];

export function CourseFilters({ searchParams }: { searchParams?: any }) {
  const router = useRouter(); const pathname = usePathname();
  const update = (key: string, value: string) => {
    const p = { ...searchParams, [key]: value, page: '1' };
    if (p[key] === searchParams?.[key]) delete p[key];
    router.push(pathname + buildSearchUrl(p));
  };
  return (
    <div className="bg-card border rounded-xl p-5 sticky top-24">
      <h2 className="font-display font-bold mb-5">Filters</h2>
      {[{ title: 'Price', items: [{ value: '', label: 'All' }, { value: 'FREE', label: 'Free' }, { value: 'PAID', label: 'Paid' }], key: 'price', type: 'radio' },].map(({ title, items, key, type }) => (
        <div key={title} className="mb-5">
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">{title}</h3>
          <div className="space-y-2">{items.map((opt) => (
            <label key={opt.value} className="flex items-center gap-2 cursor-pointer text-sm">
              <input type={type as any} name={key} checked={(searchParams?.[key] || '') === opt.value} onChange={() => update(key, opt.value)} className="accent-primary" />
              {opt.label}
            </label>
          ))}</div>
        </div>
      ))}
      <div className="mb-5">
        <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Level</h3>
        <div className="space-y-2">{LEVELS.map((l) => <label key={l.value} className="flex items-center gap-2 cursor-pointer text-sm"><input type="checkbox" checked={searchParams?.level === l.value} onChange={() => update('level', l.value)} className="accent-primary rounded" />{l.label}</label>)}</div>
      </div>
      <div className="mb-5">
        <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Rating</h3>
        <div className="space-y-2">{RATINGS.map((r) => <label key={r.value} className="flex items-center gap-2 cursor-pointer text-sm"><input type="radio" name="rating" checked={searchParams?.rating === r.value} onChange={() => update('rating', r.value)} className="accent-primary" /><Star className="w-3 h-3 fill-amber-400 text-amber-400" />{r.label}</label>)}</div>
      </div>
      <div className="mb-5">
        <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Duration</h3>
        <div className="space-y-2">{DURATIONS.map((d) => <label key={d.value} className="flex items-center gap-2 cursor-pointer text-sm"><input type="checkbox" checked={searchParams?.duration === d.value} onChange={() => update('duration', d.value)} className="accent-primary rounded" />{d.label}</label>)}</div>
      </div>
      <Button variant="outline" size="sm" className="w-full" onClick={() => router.push(pathname)}>Clear All</Button>
    </div>
  );
}

/* ── CourseSearchBar ── */
export function CourseSearchBar({ initialQuery }: { initialQuery?: string }) {
  const router = useRouter(); const [q, setQ] = useState(initialQuery || '');
  return (
    <form onSubmit={(e) => { e.preventDefault(); router.push(`/courses${q ? `?q=${encodeURIComponent(q)}` : ''}`); }} className="relative max-w-xl">
      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search courses..." className="w-full pl-10 pr-4 py-2.5 text-sm bg-background border rounded-xl outline-none focus:ring-2 ring-primary/30" />
    </form>
  );
}

/* ── CourseSortBar ── */
export function CourseSortBar({ searchParams }: { searchParams?: any }) {
  const router = useRouter(); const pathname = usePathname();
  const SORTS = [{ value: 'RELEVANCE', label: 'Most Relevant' }, { value: 'MOST_POPULAR', label: 'Most Popular' }, { value: 'HIGHEST_RATED', label: 'Highest Rated' }, { value: 'NEWEST', label: 'Newest' }, { value: 'PRICE_LOW', label: 'Price: Low to High' }, { value: 'PRICE_HIGH', label: 'Price: High to Low' }];
  return (
    <div className="flex items-center gap-3 mb-5 text-sm text-muted-foreground">
      Sort by:
      <select value={searchParams?.sort || 'RELEVANCE'} onChange={(e) => router.push(pathname + buildSearchUrl({ ...searchParams, sort: e.target.value }))} className="px-2 py-1 text-sm bg-background border rounded-lg outline-none text-foreground">
        {SORTS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
      </select>
    </div>
  );
}

/* ── CategoryTabs ── */
const CATS = [{ slug: '', label: 'All' }, { slug: 'web-development', label: 'Web Dev' }, { slug: 'data-science', label: 'Data Science' }, { slug: 'ai-ml', label: 'AI & ML' }, { slug: 'design', label: 'Design' }, { slug: 'business', label: 'Business' }, { slug: 'cloud', label: 'Cloud' }, { slug: 'mobile', label: 'Mobile' }, { slug: 'marketing', label: 'Marketing' }, { slug: 'cybersecurity', label: 'Cybersecurity' }];

export function CategoryTabs({ activeCategory }: { activeCategory?: string }) {
  const router = useRouter();
  return (
    <div className="flex gap-1 overflow-x-auto scrollbar-hide px-4 pb-1">
      {CATS.map((cat) => (
        <button key={cat.slug} onClick={() => router.push(`/courses${cat.slug ? `?category=${cat.slug}` : ''}`)} className={cn('px-4 py-2 text-sm font-medium whitespace-nowrap rounded-lg transition-colors shrink-0', (activeCategory || '') === cat.slug ? 'bg-primary/10 text-primary' : 'text-muted-foreground hover:text-foreground hover:bg-secondary')}>
          {cat.label}
        </button>
      ))}
    </div>
  );
}
