'use client';

import Link from 'next/link';
import Image from 'next/image';
import { ChevronRight, Star, Clock, Award, Trophy, Target, Calendar, Zap, TrendingUp, BookOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

/* ── Recommended Courses ── */
const RECS = [
  { id: '1', slug: 'typescript-complete', title: 'TypeScript: The Complete Developer Guide', thumbnail: 'https://images.unsplash.com/photo-1627398242454-45a1465c2479?w=200&h=120&fit=crop', instructor: 'Stephen Grider', price: 12.99, rating: 4.8, students: 67234 },
  { id: '2', slug: 'node-js-api', title: 'Node.js API Masterclass with Express & MongoDB', thumbnail: 'https://images.unsplash.com/photo-1558655146-9f40138edfeb?w=200&h=120&fit=crop', instructor: 'Brad Traversy', price: 14.99, rating: 4.7, students: 54320 },
  { id: '3', slug: 'postgresql-guide', title: 'The Complete PostgreSQL Guide', thumbnail: 'https://images.unsplash.com/photo-1544383835-bda2bc66a55d?w=200&h=120&fit=crop', instructor: 'Stephen Grider', price: 11.99, rating: 4.7, students: 38900 },
];

export function RecommendedCourses({ userId }: { userId?: string }) {
  return (
    <div className="bg-card border rounded-xl p-6">
      <div className="flex items-center justify-between mb-5">
        <div>
          <h2 className="text-lg font-display font-bold flex items-center gap-2">
            <Zap className="w-4 h-4 text-primary" />
            Recommended for You
          </h2>
          <p className="text-sm text-muted-foreground mt-0.5">Based on your learning history</p>
        </div>
        <Button variant="ghost" size="sm" className="gap-1 text-primary" asChild>
          <Link href="/courses">Explore all <ChevronRight className="w-3.5 h-3.5" /></Link>
        </Button>
      </div>
      <div className="space-y-3">
        {RECS.map((course) => (
          <Link key={course.id} href={`/courses/${course.slug}`} className="flex gap-3 p-3 rounded-xl hover:bg-secondary/50 transition-colors group">
            <div className="relative w-24 h-14 rounded-lg overflow-hidden shrink-0 bg-secondary">
              <Image src={course.thumbnail} alt={course.title} fill className="object-cover group-hover:scale-105 transition-transform duration-300" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-sm font-medium line-clamp-2 group-hover:text-primary transition-colors">{course.title}</h3>
              <p className="text-xs text-muted-foreground mt-0.5">{course.instructor}</p>
              <div className="flex items-center gap-3 mt-1">
                <span className="flex items-center gap-0.5 text-xs text-amber-500 font-medium"><Star className="w-2.5 h-2.5 fill-amber-500" />{course.rating}</span>
                <span className="text-xs font-bold text-primary">${course.price}</span>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}

/* ── Upcoming Deadlines ── */
const DEADLINES = [
  { id: '1', title: 'Hooks Assignment', course: 'Complete React Developer', dueDate: new Date(Date.now() + 1000 * 60 * 60 * 20), type: 'ASSIGNMENT', urgent: true },
  { id: '2', title: 'NumPy Quiz', course: 'Python for Data Science', dueDate: new Date(Date.now() + 1000 * 60 * 60 * 48), type: 'QUIZ', urgent: false },
  { id: '3', title: 'AWS Final Exam', course: 'AWS Cloud Practitioner', dueDate: new Date(Date.now() + 1000 * 60 * 60 * 96), type: 'QUIZ', urgent: false },
];

export function UpcomingDeadlines({ userId }: { userId?: string }) {
  return (
    <div className="bg-card border rounded-xl p-5">
      <div className="flex items-center gap-2 mb-4">
        <Calendar className="w-4 h-4 text-primary" />
        <h3 className="font-display font-bold text-sm">Upcoming Deadlines</h3>
      </div>
      <div className="space-y-3">
        {DEADLINES.map((d) => {
          const hoursLeft = Math.round((d.dueDate.getTime() - Date.now()) / (1000 * 60 * 60));
          return (
            <div key={d.id} className={cn('p-3 rounded-lg border', d.urgent ? 'border-red-500/20 bg-red-500/5' : 'border-border bg-secondary/20')}>
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="text-xs font-semibold">{d.title}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5 line-clamp-1">{d.course}</p>
                </div>
                <Badge variant="outline" className={cn('text-[10px] shrink-0', d.urgent ? 'text-red-500 border-red-500/30' : '')}>
                  {d.type}
                </Badge>
              </div>
              <p className={cn('text-[10px] mt-1.5 font-medium', d.urgent ? 'text-red-500' : 'text-muted-foreground')}>
                {d.urgent ? '⚠️ ' : ''}{hoursLeft < 24 ? `${hoursLeft}h left` : `${Math.round(hoursLeft / 24)}d left`} · {format(d.dueDate, 'MMM d')}
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ── Recent Certificates ── */
const CERTS = [
  { id: '1', courseTitle: 'JavaScript Fundamentals', issuedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 7), skills: ['JavaScript', 'ES6'] },
  { id: '2', courseTitle: 'Git & GitHub Masterclass', issuedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 30), skills: ['Git', 'GitHub'] },
];

export function RecentCertificates({ userId }: { userId?: string }) {
  return (
    <div className="bg-card border rounded-xl p-5">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Award className="w-4 h-4 text-amber-500" />
          <h3 className="font-display font-bold text-sm">Recent Certificates</h3>
        </div>
        <Link href="/dashboard/certificates" className="text-xs text-primary hover:underline">View all</Link>
      </div>
      {CERTS.length === 0 ? (
        <div className="text-center py-4">
          <Award className="w-8 h-8 text-muted-foreground/30 mx-auto mb-2" />
          <p className="text-xs text-muted-foreground">Complete a course to earn your first certificate!</p>
        </div>
      ) : (
        <div className="space-y-3">
          {CERTS.map((cert) => (
            <Link key={cert.id} href={`/dashboard/certificates/${cert.id}`} className="flex items-center gap-3 p-3 rounded-lg bg-secondary/30 hover:bg-secondary/50 transition-colors group">
              <div className="w-9 h-9 bg-amber-500/20 rounded-lg flex items-center justify-center shrink-0">
                <Award className="w-5 h-5 text-amber-500" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium line-clamp-1 group-hover:text-primary transition-colors">{cert.courseTitle}</p>
                <p className="text-[10px] text-muted-foreground">{format(cert.issuedAt, 'MMM d, yyyy')}</p>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

/* ── Weekly Goal ── */
export function WeeklyGoal({ userId }: { userId?: string }) {
  const goal = 300; // minutes
  const achieved = 187;
  const pct = Math.min(100, Math.round((achieved / goal) * 100));

  return (
    <div className="bg-card border rounded-xl p-5">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Target className="w-4 h-4 text-primary" />
          <h3 className="font-display font-bold text-sm">Weekly Goal</h3>
        </div>
        <span className="text-xs text-muted-foreground">{achieved}/{goal} min</span>
      </div>
      <div className="progress-bar mb-2">
        <div className="progress-fill" style={{ width: `${pct}%` }} />
      </div>
      <p className="text-xs text-muted-foreground">{pct}% of weekly goal · {goal - achieved} min remaining</p>
      {pct >= 100 && (
        <div className="mt-2 text-xs text-primary font-medium flex items-center gap-1">
          <Trophy className="w-3.5 h-3.5" /> Weekly goal achieved! 🎉
        </div>
      )}
    </div>
  );
}

/* ── Featured Categories (homepage) ── */
const HOMEPAGE_CATS = [
  { name: 'Web Development', icon: '🌐', courses: 3420, color: 'from-blue-500/20 to-blue-600/10', slug: 'web-development' },
  { name: 'Data Science', icon: '📊', courses: 2180, color: 'from-violet-500/20 to-violet-600/10', slug: 'data-science' },
  { name: 'AI & Machine Learning', icon: '🤖', courses: 1890, color: 'from-emerald-500/20 to-emerald-600/10', slug: 'ai-ml' },
  { name: 'UI/UX Design', icon: '🎨', courses: 1560, color: 'from-pink-500/20 to-pink-600/10', slug: 'design' },
  { name: 'Business', icon: '💼', courses: 2340, color: 'from-amber-500/20 to-amber-600/10', slug: 'business' },
  { name: 'Photography', icon: '📸', courses: 890, color: 'from-orange-500/20 to-orange-600/10', slug: 'photography' },
  { name: 'Music', icon: '🎵', courses: 720, color: 'from-teal-500/20 to-teal-600/10', slug: 'music' },
  { name: 'Marketing', icon: '📣', courses: 1340, color: 'from-red-500/20 to-red-600/10', slug: 'marketing' },
];

export function FeaturedCategories() {
  return (
    <section className="py-20 bg-secondary/20">
      <div className="container mx-auto px-4 max-w-7xl">
        <div className="flex items-end justify-between mb-10">
          <div>
            <Badge variant="secondary" className="mb-3 text-xs">Categories</Badge>
            <h2 className="text-3xl font-display font-bold">Browse top categories</h2>
          </div>
          <Button variant="ghost" asChild className="hidden sm:flex gap-1 text-primary">
            <Link href="/categories">All categories <ChevronRight className="w-4 h-4" /></Link>
          </Button>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {HOMEPAGE_CATS.map((cat, i) => (
            <Link key={cat.slug} href={`/courses?category=${cat.slug}`} className={cn('relative p-5 rounded-2xl bg-gradient-to-br border border-border/50 hover:border-primary/30 hover:shadow-md transition-all duration-200 cursor-pointer overflow-hidden group animate-fade-up', cat.color)} style={{ animationDelay: `${i * 60}ms` }}>
              <div className="text-3xl mb-3">{cat.icon}</div>
              <h3 className="font-display font-bold text-sm mb-1">{cat.name}</h3>
              <p className="text-xs text-muted-foreground">{cat.courses.toLocaleString()} courses</p>
              <ChevronRight className="absolute bottom-4 right-4 w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition-all" />
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ── Featured Courses (homepage) ── */
const FEAT_COURSES = [
  { id:'1', slug:'complete-react-developer', title:'The Complete React Developer Course', thumbnail:'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=400&h=225&fit=crop', price:89.99, discountPrice:14.99, isFree:false, level:'BEGINNER', durationMinutes:4380, totalStudents:94823, avgRating:4.7, totalReviews:18432, hasCertificate:true, tags:[], instructor:{user:{name:'Andrew Mead'}} },
  { id:'2', slug:'python-data-science', title:'Python for Data Science & Machine Learning', thumbnail:'https://images.unsplash.com/photo-1526379095098-d400fd0bf935?w=400&h=225&fit=crop', price:94.99, discountPrice:16.99, isFree:false, level:'INTERMEDIATE', durationMinutes:3720, totalStudents:82145, avgRating:4.6, totalReviews:12847, hasCertificate:true, tags:[], instructor:{user:{name:'Sarah Johnson'}} },
  { id:'3', slug:'aws-cloud-practitioner', title:'AWS Cloud Practitioner Certification Prep', thumbnail:'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=400&h=225&fit=crop', price:79.99, discountPrice:12.99, isFree:false, level:'BEGINNER', durationMinutes:1800, totalStudents:71230, avgRating:4.8, totalReviews:9231, hasCertificate:true, tags:[], instructor:{user:{name:'Mike Chen'}} },
  { id:'4', slug:'ui-ux-design-masterclass', title:'UI/UX Design Masterclass with Figma', thumbnail:'https://images.unsplash.com/photo-1558655146-9f40138edfeb?w=400&h=225&fit=crop', price:74.99, discountPrice:13.99, isFree:false, level:'ALL_LEVELS', durationMinutes:2160, totalStudents:65421, avgRating:4.5, totalReviews:8745, hasCertificate:true, tags:[], instructor:{user:{name:'Emma Wilson'}} },
  { id:'5', slug:'nextjs-fullstack', title:'Full-Stack Next.js 14 & React', thumbnail:'https://images.unsplash.com/photo-1627398242454-45a1465c2479?w=400&h=225&fit=crop', price:99.99, discountPrice:17.99, isFree:false, level:'INTERMEDIATE', durationMinutes:3060, totalStudents:58300, avgRating:4.7, totalReviews:7823, hasCertificate:true, tags:[], instructor:{user:{name:'Chris Lee'}} },
  { id:'6', slug:'machine-learning-az', title:'Machine Learning A–Z: Hands-On Python & R', thumbnail:'https://images.unsplash.com/photo-1509228468518-180b8ef8ade0?w=400&h=225&fit=crop', price:119.99, discountPrice:19.99, isFree:false, level:'INTERMEDIATE', durationMinutes:4500, totalStudents:112400, avgRating:4.8, totalReviews:24387, hasCertificate:true, tags:[], instructor:{user:{name:'Dr. Smith'}} },
];

export function FeaturedCourses() {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4 max-w-7xl">
        <div className="flex items-end justify-between mb-10">
          <div>
            <Badge variant="secondary" className="mb-3 text-xs">Featured</Badge>
            <h2 className="text-3xl font-display font-bold">Most popular courses</h2>
          </div>
          <Button variant="ghost" asChild className="hidden sm:flex gap-1 text-primary">
            <Link href="/courses">View all <ChevronRight className="w-4 h-4" /></Link>
          </Button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {FEAT_COURSES.map((course, i) => (
            <div key={course.id} className="animate-fade-up" style={{ animationDelay: `${i * 75}ms` }}>
              <CourseCard course={course as any} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ── Learning Paths (homepage) ── */
const PATHS = [
  { id:'1', title:'Full-Stack Web Developer', type:'CAREER_TRACK', courses:6, duration:'6 months', thumbnail:'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=400&h=200&fit=crop', enrolled:12400, color:'from-blue-600 to-violet-600' },
  { id:'2', title:'Data Scientist', type:'CERTIFICATE', courses:5, duration:'4 months', thumbnail:'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=200&fit=crop', enrolled:9800, color:'from-emerald-600 to-teal-600' },
  { id:'3', title:'AI / ML Engineer', type:'SPECIALIZATION', courses:8, duration:'8 months', thumbnail:'https://images.unsplash.com/photo-1677442135703-1787eea5ce01?w=400&h=200&fit=crop', enrolled:7600, color:'from-orange-600 to-red-600' },
];

export function LearningPaths() {
  return (
    <section className="py-20 bg-secondary/20">
      <div className="container mx-auto px-4 max-w-7xl">
        <div className="flex items-end justify-between mb-10">
          <div>
            <Badge variant="secondary" className="mb-3 text-xs">Learning Paths</Badge>
            <h2 className="text-3xl font-display font-bold">Structured career paths</h2>
            <p className="text-muted-foreground mt-2">Multi-course programs designed to get you job-ready</p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {PATHS.map((path, i) => (
            <Link key={path.id} href={`/learning-paths/${path.id}`} className="relative rounded-2xl overflow-hidden border hover:shadow-xl transition-all duration-300 group animate-fade-up" style={{ animationDelay: `${i * 100}ms` }}>
              <div className="relative h-36 overflow-hidden">
                <Image src={path.thumbnail} alt={path.title} fill className="object-cover group-hover:scale-105 transition-transform duration-500" />
                <div className={cn('absolute inset-0 bg-gradient-to-r opacity-80', path.color)} />
                <div className="absolute inset-0 flex flex-col justify-end p-4">
                  <Badge className="w-fit text-[10px] mb-2 bg-white/20 text-white border-0">{path.type.replace('_', ' ')}</Badge>
                  <h3 className="font-display font-bold text-white text-lg leading-tight">{path.title}</h3>
                </div>
              </div>
              <div className="p-4 bg-card">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-3 text-muted-foreground text-xs">
                    <span className="flex items-center gap-1"><BookOpen className="w-3 h-3" />{path.courses} courses</span>
                    <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{path.duration}</span>
                  </div>
                  <span className="flex items-center gap-1 text-xs text-muted-foreground"><TrendingUp className="w-3 h-3" />{path.enrolled.toLocaleString()}</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ── Stats Section (homepage) ── */
export function StatsSection() {
  const STATS = [
    { value: '4M+', label: 'Active learners', icon: '👥' },
    { value: '15K+', label: 'Expert courses', icon: '📚' },
    { value: '500K+', label: 'Certificates issued', icon: '🎓' },
    { value: '98%', label: 'Satisfaction rate', icon: '⭐' },
  ];
  return (
    <section className="py-16 border-y bg-card">
      <div className="container mx-auto px-4 max-w-5xl">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          {STATS.map((s) => (
            <div key={s.label} className="animate-fade-up">
              <div className="text-3xl mb-2">{s.icon}</div>
              <div className="text-3xl font-display font-bold gradient-text">{s.value}</div>
              <div className="text-sm text-muted-foreground mt-1">{s.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ── Instructors Section (homepage) ── */
const INSTRUCTORS = [
  { name: 'Andrew Mead', headline: 'Full-Stack Developer & Teacher', students: 283451, courses: 12, rating: 4.8, image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop&crop=face' },
  { name: 'Sarah Johnson', headline: 'Data Scientist at Google', students: 194320, courses: 8, rating: 4.9, image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop&crop=face' },
  { name: 'Mike Chen', headline: 'AWS Certified Solutions Architect', students: 156700, courses: 6, rating: 4.8, image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=face' },
  { name: 'Emma Wilson', headline: 'Lead UX Designer at Meta', students: 134200, courses: 9, rating: 4.7, image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&h=200&fit=crop&crop=face' },
];

export function InstructorsSection() {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4 max-w-7xl">
        <div className="text-center mb-12">
          <Badge variant="secondary" className="mb-3 text-xs">Instructors</Badge>
          <h2 className="text-3xl font-display font-bold mb-3">Learn from the best</h2>
          <p className="text-muted-foreground">World-class instructors with real industry experience</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {INSTRUCTORS.map((inst, i) => (
            <Link key={inst.name} href="/instructors" className="bg-card border rounded-2xl p-6 text-center hover:border-primary/30 hover:shadow-md transition-all group animate-fade-up" style={{ animationDelay: `${i * 75}ms` }}>
              <div className="relative w-20 h-20 mx-auto mb-4">
                <Image src={inst.image} alt={inst.name} fill className="rounded-full object-cover" />
                <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-primary rounded-full flex items-center justify-center">
                  <Star className="w-3 h-3 text-white fill-white" />
                </div>
              </div>
              <h3 className="font-display font-bold group-hover:text-primary transition-colors">{inst.name}</h3>
              <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{inst.headline}</p>
              <div className="flex items-center justify-center gap-3 mt-3 text-xs text-muted-foreground">
                <span className="flex items-center gap-0.5 text-amber-500 font-semibold"><Star className="w-2.5 h-2.5 fill-amber-500" />{inst.rating}</span>
                <span>{inst.students.toLocaleString()} students</span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ── Testimonials Section (homepage) ── */
const TESTIMONIALS = [
  { name: 'James Rodriguez', role: 'Frontend Developer at Shopify', quote: 'LearnForge completely changed my career trajectory. I went from zero coding knowledge to landing my dream job in 8 months.', avatar: 'JR', rating: 5 },
  { name: 'Priya Patel', role: 'Data Scientist at Netflix', quote: 'The Python and ML courses here are absolutely world-class. The AI assistant helped me through the toughest concepts.', avatar: 'PP', rating: 5 },
  { name: 'Tom Wilson', role: 'Indie SaaS Founder', quote: 'I built my entire SaaS product using skills from LearnForge. The certificate I earned opened doors I never thought possible.', avatar: 'TW', rating: 5 },
];

export function TestimonialsSection() {
  return (
    <section className="py-20 bg-secondary/10">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-display font-bold mb-3">What our students say</h2>
          <p className="text-muted-foreground">Join millions of learners worldwide</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((t, i) => (
            <div key={t.name} className="bg-card border rounded-2xl p-6 hover:border-primary/20 hover:shadow-md transition-all animate-fade-up" style={{ animationDelay: `${i * 100}ms` }}>
              <div className="flex gap-0.5 mb-4">
                {[...Array(t.rating)].map((_, j) => <Star key={j} className="w-4 h-4 fill-amber-400 text-amber-400" />)}
              </div>
              <blockquote className="text-sm text-muted-foreground leading-relaxed mb-5">&ldquo;{t.quote}&rdquo;</blockquote>
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 bg-primary/20 rounded-full flex items-center justify-center font-bold text-primary text-sm shrink-0">{t.avatar}</div>
                <div>
                  <p className="text-sm font-semibold">{t.name}</p>
                  <p className="text-xs text-muted-foreground">{t.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
