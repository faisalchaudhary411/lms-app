'use client';

import { BookOpen, Clock, Trophy, Flame, TrendingUp, Star } from 'lucide-react';
import { cn } from '@/lib/utils';

// In a real app, these would be fetched server-side
const MOCK_STATS = [
  {
    label: 'Courses Enrolled',
    value: '12',
    change: '+2 this month',
    trend: 'up',
    icon: BookOpen,
    color: 'text-blue-500',
    bg: 'bg-blue-500/10',
  },
  {
    label: 'Hours Learned',
    value: '247',
    change: '+18 this week',
    trend: 'up',
    icon: Clock,
    color: 'text-violet-500',
    bg: 'bg-violet-500/10',
  },
  {
    label: 'Certificates',
    value: '5',
    change: '+1 new',
    trend: 'up',
    icon: Trophy,
    color: 'text-amber-500',
    bg: 'bg-amber-500/10',
  },
  {
    label: 'Learning Streak',
    value: '7 days',
    change: 'Personal best!',
    trend: 'up',
    icon: Flame,
    color: 'text-orange-500',
    bg: 'bg-orange-500/10',
  },
  {
    label: 'Avg Quiz Score',
    value: '87%',
    change: '+5% improvement',
    trend: 'up',
    icon: Star,
    color: 'text-primary',
    bg: 'bg-primary/10',
  },
  {
    label: 'XP Points',
    value: '4,820',
    change: 'Level 12',
    trend: 'up',
    icon: TrendingUp,
    color: 'text-teal-500',
    bg: 'bg-teal-500/10',
  },
];

export function DashboardStats({ userId }: { userId?: string }) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
      {MOCK_STATS.map((stat, i) => (
        <div
          key={stat.label}
          className="bg-card border rounded-xl p-4 hover:border-primary/30 transition-all duration-200 animate-fade-up"
          style={{ animationDelay: `${i * 50}ms` }}
        >
          <div className={cn('w-8 h-8 rounded-lg flex items-center justify-center mb-3', stat.bg)}>
            <stat.icon className={cn('w-4 h-4', stat.color)} />
          </div>
          <div className="text-xl font-display font-bold">{stat.value}</div>
          <div className="text-xs text-muted-foreground mt-0.5">{stat.label}</div>
          <div className={cn('text-xs mt-1 font-medium', stat.color)}>{stat.change}</div>
        </div>
      ))}
    </div>
  );
}
