'use client';

import Image from 'next/image';
import Link from 'next/link';
import { Play, ChevronRight, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const MOCK_IN_PROGRESS = [
  {
    id: '1',
    title: 'Complete React Developer in 2024',
    instructor: 'John Smith',
    thumbnail: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=400&h=225&fit=crop',
    progress: 68,
    currentLesson: 'React Hooks Deep Dive',
    nextUp: 'useCallback & useMemo',
    timeLeft: '4h 32m left',
    href: '/learn/complete-react-developer/lesson/react-hooks-deep-dive',
  },
  {
    id: '2',
    title: 'Python for Data Science & Machine Learning',
    instructor: 'Sarah Johnson',
    thumbnail: 'https://images.unsplash.com/photo-1526379095098-d400fd0bf935?w=400&h=225&fit=crop',
    progress: 34,
    currentLesson: 'NumPy Arrays & Operations',
    nextUp: 'Pandas DataFrames',
    timeLeft: '12h 15m left',
    href: '/learn/python-data-science/lesson/numpy-arrays',
  },
  {
    id: '3',
    title: 'AWS Cloud Practitioner Certification',
    instructor: 'Mike Chen',
    thumbnail: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=400&h=225&fit=crop',
    progress: 85,
    currentLesson: 'EC2 Auto Scaling',
    nextUp: 'Final Exam Prep',
    timeLeft: '1h 45m left',
    href: '/learn/aws-cloud-practitioner/lesson/ec2-auto-scaling',
  },
];

export function ContinueLearning({ userId }: { userId?: string }) {
  return (
    <div className="bg-card border rounded-xl p-6">
      <div className="flex items-center justify-between mb-5">
        <div>
          <h2 className="text-lg font-display font-bold">Continue Learning</h2>
          <p className="text-sm text-muted-foreground mt-0.5">Pick up where you left off</p>
        </div>
        <Button variant="ghost" size="sm" className="gap-1 text-primary" asChild>
          <Link href="/dashboard/my-courses">
            View all <ChevronRight className="w-3.5 h-3.5" />
          </Link>
        </Button>
      </div>

      <div className="space-y-4">
        {MOCK_IN_PROGRESS.map((course, i) => (
          <Link
            key={course.id}
            href={course.href}
            className="flex gap-4 p-3 rounded-xl hover:bg-secondary/50 transition-colors group"
          >
            {/* Thumbnail */}
            <div className="relative w-28 h-16 rounded-lg overflow-hidden shrink-0 bg-secondary">
              <Image
                src={course.thumbnail}
                alt={course.title}
                fill
                className="object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="w-8 h-8 bg-white/90 rounded-full flex items-center justify-center">
                  <Play className="w-4 h-4 text-black fill-black ml-0.5" />
                </div>
              </div>
            </div>

            {/* Info */}
            <div className="flex-1 min-w-0">
              <h3 className="text-sm font-semibold line-clamp-1 group-hover:text-primary transition-colors">
                {course.title}
              </h3>
              <p className="text-xs text-muted-foreground mt-0.5 truncate">
                Next: {course.nextUp}
              </p>

              {/* Progress */}
              <div className="mt-2 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">{course.progress}% complete</span>
                  <span className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Clock className="w-3 h-3" />
                    {course.timeLeft}
                  </span>
                </div>
                <div className="progress-bar h-1.5">
                  <div
                    className="progress-fill"
                    style={{ width: `${course.progress}%` }}
                  />
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
