'use client';

import { useEffect, useState } from 'react';
import { format } from 'date-fns';
import {
  Bell, X, Check, CheckCheck, BookOpen, Award, MessageSquare,
  Calendar, AlertCircle, Megaphone, ExternalLink
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import Link from 'next/link';

interface Notification {
  id: string;
  type: string;
  title: string;
  message: string;
  link?: string;
  isRead: boolean;
  createdAt: string;
}

const TYPE_ICONS: Record<string, any> = {
  COURSE_UPDATE: BookOpen,
  DEADLINE_REMINDER: Calendar,
  NEW_ANNOUNCEMENT: Megaphone,
  ASSIGNMENT_GRADED: CheckCheck,
  CERTIFICATE_EARNED: Award,
  REPLY_TO_POST: MessageSquare,
  ENROLLMENT_CONFIRMED: BookOpen,
  LIVE_CLASS_STARTING: AlertCircle,
};

const TYPE_COLORS: Record<string, string> = {
  COURSE_UPDATE: 'text-blue-500 bg-blue-500/10',
  DEADLINE_REMINDER: 'text-amber-500 bg-amber-500/10',
  NEW_ANNOUNCEMENT: 'text-violet-500 bg-violet-500/10',
  ASSIGNMENT_GRADED: 'text-primary bg-primary/10',
  CERTIFICATE_EARNED: 'text-amber-500 bg-amber-500/10',
  REPLY_TO_POST: 'text-blue-500 bg-blue-500/10',
  ENROLLMENT_CONFIRMED: 'text-primary bg-primary/10',
  LIVE_CLASS_STARTING: 'text-red-500 bg-red-500/10',
};

interface Props {
  open: boolean;
  onClose: () => void;
}

export function NotificationsPanel({ open, onClose }: Props) {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open) fetchNotifications();
  }, [open]);

  const fetchNotifications = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/notifications');
      const data = await res.json();
      setNotifications(data.notifications || []);
      setUnreadCount(data.unreadCount || 0);
    } catch {}
    finally { setLoading(false); }
  };

  const markAllRead = async () => {
    await fetch('/api/notifications', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ markAll: true }),
    });
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
    setUnreadCount(0);
  };

  const markRead = async (id: string) => {
    await fetch('/api/notifications', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ids: [id] }),
    });
    setNotifications((prev) => prev.map((n) => n.id === id ? { ...n, isRead: true } : n));
    setUnreadCount((c) => Math.max(0, c - 1));
  };

  // Mock data for preview
  const MOCK: Notification[] = [
    { id: '1', type: 'CERTIFICATE_EARNED', title: '🎉 Certificate earned!', message: 'You completed "Complete React Developer Course"', link: '/dashboard/certificates', isRead: false, createdAt: new Date(Date.now() - 1000 * 60 * 5).toISOString() },
    { id: '2', type: 'ASSIGNMENT_GRADED', title: 'Assignment graded', message: 'Your "React Hooks" assignment received 92/100 points', link: '/dashboard/my-courses', isRead: false, createdAt: new Date(Date.now() - 1000 * 60 * 60).toISOString() },
    { id: '3', type: 'DEADLINE_REMINDER', title: 'Deadline tomorrow', message: 'Your Python Data Science assignment is due in 24 hours', link: '/dashboard/my-courses', isRead: true, createdAt: new Date(Date.now() - 1000 * 60 * 60 * 3).toISOString() },
    { id: '4', type: 'REPLY_TO_POST', title: 'New reply', message: 'An instructor replied to your question in React Hooks Deep Dive', link: '/courses/react/discussion/1', isRead: true, createdAt: new Date(Date.now() - 1000 * 60 * 60 * 8).toISOString() },
    { id: '5', type: 'LIVE_CLASS_STARTING', title: 'Live class starting soon', message: '"Advanced TypeScript Patterns" starts in 15 minutes!', link: '/live', isRead: true, createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString() },
  ];

  const displayNotifications = notifications.length > 0 ? notifications : MOCK;
  const displayUnread = notifications.length > 0 ? unreadCount : 2;

  if (!open) return null;

  return (
    <>
      {/* Backdrop */}
      <div className="fixed inset-0 z-40" onClick={onClose} />

      {/* Panel */}
      <div className="fixed top-16 right-4 w-96 max-h-[calc(100vh-5rem)] bg-card border rounded-2xl shadow-2xl z-50 flex flex-col overflow-hidden animate-fade-up">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b">
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4 text-primary" />
            <h3 className="font-display font-bold text-sm">Notifications</h3>
            {displayUnread > 0 && (
              <Badge className="text-[10px] h-4 min-w-4 bg-primary/10 text-primary border-0">
                {displayUnread}
              </Badge>
            )}
          </div>
          <div className="flex items-center gap-1">
            {displayUnread > 0 && (
              <Button variant="ghost" size="sm" className="h-7 text-xs gap-1" onClick={markAllRead}>
                <Check className="w-3 h-3" />
                Mark all read
              </Button>
            )}
            <Button variant="ghost" size="icon" className="w-7 h-7" onClick={onClose}>
              <X className="w-3.5 h-3.5" />
            </Button>
          </div>
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto">
          {loading ? (
            <div className="p-4 space-y-3">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="flex gap-3">
                  <div className="w-9 h-9 rounded-xl shimmer shrink-0" />
                  <div className="flex-1 space-y-2">
                    <div className="h-3 w-3/4 shimmer rounded" />
                    <div className="h-3 w-full shimmer rounded" />
                  </div>
                </div>
              ))}
            </div>
          ) : displayNotifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12">
              <Bell className="w-8 h-8 text-muted-foreground mb-3" />
              <p className="text-sm text-muted-foreground">No notifications yet</p>
            </div>
          ) : (
            <div>
              {displayNotifications.map((notif) => {
                const Icon = TYPE_ICONS[notif.type] || Bell;
                const colors = TYPE_COLORS[notif.type] || 'text-muted-foreground bg-secondary';

                return (
                  <div
                    key={notif.id}
                    className={cn(
                      'flex gap-3 p-4 border-b last:border-0 cursor-pointer hover:bg-secondary/30 transition-colors',
                      !notif.isRead && 'bg-primary/[0.02]'
                    )}
                    onClick={() => { if (!notif.isRead) markRead(notif.id); }}
                  >
                    {/* Icon */}
                    <div className={cn('w-9 h-9 rounded-xl flex items-center justify-center shrink-0', colors)}>
                      <Icon className="w-4 h-4" />
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <p className={cn('text-sm font-medium line-clamp-1', !notif.isRead && 'text-foreground')}>
                          {notif.title}
                        </p>
                        {!notif.isRead && (
                          <div className="w-2 h-2 bg-primary rounded-full shrink-0 mt-1.5" />
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2 leading-relaxed">
                        {notif.message}
                      </p>
                      <div className="flex items-center justify-between mt-1.5">
                        <span className="text-[10px] text-muted-foreground">
                          {format(new Date(notif.createdAt), 'MMM d, h:mm a')}
                        </span>
                        {notif.link && (
                          <Link
                            href={notif.link}
                            onClick={(e) => e.stopPropagation()}
                            className="text-[10px] text-primary hover:underline flex items-center gap-0.5"
                          >
                            View <ExternalLink className="w-2.5 h-2.5" />
                          </Link>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 border-t">
          <Link
            href="/dashboard/notifications"
            onClick={onClose}
            className="flex items-center justify-center text-xs text-primary hover:underline"
          >
            View all notifications
          </Link>
        </div>
      </div>
    </>
  );
}
