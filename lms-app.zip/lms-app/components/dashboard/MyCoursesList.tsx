'use client';

import { useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import {
  Play, Clock, CheckCircle2, BarChart2, Award, BookOpen,
  Search, Filter, LayoutGrid, List
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { cn, formatMinutes } from '@/lib/utils';

const MOCK_ENROLLMENTS = [
  {
    id: 'e1', progress: 68, isCompleted: false, lastAccessedAt: new Date(Date.now() - 1000 * 60 * 30),
    course: { id: '1', slug: 'complete-react-developer', title: 'The Complete React Developer Course', thumbnail: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=400&h=225&fit=crop', durationMinutes: 4380, totalLessons: 312, level: 'BEGINNER', instructor: { user: { name: 'Andrew Mead' } }, category: { name: 'Web Dev' } },
    completedLessons: 212, totalTimeSpent: 14220,
  },
  {
    id: 'e2', progress: 34, isCompleted: false, lastAccessedAt: new Date(Date.now() - 1000 * 60 * 60 * 5),
    course: { id: '2', slug: 'python-data-science', title: 'Python for Data Science & Machine Learning', thumbnail: 'https://images.unsplash.com/photo-1526379095098-d400fd0bf935?w=400&h=225&fit=crop', durationMinutes: 3720, totalLessons: 240, level: 'INTERMEDIATE', instructor: { user: { name: 'Sarah Johnson' } }, category: { name: 'Data Science' } },
    completedLessons: 82, totalTimeSpent: 6528,
  },
  {
    id: 'e3', progress: 100, isCompleted: true, lastAccessedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 7),
    course: { id: '3', slug: 'javascript-fundamentals', title: 'JavaScript: The Complete Guide 2024', thumbnail: 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=400&h=225&fit=crop', durationMinutes: 5220, totalLessons: 390, level: 'BEGINNER', instructor: { user: { name: 'Maximilian S.' } }, category: { name: 'Web Dev' } },
    completedLessons: 390, totalTimeSpent: 28800,
  },
  {
    id: 'e4', progress: 85, isCompleted: false, lastAccessedAt: new Date(Date.now() - 1000 * 60 * 60 * 2),
    course: { id: '4', slug: 'aws-cloud-practitioner', title: 'AWS Cloud Practitioner Certification', thumbnail: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=400&h=225&fit=crop', durationMinutes: 1800, totalLessons: 120, level: 'BEGINNER', instructor: { user: { name: 'Mike Chen' } }, category: { name: 'Cloud' } },
    completedLessons: 102, totalTimeSpent: 9180,
  },
  {
    id: 'e5', progress: 12, isCompleted: false, lastAccessedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2),
    course: { id: '5', slug: 'ui-ux-design', title: 'UI/UX Design Masterclass with Figma', thumbnail: 'https://images.unsplash.com/photo-1558655146-9f40138edfeb?w=400&h=225&fit=crop', durationMinutes: 2160, totalLessons: 148, level: 'ALL_LEVELS', instructor: { user: { name: 'Emma Wilson' } }, category: { name: 'Design' } },
    completedLessons: 18, totalTimeSpent: 1560,
  },
];

type FilterType = 'all' | 'in-progress' | 'completed' | 'not-started';
type ViewType = 'grid' | 'list';

export function MyCoursesList({ userId }: { userId?: string }) {
  const [filter, setFilter] = useState<FilterType>('all');
  const [search, setSearch] = useState('');
  const [view, setView] = useState<ViewType>('grid');

  const filtered = MOCK_ENROLLMENTS.filter((e) => {
    const matchSearch = e.course.title.toLowerCase().includes(search.toLowerCase());
    const matchFilter =
      filter === 'all' ||
      (filter === 'completed' && e.isCompleted) ||
      (filter === 'in-progress' && !e.isCompleted && e.progress > 0) ||
      (filter === 'not-started' && e.progress === 0);
    return matchSearch && matchFilter;
  });

  const counts = {
    all: MOCK_ENROLLMENTS.length,
    'in-progress': MOCK_ENROLLMENTS.filter((e) => !e.isCompleted && e.progress > 0).length,
    completed: MOCK_ENROLLMENTS.filter((e) => e.isCompleted).length,
    'not-started': MOCK_ENROLLMENTS.filter((e) => e.progress === 0).length,
  };

  return (
    <div>
      {/* Controls */}
      <div className="flex flex-wrap items-center gap-3 mb-6">
        {/* Filter tabs */}
        <div className="flex items-center bg-secondary rounded-xl p-1 gap-0.5">
          {(['all', 'in-progress', 'completed', 'not-started'] as FilterType[]).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                'px-3 py-1.5 text-xs font-medium rounded-lg transition-all capitalize',
                filter === f ? 'bg-card shadow-sm text-foreground' : 'text-muted-foreground hover:text-foreground'
              )}
            >
              {f.replace('-', ' ')} ({counts[f]})
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search your courses..."
            className="pl-9 h-9 text-sm"
          />
        </div>

        {/* View toggle */}
        <div className="flex items-center gap-1 bg-secondary rounded-xl p-1">
          {([{ id: 'grid', Icon: LayoutGrid }, { id: 'list', Icon: List }] as const).map(({ id, Icon }) => (
            <button
              key={id}
              onClick={() => setView(id as ViewType)}
              className={cn(
                'w-8 h-7 flex items-center justify-center rounded-lg transition-all',
                view === id ? 'bg-card shadow-sm text-foreground' : 'text-muted-foreground hover:text-foreground'
              )}
            >
              <Icon className="w-3.5 h-3.5" />
            </button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-20 border rounded-xl">
          <BookOpen className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
          <p className="font-semibold mb-1">No courses found</p>
          <p className="text-sm text-muted-foreground mb-5">
            {search ? 'Try a different search term' : 'Start learning by enrolling in a course'}
          </p>
          <Button asChild>
            <Link href="/courses">Browse Courses</Link>
          </Button>
        </div>
      ) : view === 'grid' ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5">
          {filtered.map((enrollment) => (
            <CourseEnrollmentCard key={enrollment.id} enrollment={enrollment} />
          ))}
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((enrollment) => (
            <CourseEnrollmentRow key={enrollment.id} enrollment={enrollment} />
          ))}
        </div>
      )}
    </div>
  );
}

function CourseEnrollmentCard({ enrollment }: { enrollment: (typeof MOCK_ENROLLMENTS)[0] }) {
  const { course, progress, isCompleted, completedLessons, totalTimeSpent } = enrollment;

  return (
    <div className="bg-card border rounded-xl overflow-hidden hover:border-primary/30 hover:shadow-md transition-all group">
      {/* Thumbnail */}
      <div className="relative aspect-video overflow-hidden bg-secondary">
        <Image src={course.thumbnail} alt={course.title} fill className="object-cover group-hover:scale-105 transition-transform duration-300" />
        {isCompleted && (
          <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
            <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
              <CheckCircle2 className="w-6 h-6 text-white" />
            </div>
          </div>
        )}
        <div className="absolute top-2 right-2">
          <Badge className={cn('text-[10px] border-0', isCompleted ? 'bg-primary text-primary-foreground' : progress > 0 ? 'bg-blue-500/80 text-white' : 'bg-secondary text-muted-foreground')}>
            {isCompleted ? 'Completed' : progress > 0 ? `${progress}%` : 'Not Started'}
          </Badge>
        </div>
      </div>

      <div className="p-4">
        <h3 className="font-semibold text-sm leading-snug line-clamp-2 mb-1 group-hover:text-primary transition-colors">
          {course.title}
        </h3>
        <p className="text-xs text-muted-foreground mb-3">{course.instructor.user.name}</p>

        {/* Progress */}
        <div className="mb-3">
          <div className="flex justify-between text-xs text-muted-foreground mb-1">
            <span>{completedLessons}/{course.totalLessons} lessons</span>
            <span className="flex items-center gap-1">
              <Clock className="w-2.5 h-2.5" />
              {formatMinutes(Math.round(totalTimeSpent / 60))} spent
            </span>
          </div>
          <div className="progress-bar">
            <div className="progress-fill" style={{ width: `${progress}%` }} />
          </div>
        </div>

        <Button
          size="sm"
          variant={isCompleted ? 'outline' : 'default'}
          className="w-full gap-2"
          asChild
        >
          <Link href={`/learn/${course.slug}`}>
            {isCompleted ? (
              <><Award className="w-3.5 h-3.5" />View Certificate</>
            ) : (
              <><Play className="w-3.5 h-3.5 fill-current" />{progress > 0 ? 'Continue' : 'Start Learning'}</>
            )}
          </Link>
        </Button>
      </div>
    </div>
  );
}

function CourseEnrollmentRow({ enrollment }: { enrollment: (typeof MOCK_ENROLLMENTS)[0] }) {
  const { course, progress, isCompleted, completedLessons } = enrollment;

  return (
    <div className="bg-card border rounded-xl p-4 flex items-center gap-4 hover:border-primary/30 transition-all group">
      <div className="relative w-20 h-14 rounded-lg overflow-hidden bg-secondary shrink-0">
        <Image src={course.thumbnail} alt={course.title} fill className="object-cover" />
      </div>

      <div className="flex-1 min-w-0">
        <h3 className="font-medium text-sm line-clamp-1 group-hover:text-primary transition-colors">{course.title}</h3>
        <p className="text-xs text-muted-foreground">{course.instructor.user.name}</p>
        <div className="flex items-center gap-4 mt-1.5">
          <div className="flex items-center gap-2 min-w-0 flex-1">
            <div className="progress-bar flex-1 max-w-32">
              <div className="progress-fill" style={{ width: `${progress}%` }} />
            </div>
            <span className="text-xs text-muted-foreground whitespace-nowrap">{progress}%</span>
          </div>
          <span className="text-xs text-muted-foreground whitespace-nowrap hidden sm:block">
            {completedLessons}/{course.totalLessons} lessons
          </span>
        </div>
      </div>

      <div className="shrink-0">
        <Button size="sm" variant={isCompleted ? 'outline' : 'default'} className="gap-1.5" asChild>
          <Link href={`/learn/${course.slug}`}>
            <Play className="w-3 h-3 fill-current" />
            {isCompleted ? 'Review' : progress > 0 ? 'Continue' : 'Start'}
          </Link>
        </Button>
      </div>
    </div>
  );
}
