'use client';

import { useState } from 'react';
import Link from 'next/link';
import {
  Award, Download, Share2, Linkedin, ExternalLink,
  Copy, Check, Search, GraduationCap
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import toast from 'react-hot-toast';

const MOCK_CERTIFICATES = [
  {
    id: 'cert-1',
    verificationId: 'LF-2024-REACT-001',
    issuedAt: new Date('2024-02-10'),
    skills: ['React', 'JavaScript', 'Hooks', 'Redux', 'TypeScript'],
    course: {
      title: 'The Complete React Developer Course',
      instructor: { user: { name: 'Andrew Mead' } },
      durationMinutes: 4380,
      category: { name: 'Web Development' },
    },
  },
  {
    id: 'cert-2',
    verificationId: 'LF-2024-JS-002',
    issuedAt: new Date('2024-01-20'),
    skills: ['JavaScript', 'ES6+', 'Async/Await', 'DOM'],
    course: {
      title: 'JavaScript: The Complete Guide 2024',
      instructor: { user: { name: 'Maximilian S.' } },
      durationMinutes: 5220,
      category: { name: 'Web Development' },
    },
  },
  {
    id: 'cert-3',
    verificationId: 'LF-2024-GIT-003',
    issuedAt: new Date('2024-01-05'),
    skills: ['Git', 'GitHub', 'Version Control'],
    course: {
      title: 'Git & GitHub Masterclass',
      instructor: { user: { name: 'Colt Steele' } },
      durationMinutes: 900,
      category: { name: 'Developer Tools' },
    },
  },
];

export function CertificatesList() {
  const [search, setSearch] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filtered = MOCK_CERTIFICATES.filter((c) =>
    c.course.title.toLowerCase().includes(search.toLowerCase())
  );

  const copyVerificationId = (id: string, verificationId: string) => {
    navigator.clipboard.writeText(verificationId);
    setCopiedId(id);
    toast.success('Verification ID copied!');
    setTimeout(() => setCopiedId(null), 2000);
  };

  const shareOnLinkedIn = (cert: (typeof MOCK_CERTIFICATES)[0]) => {
    const verifyUrl = `${process.env.NEXT_PUBLIC_URL}/certificates/verify/${cert.verificationId}`;
    const params = new URLSearchParams({
      startTask: 'CERTIFICATION_NAME',
      name: cert.course.title,
      organizationId: '0',
      issueYear: new Date(cert.issuedAt).getFullYear().toString(),
      issueMonth: (new Date(cert.issuedAt).getMonth() + 1).toString(),
      certUrl: verifyUrl,
      certId: cert.verificationId,
    });
    window.open(`https://www.linkedin.com/profile/add?${params.toString()}`, '_blank');
  };

  return (
    <div className="space-y-6">
      {/* Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {[
          { label: 'Total Certificates', value: MOCK_CERTIFICATES.length, icon: Award, color: 'text-amber-500', bg: 'bg-amber-500/10' },
          { label: 'Skills Verified', value: [...new Set(MOCK_CERTIFICATES.flatMap((c) => c.skills))].length, icon: GraduationCap, color: 'text-primary', bg: 'bg-primary/10' },
          { label: 'Hours of Learning', value: Math.round(MOCK_CERTIFICATES.reduce((s, c) => s + c.course.durationMinutes, 0) / 60), icon: Award, color: 'text-blue-500', bg: 'bg-blue-500/10' },
        ].map((stat) => (
          <div key={stat.label} className="bg-card border rounded-xl p-4 flex items-center gap-4">
            <div className={cn('w-10 h-10 rounded-xl flex items-center justify-center shrink-0', stat.bg)}>
              <stat.icon className={cn('w-5 h-5', stat.color)} />
            </div>
            <div>
              <div className="text-2xl font-display font-bold">{stat.value}</div>
              <div className="text-sm text-muted-foreground">{stat.label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Search */}
      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search certificates..."
          className="pl-9 h-9"
        />
      </div>

      {/* Certificates */}
      {filtered.length === 0 ? (
        <div className="text-center py-16 border rounded-xl">
          <Award className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
          <p className="font-semibold mb-1">No certificates found</p>
          <p className="text-sm text-muted-foreground mb-4">Complete a course to earn your first certificate</p>
          <Button asChild><Link href="/courses">Browse Courses</Link></Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {filtered.map((cert) => (
            <div key={cert.id} className="bg-card border rounded-2xl overflow-hidden hover:border-primary/30 hover:shadow-md transition-all">
              {/* Certificate preview strip */}
              <div className="relative p-6 bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-950/30 dark:to-teal-950/30 border-b">
                <div className="flex items-start gap-4">
                  <div className="w-14 h-14 bg-amber-500/20 border-2 border-amber-500/30 rounded-2xl flex items-center justify-center shrink-0">
                    <Award className="w-7 h-7 text-amber-500" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <Badge className="mb-1.5 text-[10px] bg-primary/10 text-primary border-0">
                      Certificate of Completion
                    </Badge>
                    <h3 className="font-display font-bold leading-snug line-clamp-2">
                      {cert.course.title}
                    </h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      {cert.course.instructor.user.name} · {format(cert.issuedAt, 'MMM d, yyyy')}
                    </p>
                  </div>
                </div>

                {/* Skills */}
                <div className="flex flex-wrap gap-1.5 mt-4">
                  {cert.skills.slice(0, 4).map((skill) => (
                    <span key={skill} className="px-2 py-0.5 bg-primary/10 text-primary text-[10px] font-medium rounded-full">
                      {skill}
                    </span>
                  ))}
                  {cert.skills.length > 4 && (
                    <span className="px-2 py-0.5 bg-secondary text-muted-foreground text-[10px] rounded-full">
                      +{cert.skills.length - 4} more
                    </span>
                  )}
                </div>
              </div>

              {/* Actions */}
              <div className="p-4 space-y-3">
                {/* Verification ID */}
                <div className="flex items-center gap-2 p-2.5 bg-secondary/50 rounded-lg">
                  <div className="flex-1 min-w-0">
                    <p className="text-[10px] text-muted-foreground">Verification ID</p>
                    <code className="text-xs font-mono font-semibold">{cert.verificationId}</code>
                  </div>
                  <button
                    onClick={() => copyVerificationId(cert.id, cert.verificationId)}
                    className="p-1.5 text-muted-foreground hover:text-foreground rounded-lg hover:bg-background transition-colors"
                  >
                    {copiedId === cert.id ? (
                      <Check className="w-3.5 h-3.5 text-primary" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>

                {/* Action buttons */}
                <div className="flex flex-wrap gap-2">
                  <Button size="sm" variant="outline" className="flex-1 gap-1.5 text-xs" onClick={() => shareOnLinkedIn(cert)}>
                    <Linkedin className="w-3.5 h-3.5 text-[#0077b5]" />
                    LinkedIn
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="flex-1 gap-1.5 text-xs"
                    onClick={() => {
                      navigator.clipboard.writeText(`${process.env.NEXT_PUBLIC_URL}/certificates/verify/${cert.verificationId}`);
                      toast.success('Link copied!');
                    }}
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    Share
                  </Button>
                  <Button size="sm" variant="outline" className="flex-1 gap-1.5 text-xs" asChild>
                    <Link href={`/certificates/verify/${cert.verificationId}`} target="_blank">
                      <ExternalLink className="w-3.5 h-3.5" />
                      Verify
                    </Link>
                  </Button>
                  <Button size="sm" className="flex-1 gap-1.5 text-xs">
                    <Download className="w-3.5 h-3.5" />
                    PDF
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
