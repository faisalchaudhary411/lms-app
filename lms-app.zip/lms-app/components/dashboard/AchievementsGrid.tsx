'use client';

import { useState } from 'react';
import { Trophy, Lock, Star, Zap, Flame, BookOpen, Award, Users, Target, TrendingUp } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { cn, getLevelProgress, getXPForNextLevel, getLevel } from '@/lib/utils';

const ALL_BADGES = [
  { id: 'first-lesson', name: 'First Step', description: 'Complete your first lesson', icon: '🎯', color: '#22c55e', xpReward: 50, earned: true, earnedAt: '2024-01-15', category: 'Learning' },
  { id: 'first-course', name: 'Course Crusher', description: 'Complete your first course', icon: '📚', color: '#3b82f6', xpReward: 200, earned: true, earnedAt: '2024-02-10', category: 'Learning' },
  { id: 'streak-7', name: 'Week Warrior', description: 'Maintain a 7-day learning streak', icon: '🔥', color: '#f97316', xpReward: 150, earned: true, earnedAt: '2024-03-05', category: 'Streaks' },
  { id: 'streak-30', name: 'Monthly Master', description: 'Maintain a 30-day learning streak', icon: '⚡', color: '#eab308', xpReward: 500, earned: false, category: 'Streaks' },
  { id: 'quiz-ace', name: 'Quiz Ace', description: 'Score 100% on any quiz', icon: '🏆', color: '#8b5cf6', xpReward: 100, earned: true, earnedAt: '2024-02-28', category: 'Performance' },
  { id: 'five-courses', name: 'Knowledge Seeker', description: 'Enroll in 5 courses', icon: '🎓', color: '#06b6d4', xpReward: 300, earned: false, category: 'Learning' },
  { id: 'first-cert', name: 'Certified!', description: 'Earn your first certificate', icon: '📜', color: '#f59e0b', xpReward: 400, earned: true, earnedAt: '2024-02-10', category: 'Milestones' },
  { id: 'night-owl', name: 'Night Owl', description: 'Complete 10 lessons after 10 PM', icon: '🦉', color: '#6366f1', xpReward: 100, earned: false, category: 'Special' },
  { id: 'speed-learner', name: 'Speed Learner', description: 'Complete a course in under 7 days', icon: '⚡', color: '#ec4899', xpReward: 250, earned: false, category: 'Performance' },
  { id: 'social-butterfly', name: 'Social Butterfly', description: 'Reply to 10 discussions', icon: '🦋', color: '#14b8a6', xpReward: 150, earned: false, category: 'Community' },
  { id: 'helpful', name: 'Helper', description: 'Get 50 upvotes on your posts', icon: '👍', color: '#22c55e', xpReward: 200, earned: false, category: 'Community' },
  { id: 'polyglot', name: 'Polyglot', description: 'Take courses in 3 different languages', icon: '🌍', color: '#f97316', xpReward: 200, earned: false, category: 'Special' },
];

const CATEGORIES = ['All', 'Learning', 'Streaks', 'Performance', 'Milestones', 'Community', 'Special'];

const XP_DATA = { current: 4820, level: 12 };

export function AchievementsGrid() {
  const [activeCategory, setActiveCategory] = useState('All');

  const earned = ALL_BADGES.filter((b) => b.earned);
  const filtered = ALL_BADGES.filter((b) =>
    activeCategory === 'All' || b.category === activeCategory
  );

  const levelProgress = getLevelProgress(XP_DATA.current);
  const nextLevelXP = getXPForNextLevel(XP_DATA.level);

  return (
    <div className="space-y-6">
      {/* XP Level card */}
      <div className="bg-gradient-to-r from-primary/10 via-emerald-500/5 to-background border rounded-2xl p-6">
        <div className="flex items-start justify-between gap-6">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-14 h-14 bg-primary rounded-2xl flex items-center justify-center text-2xl font-display font-bold text-primary-foreground shadow-lg shadow-primary/30">
                {XP_DATA.level}
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Current Level</p>
                <h2 className="text-xl font-display font-bold">Level {XP_DATA.level} Learner</h2>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">{XP_DATA.current.toLocaleString()} XP</span>
                <span className="text-muted-foreground">{nextLevelXP.toLocaleString()} XP to Level {XP_DATA.level + 1}</span>
              </div>
              <div className="h-3 bg-secondary rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-1000"
                  style={{
                    width: `${levelProgress}%`,
                    background: 'linear-gradient(90deg, hsl(142, 71%, 45%), hsl(160, 71%, 45%))',
                    boxShadow: '0 0 12px rgba(34, 197, 94, 0.4)',
                  }}
                />
              </div>
              <p className="text-xs text-muted-foreground">{levelProgress}% to next level</p>
            </div>
          </div>

          {/* Stats */}
          <div className="hidden sm:grid grid-cols-2 gap-3 shrink-0">
            {[
              { label: 'Badges Earned', value: earned.length, icon: Trophy, color: 'text-amber-500' },
              { label: 'Total XP', value: XP_DATA.current.toLocaleString(), icon: Zap, color: 'text-primary' },
              { label: 'Current Streak', value: '7 days', icon: Flame, color: 'text-orange-500' },
              { label: 'Courses Done', value: '5', icon: BookOpen, color: 'text-blue-500' },
            ].map((stat) => (
              <div key={stat.label} className="bg-card border rounded-xl p-3 text-center">
                <stat.icon className={cn('w-4 h-4 mx-auto mb-1', stat.color)} />
                <div className="text-base font-bold">{stat.value}</div>
                <div className="text-[10px] text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent XP gains */}
      <div className="bg-card border rounded-xl p-5">
        <h3 className="font-display font-bold text-sm mb-4">Recent XP Activity</h3>
        <div className="space-y-2">
          {[
            { event: 'Completed "React Hooks Deep Dive"', xp: '+10 XP', time: '2 hours ago', color: 'text-primary' },
            { event: 'Quiz: 95% score on Components Quiz', xp: '+25 XP', time: '5 hours ago', color: 'text-primary' },
            { event: 'Badge: Week Warrior earned!', xp: '+150 XP', time: '1 day ago', color: 'text-amber-500' },
            { event: 'Assignment graded: 92/100', xp: '+20 XP', time: '2 days ago', color: 'text-primary' },
          ].map((item, i) => (
            <div key={i} className="flex items-center justify-between py-2 border-b last:border-0">
              <p className="text-sm text-muted-foreground">{item.event}</p>
              <span className={cn('text-sm font-bold', item.color)}>{item.xp}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Badges */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display font-bold">Badges & Achievements</h2>
          <span className="text-sm text-muted-foreground">{earned.length}/{ALL_BADGES.length} earned</span>
        </div>

        {/* Category filter */}
        <div className="flex gap-2 overflow-x-auto scrollbar-hide mb-5 pb-1">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={cn(
                'px-3 py-1.5 text-xs font-medium rounded-full border whitespace-nowrap transition-all',
                activeCategory === cat
                  ? 'bg-primary text-primary-foreground border-primary'
                  : 'border-border hover:border-primary/40 text-muted-foreground'
              )}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
          {filtered.map((badge) => (
            <div
              key={badge.id}
              className={cn(
                'relative bg-card border rounded-2xl p-4 text-center transition-all duration-200',
                badge.earned
                  ? 'hover:border-primary/30 hover:shadow-md hover:-translate-y-0.5 cursor-pointer'
                  : 'opacity-50 grayscale'
              )}
            >
              {badge.earned && (
                <div className="absolute -top-1.5 -right-1.5">
                  <div className="w-5 h-5 bg-primary rounded-full flex items-center justify-center shadow-sm">
                    <Star className="w-2.5 h-2.5 text-white fill-white" />
                  </div>
                </div>
              )}

              {/* Badge icon */}
              <div
                className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl mx-auto mb-3 transition-all"
                style={{
                  backgroundColor: badge.earned ? `${badge.color}20` : 'hsl(var(--secondary))',
                  border: badge.earned ? `2px solid ${badge.color}40` : '2px solid transparent',
                  boxShadow: badge.earned ? `0 0 16px ${badge.color}30` : 'none',
                }}
              >
                {badge.earned ? badge.icon : <Lock className="w-6 h-6 text-muted-foreground" />}
              </div>

              <h4 className="text-xs font-semibold mb-0.5 line-clamp-1">{badge.name}</h4>
              <p className="text-[10px] text-muted-foreground leading-relaxed line-clamp-2 mb-2">
                {badge.description}
              </p>

              <div className="flex items-center justify-center gap-1">
                <Zap className="w-2.5 h-2.5 text-primary" />
                <span className="text-[10px] font-semibold text-primary">{badge.xpReward} XP</span>
              </div>

              {badge.earned && badge.earnedAt && (
                <p className="text-[10px] text-muted-foreground mt-1">
                  {new Date(badge.earnedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                </p>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
