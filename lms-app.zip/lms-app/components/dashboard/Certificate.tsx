'use client';

import { useRef, useState } from 'react';
import Image from 'next/image';
import {
  Download, Share2, Linkedin, ExternalLink, Award, CheckCircle2,
  Copy, Check, QrCode
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import toast from 'react-hot-toast';
import { format } from 'date-fns';

interface CertificateProps {
  certificate: {
    id: string;
    verificationId: string;
    issuedAt: Date | string;
    skills: string[];
    pdfUrl?: string;
    user: { name: string; email: string };
    course: {
      title: string;
      instructor: { user: { name: string } };
      durationMinutes: number;
    };
  };
  preview?: boolean;
}

export function Certificate({ certificate, preview = false }: CertificateProps) {
  const certRef = useRef<HTMLDivElement>(null);
  const [copied, setCopied] = useState(false);
  const [downloading, setDownloading] = useState(false);

  const verificationUrl = `${process.env.NEXT_PUBLIC_URL}/certificates/verify/${certificate.verificationId}`;
  const issuedDate = format(new Date(certificate.issuedAt), 'MMMM d, yyyy');
  const hours = Math.round(certificate.course.durationMinutes / 60);

  const copyVerificationId = () => {
    navigator.clipboard.writeText(certificate.verificationId);
    setCopied(true);
    toast.success('Verification ID copied!');
    setTimeout(() => setCopied(false), 2000);
  };

  const shareOnLinkedIn = () => {
    const params = new URLSearchParams({
      startTask: 'CERTIFICATION_NAME',
      name: certificate.course.title,
      organizationId: '0',
      issueYear: new Date(certificate.issuedAt).getFullYear().toString(),
      issueMonth: (new Date(certificate.issuedAt).getMonth() + 1).toString(),
      certUrl: verificationUrl,
      certId: certificate.verificationId,
    });
    window.open(
      `https://www.linkedin.com/profile/add?${params.toString()}`,
      '_blank'
    );
  };

  const downloadPDF = async () => {
    if (certificate.pdfUrl) {
      window.open(certificate.pdfUrl, '_blank');
      return;
    }
    setDownloading(true);
    try {
      const res = await fetch(`/api/certificates/${certificate.id}/pdf`);
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `certificate-${certificate.verificationId}.pdf`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success('Certificate downloaded!');
    } catch {
      toast.error('Download failed. Please try again.');
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Certificate design */}
      <div
        ref={certRef}
        className={cn(
          'relative bg-white text-black rounded-2xl overflow-hidden shadow-2xl',
          preview ? 'max-w-2xl mx-auto' : 'w-full'
        )}
        style={{ aspectRatio: '1.414' }} // A4 landscape ratio
      >
        {/* Background design */}
        <div className="absolute inset-0">
          {/* Corner decorations */}
          <div className="absolute top-0 left-0 w-32 h-32 border-l-4 border-t-4 border-emerald-500 rounded-tl-2xl" />
          <div className="absolute top-0 right-0 w-32 h-32 border-r-4 border-t-4 border-emerald-500 rounded-tr-2xl" />
          <div className="absolute bottom-0 left-0 w-32 h-32 border-l-4 border-b-4 border-emerald-500 rounded-bl-2xl" />
          <div className="absolute bottom-0 right-0 w-32 h-32 border-r-4 border-b-4 border-emerald-500 rounded-br-2xl" />

          {/* Subtle gradient bg */}
          <div className="absolute inset-0 bg-gradient-to-br from-emerald-50/50 via-white to-teal-50/30" />

          {/* Decorative dots */}
          <div className="absolute top-8 left-1/2 -translate-x-1/2 flex gap-2">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="w-1.5 h-1.5 bg-emerald-300 rounded-full" />
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="relative z-10 flex flex-col items-center justify-center h-full p-12 text-center">
          {/* Logo */}
          <div className="flex items-center gap-2 mb-6">
            <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center">
              <Award className="w-5 h-5 text-white" />
            </div>
            <span className="font-bold text-lg text-gray-800">
              Learn<span className="text-emerald-500">Forge</span>
            </span>
          </div>

          <p className="text-xs font-semibold tracking-[0.3em] text-emerald-600 uppercase mb-4">
            Certificate of Completion
          </p>

          <p className="text-sm text-gray-500 mb-2">This certifies that</p>

          <h2 className="text-4xl font-bold text-gray-900 mb-3" style={{ fontFamily: 'Georgia, serif' }}>
            {certificate.user.name}
          </h2>

          <p className="text-sm text-gray-500 mb-2">has successfully completed</p>

          <h3 className="text-xl font-bold text-gray-800 max-w-md leading-tight mb-4">
            {certificate.course.title}
          </h3>

          <div className="flex items-center gap-6 text-xs text-gray-500 mb-6">
            <span>{hours} hours of content</span>
            <span className="w-1 h-1 bg-gray-300 rounded-full" />
            <span>Issued {issuedDate}</span>
          </div>

          {/* Skills */}
          {certificate.skills.length > 0 && (
            <div className="flex flex-wrap justify-center gap-1.5 mb-6">
              {certificate.skills.slice(0, 5).map((skill) => (
                <span
                  key={skill}
                  className="px-2.5 py-0.5 bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs rounded-full"
                >
                  {skill}
                </span>
              ))}
            </div>
          )}

          {/* Instructor signature & verification */}
          <div className="flex items-end justify-between w-full max-w-md mt-auto">
            <div className="text-left">
              <div className="text-base font-semibold text-gray-700 border-b border-gray-300 pb-1 mb-1" style={{ fontFamily: 'cursive' }}>
                {certificate.course.instructor.user.name}
              </div>
              <p className="text-xs text-gray-400">Instructor</p>
            </div>

            <div className="text-right">
              <div className="text-xs text-gray-400 mb-1">Verification ID</div>
              <div className="font-mono text-xs font-bold text-gray-600 bg-gray-100 px-2 py-1 rounded">
                {certificate.verificationId.slice(0, 12).toUpperCase()}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Actions */}
      {!preview && (
        <div className="flex flex-wrap gap-3">
          <Button onClick={downloadPDF} disabled={downloading} className="gap-2">
            <Download className="w-4 h-4" />
            {downloading ? 'Generating PDF...' : 'Download PDF'}
          </Button>

          <Button variant="outline" onClick={shareOnLinkedIn} className="gap-2">
            <Linkedin className="w-4 h-4 text-[#0077b5]" />
            Add to LinkedIn
          </Button>

          <Button
            variant="outline"
            onClick={() => {
              navigator.share?.({
                title: `${certificate.course.title} Certificate`,
                url: verificationUrl,
              }) ?? navigator.clipboard.writeText(verificationUrl).then(() => toast.success('Link copied!'));
            }}
            className="gap-2"
          >
            <Share2 className="w-4 h-4" />
            Share
          </Button>

          <Button variant="outline" asChild className="gap-2">
            <a href={verificationUrl} target="_blank" rel="noopener noreferrer">
              <ExternalLink className="w-4 h-4" />
              View Public
            </a>
          </Button>
        </div>
      )}

      {/* Verification info */}
      {!preview && (
        <div className="bg-secondary/50 border rounded-xl p-4">
          <div className="flex items-center gap-2 mb-3">
            <CheckCircle2 className="w-4 h-4 text-primary" />
            <span className="text-sm font-semibold">Certificate Verified</span>
            <Badge variant="secondary" className="text-xs">Authentic</Badge>
          </div>
          <div className="flex items-center gap-3">
            <div>
              <p className="text-xs text-muted-foreground mb-0.5">Verification ID</p>
              <code className="text-xs font-mono">{certificate.verificationId}</code>
            </div>
            <Button variant="ghost" size="icon" className="w-7 h-7 ml-auto" onClick={copyVerificationId}>
              {copied ? <Check className="w-3.5 h-3.5 text-primary" /> : <Copy className="w-3.5 h-3.5" />}
            </Button>
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            Anyone can verify this certificate at{' '}
            <a href={verificationUrl} className="text-primary hover:underline" target="_blank" rel="noopener noreferrer">
              learnforge.com/verify
            </a>
          </p>
        </div>
      )}
    </div>
  );
}
