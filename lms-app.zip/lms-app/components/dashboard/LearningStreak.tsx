'use client';

import { Flame, Trophy, Target, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

const DAYS = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
const COMPLETED = [true, true, true, true, true, true, false]; // today is Sunday

export function LearningStreak({ userId }: { userId?: string }) {
  const streak = 7;
  const longestStreak = 14;

  return (
    <div className="bg-card border rounded-xl p-5">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-display font-bold text-sm">Learning Streak</h3>
        <div className="flex items-center gap-1.5 text-orange-500 font-bold">
          <Flame className="w-4 h-4 fill-orange-500 streak-flame" />
          <span>{streak} days</span>
        </div>
      </div>

      {/* Week view */}
      <div className="flex items-center justify-between mb-4">
        {DAYS.map((day, i) => (
          <div key={i} className="flex flex-col items-center gap-1.5">
            <div
              className={cn(
                'w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all',
                COMPLETED[i]
                  ? 'bg-orange-500 text-white shadow-[0_0_12px_rgba(249,115,22,0.4)]'
                  : i === 6
                  ? 'border-2 border-dashed border-border text-muted-foreground'
                  : 'bg-secondary text-muted-foreground'
              )}
            >
              {COMPLETED[i] ? <Flame className="w-3.5 h-3.5 fill-white" /> : day}
            </div>
            <span className="text-[10px] text-muted-foreground">{day}</span>
          </div>
        ))}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-secondary/50 rounded-lg p-3">
          <div className="flex items-center gap-1.5 mb-1">
            <Flame className="w-3.5 h-3.5 text-orange-500" />
            <span className="text-xs text-muted-foreground">Current</span>
          </div>
          <span className="text-lg font-bold">{streak} days</span>
        </div>
        <div className="bg-secondary/50 rounded-lg p-3">
          <div className="flex items-center gap-1.5 mb-1">
            <Trophy className="w-3.5 h-3.5 text-amber-500" />
            <span className="text-xs text-muted-foreground">Longest</span>
          </div>
          <span className="text-lg font-bold">{longestStreak} days</span>
        </div>
      </div>

      {/* Today's goal */}
      <div className="mt-3 p-3 bg-orange-500/10 border border-orange-500/20 rounded-lg">
        <div className="flex items-center gap-2">
          <Target className="w-4 h-4 text-orange-500" />
          <span className="text-xs font-medium text-orange-500">
            Complete 30 min today to keep streak!
          </span>
        </div>
      </div>
    </div>
  );
}
