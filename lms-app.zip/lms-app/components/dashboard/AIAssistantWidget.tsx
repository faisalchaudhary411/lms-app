'use client';

import { useState, useRef, useEffect } from 'react';
import { Sparkles, X, Send, Loader2, Bot, User, BookOpen, Lightbulb, TrendingUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  suggestions?: string[];
  courses?: { title: string; href: string }[];
  timestamp: Date;
}

const QUICK_PROMPTS = [
  { label: '📚 What should I learn next?', prompt: 'Based on my progress, what should I learn next?' },
  { label: '🎯 Skill gap analysis', prompt: 'Analyze my skill gaps and recommend courses to fill them.' },
  { label: '📊 Learning summary', prompt: 'Give me a summary of my learning progress this week.' },
  { label: '🚀 Career advice', prompt: 'What skills should I prioritize for a career in software engineering?' },
];

export function AIAssistantWidget() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '0',
      role: 'assistant',
      content: "Hi! I'm your AI learning assistant. I can help you discover courses, analyze your skill gaps, and personalize your learning journey. What would you like to explore today?",
      suggestions: ['What should I learn next?', 'Skill gap analysis', 'Career advice'],
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = async (text: string) => {
    if (!text.trim() || loading) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: text,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/ai/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          history: messages.map((m) => ({ role: m.role, content: m.content })),
        }),
      });
      const data = await res.json();

      const assistantMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: data.message || "I'm having trouble connecting. Please try again.",
        suggestions: data.suggestions,
        courses: data.courses,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, assistantMsg]);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          role: 'assistant',
          content: "Sorry, I'm having trouble connecting right now. Please try again.",
          timestamp: new Date(),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {/* Trigger button */}
      <button
        onClick={() => setOpen(true)}
        className="hidden sm:flex items-center gap-2 px-3 py-2 bg-primary/10 border border-primary/20 rounded-xl text-sm font-medium text-primary hover:bg-primary/20 transition-colors"
      >
        <Sparkles className="w-4 h-4" />
        <span>AI Assistant</span>
      </button>

      {/* Chat panel */}
      {open && (
        <div className="fixed bottom-6 right-6 w-96 h-[600px] bg-card border rounded-2xl shadow-2xl z-50 flex flex-col overflow-hidden animate-fade-up">
          {/* Header */}
          <div className="flex items-center gap-3 p-4 border-b bg-gradient-to-r from-primary/10 to-emerald-500/10">
            <div className="w-9 h-9 bg-primary rounded-xl flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1">
              <p className="font-semibold text-sm">AI Learning Assistant</p>
              <p className="text-xs text-muted-foreground">Powered by LearnForge AI</p>
            </div>
            <button
              onClick={() => setOpen(false)}
              className="w-7 h-7 flex items-center justify-center text-muted-foreground hover:text-foreground rounded-lg hover:bg-secondary transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-hide">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={cn(
                  'flex gap-2.5',
                  msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'
                )}
              >
                {/* Avatar */}
                <div className={cn(
                  'w-7 h-7 rounded-full flex items-center justify-center shrink-0 mt-0.5',
                  msg.role === 'assistant'
                    ? 'bg-primary/20 text-primary'
                    : 'bg-secondary text-muted-foreground'
                )}>
                  {msg.role === 'assistant' ? <Bot className="w-4 h-4" /> : <User className="w-4 h-4" />}
                </div>

                <div className={cn(
                  'max-w-[80%] space-y-2',
                  msg.role === 'user' ? 'items-end' : 'items-start'
                )}>
                  {/* Bubble */}
                  <div className={cn(
                    'px-3 py-2.5 rounded-2xl text-sm leading-relaxed',
                    msg.role === 'assistant'
                      ? 'bg-secondary text-foreground rounded-tl-sm'
                      : 'bg-primary text-primary-foreground rounded-tr-sm'
                  )}>
                    {msg.content}
                  </div>

                  {/* Suggested courses */}
                  {msg.courses && msg.courses.length > 0 && (
                    <div className="space-y-1.5">
                      {msg.courses.map((course, i) => (
                        <a
                          key={i}
                          href={course.href}
                          className="flex items-center gap-2 p-2 bg-primary/5 border border-primary/10 rounded-lg hover:bg-primary/10 transition-colors"
                        >
                          <BookOpen className="w-3.5 h-3.5 text-primary shrink-0" />
                          <span className="text-xs font-medium line-clamp-1">{course.title}</span>
                        </a>
                      ))}
                    </div>
                  )}

                  {/* Quick reply suggestions */}
                  {msg.suggestions && msg.role === 'assistant' && (
                    <div className="flex flex-wrap gap-1.5">
                      {msg.suggestions.map((s) => (
                        <button
                          key={s}
                          onClick={() => sendMessage(s)}
                          className="px-2.5 py-1 text-xs bg-secondary border rounded-full hover:border-primary/40 hover:bg-primary/5 transition-colors"
                        >
                          {s}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}

            {loading && (
              <div className="flex gap-2.5">
                <div className="w-7 h-7 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
                  <Bot className="w-4 h-4 text-primary" />
                </div>
                <div className="bg-secondary rounded-2xl rounded-tl-sm px-4 py-3">
                  <div className="flex gap-1">
                    {[0, 1, 2].map((i) => (
                      <div
                        key={i}
                        className="w-1.5 h-1.5 bg-muted-foreground rounded-full animate-bounce"
                        style={{ animationDelay: `${i * 150}ms` }}
                      />
                    ))}
                  </div>
                </div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          {/* Quick prompts */}
          {messages.length === 1 && (
            <div className="px-4 pb-2">
              <div className="grid grid-cols-2 gap-1.5">
                {QUICK_PROMPTS.map((prompt) => (
                  <button
                    key={prompt.label}
                    onClick={() => sendMessage(prompt.prompt)}
                    className="p-2 text-xs text-left bg-secondary/50 hover:bg-secondary rounded-lg border border-border/50 transition-colors leading-snug"
                  >
                    {prompt.label}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Input */}
          <div className="p-4 border-t">
            <div className="flex gap-2">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), sendMessage(input))}
                placeholder="Ask me anything..."
                className="flex-1 px-3 py-2 text-sm bg-background border rounded-xl outline-none focus:ring-2 ring-primary/30"
                disabled={loading}
              />
              <Button
                size="icon"
                className="w-9 h-9 shrink-0"
                onClick={() => sendMessage(input)}
                disabled={!input.trim() || loading}
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
