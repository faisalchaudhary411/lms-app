'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Check, X, Zap, Building2, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

const PLANS = [
  {
    id: 'basic',
    name: 'Basic',
    monthlyPrice: 0,
    yearlyPrice: 0,
    description: 'Start your learning journey for free',
    icon: Star,
    color: 'text-muted-foreground',
    features: [
      { label: 'Access to free courses', included: true },
      { label: 'Course previews', included: true },
      { label: 'Discussion forums', included: true },
      { label: 'Mobile app', included: true },
      { label: 'Certificates', included: false },
      { label: 'AI assistant', included: false },
      { label: 'Offline downloads', included: false },
      { label: 'Priority support', included: false },
    ],
    cta: 'Get Started Free',
    ctaHref: '/auth/register',
  },
  {
    id: 'pro',
    name: 'Pro',
    monthlyPrice: 29,
    yearlyPrice: 19,
    description: 'Unlimited access to all courses',
    icon: Zap,
    color: 'text-primary',
    badge: 'Most Popular',
    highlighted: true,
    features: [
      { label: 'Everything in Basic', included: true },
      { label: 'Unlimited course access', included: true },
      { label: 'Verified certificates', included: true },
      { label: 'AI learning assistant', included: true },
      { label: 'Offline downloads', included: true },
      { label: 'Priority support', included: true },
      { label: 'Learning paths', included: true },
      { label: 'Team features', included: false },
    ],
    cta: 'Start Pro',
    ctaHref: '/checkout/subscription?plan=pro',
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    monthlyPrice: null,
    yearlyPrice: null,
    description: 'Tailored learning for your organization',
    icon: Building2,
    color: 'text-violet-500',
    features: [
      { label: 'Everything in Pro', included: true },
      { label: 'Team dashboards', included: true },
      { label: 'Custom learning paths', included: true },
      { label: 'SSO integration', included: true },
      { label: 'Analytics & reporting', included: true },
      { label: 'Dedicated support', included: true },
      { label: 'Custom branding', included: true },
      { label: 'API access', included: true },
    ],
    cta: 'Contact Sales',
    ctaHref: '/enterprise/contact',
  },
];

export function PricingSection() {
  const [annual, setAnnual] = useState(true);

  return (
    <section className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-primary/5 to-background" />
      <div className="container mx-auto px-4 max-w-6xl relative">
        {/* Header */}
        <div className="text-center mb-12">
          <Badge variant="secondary" className="mb-4 text-xs px-3 py-1">Pricing</Badge>
          <h2 className="text-3xl sm:text-4xl font-display font-bold mb-4">
            Invest in your future
          </h2>
          <p className="text-muted-foreground max-w-lg mx-auto">
            Choose the plan that fits your learning goals. Upgrade or cancel anytime.
          </p>

          {/* Billing toggle */}
          <div className="flex items-center justify-center gap-4 mt-8">
            <span className={cn('text-sm', !annual && 'font-medium')}>Monthly</span>
            <button
              onClick={() => setAnnual(!annual)}
              className={cn(
                'relative w-12 h-6 rounded-full transition-colors',
                annual ? 'bg-primary' : 'bg-secondary border'
              )}
            >
              <span className={cn(
                'absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform',
                annual ? 'translate-x-6' : 'translate-x-0.5'
              )} />
            </button>
            <span className={cn('text-sm', annual && 'font-medium')}>
              Annual
              <Badge className="ml-2 text-[10px] bg-primary/10 text-primary border-0">Save 35%</Badge>
            </span>
          </div>
        </div>

        {/* Plans */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-start">
          {PLANS.map((plan) => (
            <div
              key={plan.id}
              className={cn(
                'relative rounded-2xl border p-6 transition-all duration-200',
                plan.highlighted
                  ? 'border-primary shadow-lg shadow-primary/10 bg-card scale-[1.02]'
                  : 'border-border bg-card hover:border-primary/30 hover:shadow-md'
              )}
            >
              {plan.badge && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <Badge className="bg-primary text-primary-foreground shadow-md px-3">
                    {plan.badge}
                  </Badge>
                </div>
              )}

              {/* Plan header */}
              <div className="mb-6">
                <div className={cn('w-10 h-10 rounded-xl flex items-center justify-center mb-3',
                  plan.highlighted ? 'bg-primary/20' : 'bg-secondary'
                )}>
                  <plan.icon className={cn('w-5 h-5', plan.color)} />
                </div>
                <h3 className="font-display font-bold text-lg">{plan.name}</h3>
                <p className="text-sm text-muted-foreground mt-1">{plan.description}</p>
              </div>

              {/* Price */}
              <div className="mb-6">
                {plan.monthlyPrice === null ? (
                  <div className="text-2xl font-display font-bold">Custom</div>
                ) : plan.monthlyPrice === 0 ? (
                  <div className="text-3xl font-display font-bold">Free</div>
                ) : (
                  <div>
                    <div className="flex items-baseline gap-1">
                      <span className="text-3xl font-display font-bold">
                        ${annual ? plan.yearlyPrice : plan.monthlyPrice}
                      </span>
                      <span className="text-muted-foreground">/month</span>
                    </div>
                    {annual && (
                      <p className="text-xs text-muted-foreground mt-1">
                        Billed ${(plan.yearlyPrice! * 12).toFixed(0)}/year
                      </p>
                    )}
                  </div>
                )}
              </div>

              {/* CTA */}
              <Button
                className={cn('w-full mb-6', !plan.highlighted && 'variant-outline')}
                variant={plan.highlighted ? 'default' : 'outline'}
                asChild
              >
                <Link href={plan.ctaHref}>{plan.cta}</Link>
              </Button>

              {/* Features */}
              <ul className="space-y-2.5">
                {plan.features.map((feature) => (
                  <li key={feature.label} className="flex items-center gap-2.5 text-sm">
                    {feature.included ? (
                      <div className={cn('w-4 h-4 rounded-full flex items-center justify-center shrink-0',
                        plan.highlighted ? 'bg-primary/20 text-primary' : 'bg-secondary text-muted-foreground'
                      )}>
                        <Check className="w-2.5 h-2.5" />
                      </div>
                    ) : (
                      <div className="w-4 h-4 rounded-full bg-secondary/50 flex items-center justify-center shrink-0">
                        <X className="w-2.5 h-2.5 text-muted-foreground/40" />
                      </div>
                    )}
                    <span className={cn(
                      feature.included ? 'text-foreground' : 'text-muted-foreground/50 line-through'
                    )}>
                      {feature.label}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Money-back guarantee */}
        <p className="text-center text-sm text-muted-foreground mt-10">
          All paid plans come with a <span className="text-foreground font-medium">30-day money-back guarantee</span>.
          No questions asked.
        </p>
      </div>
    </section>
  );
}
