'use client';

import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useSession } from 'next-auth/react';
import {
  LayoutDashboard, BookOpen, GraduationCap, Trophy, Heart,
  MessageSquare, Settings, ChevronLeft, ChevronRight,
  BarChart2, Calendar, FileText, Users, Flame, Star,
  Bell, CreditCard, Shield, Zap
} from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { Navbar } from './Navbar';

const SIDEBAR_ITEMS = [
  {
    group: 'Learning',
    items: [
      { label: 'Overview', href: '/dashboard', icon: LayoutDashboard },
      { label: 'My Courses', href: '/dashboard/my-courses', icon: BookOpen },
      { label: 'Learning Paths', href: '/dashboard/paths', icon: Zap },
      { label: 'Calendar', href: '/dashboard/calendar', icon: Calendar },
    ],
  },
  {
    group: 'Progress',
    items: [
      { label: 'Achievements', href: '/dashboard/achievements', icon: Trophy },
      { label: 'Certificates', href: '/dashboard/certificates', icon: GraduationCap },
      { label: 'Analytics', href: '/dashboard/analytics', icon: BarChart2 },
      { label: 'Streaks', href: '/dashboard/streaks', icon: Flame },
    ],
  },
  {
    group: 'Community',
    items: [
      { label: 'Discussions', href: '/dashboard/discussions', icon: MessageSquare },
      { label: 'Study Groups', href: '/dashboard/groups', icon: Users },
      { label: 'Wishlist', href: '/dashboard/wishlist', icon: Heart },
    ],
  },
  {
    group: 'Account',
    items: [
      { label: 'Notifications', href: '/dashboard/notifications', icon: Bell, badge: '3' },
      { label: 'Billing', href: '/dashboard/billing', icon: CreditCard },
      { label: 'Security', href: '/dashboard/security', icon: Shield },
      { label: 'Settings', href: '/dashboard/settings', icon: Settings },
    ],
  },
];

export function DashboardLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const { data: session } = useSession();
  const [collapsed, setCollapsed] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <div className="flex pt-16">
        {/* Sidebar */}
        <aside
          className={cn(
            'fixed left-0 top-16 bottom-0 z-40 flex flex-col border-r bg-card transition-all duration-300 ease-in-out',
            collapsed ? 'w-16' : 'w-64'
          )}
        >
          {/* User summary */}
          {!collapsed && (
            <div className="p-4 border-b">
              <div className="flex items-center gap-3">
                <Avatar className="w-10 h-10 shrink-0">
                  <AvatarImage src={session?.user?.image || ''} />
                  <AvatarFallback className="bg-primary/20 text-primary font-bold text-sm">
                    {session?.user?.name?.[0] || 'U'}
                  </AvatarFallback>
                </Avatar>
                <div className="min-w-0">
                  <p className="text-sm font-semibold truncate">{session?.user?.name}</p>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <span className="level-badge">Lvl 12</span>
                    <div className="flex-1 h-1 bg-secondary rounded-full overflow-hidden">
                      <div className="h-full bg-primary rounded-full" style={{ width: '65%' }} />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Navigation */}
          <nav className="flex-1 overflow-y-auto py-4 scrollbar-hide">
            {SIDEBAR_ITEMS.map((group) => (
              <div key={group.group} className="mb-4">
                {!collapsed && (
                  <p className="px-4 mb-1 text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">
                    {group.group}
                  </p>
                )}
                {group.items.map((item) => {
                  const isActive = pathname === item.href;
                  return (
                    <Link
                      key={item.href}
                      href={item.href}
                      className={cn(
                        'flex items-center gap-3 px-4 py-2.5 text-sm font-medium transition-all duration-150 relative',
                        isActive
                          ? 'sidebar-item-active text-primary'
                          : 'text-muted-foreground hover:text-foreground hover:bg-secondary/50',
                        collapsed && 'justify-center px-0'
                      )}
                      title={collapsed ? item.label : undefined}
                    >
                      <item.icon className="w-4 h-4 shrink-0" />
                      {!collapsed && (
                        <>
                          <span className="flex-1">{item.label}</span>
                          {item.badge && (
                            <Badge
                              variant="secondary"
                              className="text-[10px] h-4 min-w-4 flex items-center justify-center bg-primary/10 text-primary"
                            >
                              {item.badge}
                            </Badge>
                          )}
                        </>
                      )}
                    </Link>
                  );
                })}
              </div>
            ))}
          </nav>

          {/* Collapse toggle */}
          <div className="p-3 border-t">
            <button
              onClick={() => setCollapsed(!collapsed)}
              className={cn(
                'flex items-center gap-2 w-full px-3 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-secondary rounded-lg transition-colors',
                collapsed && 'justify-center'
              )}
            >
              {collapsed ? (
                <ChevronRight className="w-4 h-4" />
              ) : (
                <>
                  <ChevronLeft className="w-4 h-4" />
                  <span>Collapse</span>
                </>
              )}
            </button>
          </div>
        </aside>

        {/* Main content */}
        <main
          className={cn(
            'flex-1 transition-all duration-300 min-h-[calc(100vh-4rem)]',
            collapsed ? 'ml-16' : 'ml-64'
          )}
        >
          <div className="p-6 lg:p-8 max-w-7xl mx-auto">{children}</div>
        </main>
      </div>
    </div>
  );
}
