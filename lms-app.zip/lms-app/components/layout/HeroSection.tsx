'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Search, Play, Star, Users, BookOpen, Award, ArrowRight, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useRouter } from 'next/navigation';

const TRENDING = ['Python', 'React', 'Data Science', 'AI/ML', 'Web Design', 'Cloud'];

export function HeroSection() {
  const router = useRouter();
  const [query, setQuery] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      router.push(`/courses?q=${encodeURIComponent(query.trim())}`);
    }
  };

  return (
    <section className="relative min-h-screen flex items-center overflow-hidden pt-20">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-background via-background to-primary/5" />
      <div className="absolute inset-0 bg-grid-pattern opacity-50" />

      {/* Glowing orbs */}
      <div className="absolute top-1/4 -left-32 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl" />

      {/* Floating cards */}
      <div className="absolute top-32 right-12 hidden xl:block animate-bounce-subtle">
        <div className="glass rounded-2xl p-4 shadow-lg w-52">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center">
              <Award className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Just earned</p>
              <p className="text-sm font-semibold">React Certificate</p>
            </div>
          </div>
          <div className="flex gap-0.5">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-3 h-3 text-amber-400 fill-amber-400" />
            ))}
          </div>
        </div>
      </div>

      <div className="absolute bottom-48 right-24 hidden xl:block" style={{ animationDelay: '1s' }}>
        <div className="glass rounded-2xl p-4 shadow-lg w-48">
          <div className="flex items-center gap-2 mb-2">
            <div className="flex -space-x-1.5">
              {[...Array(4)].map((_, i) => (
                <div
                  key={i}
                  className="w-6 h-6 rounded-full bg-primary/20 border-2 border-background"
                />
              ))}
            </div>
            <span className="text-xs font-medium">+2.4k</span>
          </div>
          <p className="text-xs text-muted-foreground">enrolled this week</p>
        </div>
      </div>

      <div className="absolute top-56 left-12 hidden xl:block" style={{ animationDelay: '0.5s' }}>
        <div className="glass rounded-2xl p-4 shadow-lg w-44">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-2xl font-bold gradient-text">94%</span>
          </div>
          <p className="text-xs text-muted-foreground">completion rate</p>
          <div className="mt-2 progress-bar">
            <div className="progress-fill" style={{ width: '94%' }} />
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 max-w-7xl relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 border border-primary/20 rounded-full text-sm font-medium text-primary mb-8">
            <Sparkles className="w-4 h-4" />
            <span>AI-powered learning platform</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </div>

          {/* Headline */}
          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-display font-bold tracking-tight text-balance leading-[1.1] mb-6">
            Master any skill,{' '}
            <span className="gradient-text">faster than ever</span>
          </h1>

          <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed">
            Join over 4 million learners. Access 15,000+ expert-led courses, earn
            industry-recognized certificates, and accelerate your career.
          </p>

          {/* Search */}
          <form onSubmit={handleSearch} className="relative max-w-2xl mx-auto mb-6">
            <div className="flex gap-3 p-2 bg-card border border-border rounded-2xl shadow-xl shadow-black/5">
              <div className="flex-1 flex items-center gap-3 px-3">
                <Search className="w-5 h-5 text-muted-foreground shrink-0" />
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="What do you want to learn?"
                  className="flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
                />
              </div>
              <Button type="submit" size="lg" className="rounded-xl shrink-0">
                Search Courses
              </Button>
            </div>
          </form>

          {/* Trending */}
          <div className="flex flex-wrap items-center justify-center gap-2 mb-14">
            <span className="text-sm text-muted-foreground">Trending:</span>
            {TRENDING.map((term) => (
              <Link
                key={term}
                href={`/courses?q=${encodeURIComponent(term)}`}
                className="tag-pill hover:border-primary/40 hover:text-primary transition-colors"
              >
                {term}
              </Link>
            ))}
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 max-w-2xl mx-auto">
            {[
              { icon: BookOpen, value: '15,000+', label: 'Expert Courses' },
              { icon: Users, value: '4M+', label: 'Active Learners' },
              { icon: Star, value: '4.8/5', label: 'Avg Rating' },
              { icon: Award, value: '500K+', label: 'Certificates Issued' },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <stat.icon className="w-5 h-5 text-primary" />
                </div>
                <div className="text-2xl font-bold font-display">{stat.value}</div>
                <div className="text-xs text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom gradient */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent" />
    </section>
  );
}
