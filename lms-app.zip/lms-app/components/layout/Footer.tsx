// ─────────────────────────────────────────────────────────────────────────────
// Footer
// ─────────────────────────────────────────────────────────────────────────────
import Link from 'next/link';
import { GraduationCap, Twitter, Linkedin, Github, Youtube } from 'lucide-react';

export function Footer() {
  const LINKS = {
    Learn: ['Browse Courses', 'Learning Paths', 'Live Classes', 'Certifications'],
    Teach: ['Become an Instructor', 'Instructor Hub', 'Revenue Share', 'Teaching Resources'],
    Company: ['About Us', 'Blog', 'Careers', 'Press'],
    Support: ['Help Center', 'Contact Us', 'Privacy Policy', 'Terms of Service'],
  };
  return (
    <footer className="border-t bg-card mt-20">
      <div className="container mx-auto px-4 max-w-7xl py-14">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-10">
          <div className="col-span-2 md:col-span-1">
            <Link href="/" className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <GraduationCap className="w-5 h-5 text-white" />
              </div>
              <span className="font-display font-bold">Learn<span className="text-primary">Forge</span></span>
            </Link>
            <p className="text-sm text-muted-foreground leading-relaxed mb-4">
              The most powerful learning management system.
            </p>
            <div className="flex gap-3">
              {[Twitter, Linkedin, Github, Youtube].map((Icon, i) => (
                <a key={i} href="#" className="w-8 h-8 flex items-center justify-center rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>
          {Object.entries(LINKS).map(([group, links]) => (
            <div key={group}>
              <h4 className="font-semibold text-sm mb-3">{group}</h4>
              <ul className="space-y-2">
                {links.map((link) => (
                  <li key={link}>
                    <Link href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                      {link}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="border-t mt-12 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-muted-foreground">© 2024 LearnForge Inc. All rights reserved.</p>
          <div className="flex gap-4 text-xs text-muted-foreground">
            <Link href="/privacy" className="hover:text-foreground">Privacy</Link>
            <Link href="/terms" className="hover:text-foreground">Terms</Link>
            <Link href="/sitemap" className="hover:text-foreground">Sitemap</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
