'use client';

import { useEffect, useState, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import * as DialogPrimitive from '@radix-ui/react-dialog';
import {
  Search, BookOpen, Users, GraduationCap, ArrowRight,
  TrendingUp, Loader2, X, Star, Clock
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useDebounce } from '@/hooks/useDebounce';

interface SearchResult {
  id: string;
  type: 'course' | 'instructor' | 'category';
  title: string;
  subtitle?: string;
  href: string;
  rating?: number;
  students?: number;
}

const QUICK_LINKS = [
  { label: 'Browse All Courses', href: '/courses', icon: BookOpen },
  { label: 'My Dashboard', href: '/dashboard', icon: GraduationCap },
  { label: 'Trending Now', href: '/courses?sort=MOST_POPULAR', icon: TrendingUp },
  { label: 'Top Instructors', href: '/instructors', icon: Users },
];

const TRENDING = ['React', 'Python', 'Machine Learning', 'TypeScript', 'AWS', 'Figma'];

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function CommandPalette({ open, onOpenChange }: Props) {
  const router = useRouter();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedIdx, setSelectedIdx] = useState(0);
  const debouncedQuery = useDebounce(query, 300);

  useEffect(() => {
    if (!open) {
      setQuery('');
      setResults([]);
      setSelectedIdx(0);
    }
  }, [open]);

  useEffect(() => {
    if (!debouncedQuery.trim()) {
      setResults([]);
      return;
    }
    searchCourses(debouncedQuery);
  }, [debouncedQuery]);

  const searchCourses = async (q: string) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/courses?q=${encodeURIComponent(q)}&limit=6`);
      const data = await res.json();
      const mapped: SearchResult[] = (data.data || []).map((c: any) => ({
        id: c.id,
        type: 'course' as const,
        title: c.title,
        subtitle: c.instructor?.user?.name,
        href: `/courses/${c.slug}`,
        rating: c.avgRating,
        students: c.totalStudents,
      }));
      setResults(mapped);
    } catch {
      setResults([]);
    } finally {
      setLoading(false);
    }
  };

  const navigate = (href: string) => {
    onOpenChange(false);
    router.push(href);
  };

  // Keyboard navigation
  useEffect(() => {
    if (!open) return;
    const allItems = query
      ? results
      : QUICK_LINKS.map((l) => ({ id: l.href, type: 'course' as const, title: l.label, href: l.href }));

    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIdx((i) => Math.min(i + 1, allItems.length - 1));
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIdx((i) => Math.max(i - 1, 0));
      } else if (e.key === 'Enter') {
        e.preventDefault();
        const item = allItems[selectedIdx];
        if (item) navigate(item.href);
        else if (query) navigate(`/courses?q=${encodeURIComponent(query)}`);
      } else if (e.key === 'Escape') {
        onOpenChange(false);
      }
    };
    document.addEventListener('keydown', handleKey);
    return () => document.removeEventListener('keydown', handleKey);
  }, [open, results, selectedIdx, query]);

  return (
    <DialogPrimitive.Root open={open} onOpenChange={onOpenChange}>
      <DialogPrimitive.Portal>
        <DialogPrimitive.Overlay className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0" />
        <DialogPrimitive.Content className="fixed left-1/2 top-[15%] -translate-x-1/2 z-50 w-full max-w-2xl bg-card border rounded-2xl shadow-2xl overflow-hidden data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-top-[2%] data-[state=open]:slide-in-from-top-[2%]">
          {/* Search input */}
          <div className="flex items-center gap-3 px-4 py-4 border-b">
            {loading ? (
              <Loader2 className="w-5 h-5 text-muted-foreground animate-spin shrink-0" />
            ) : (
              <Search className="w-5 h-5 text-muted-foreground shrink-0" />
            )}
            <input
              autoFocus
              value={query}
              onChange={(e) => { setQuery(e.target.value); setSelectedIdx(0); }}
              placeholder="Search courses, instructors, topics..."
              className="flex-1 bg-transparent text-base outline-none placeholder:text-muted-foreground"
            />
            {query && (
              <button onClick={() => setQuery('')} className="text-muted-foreground hover:text-foreground">
                <X className="w-4 h-4" />
              </button>
            )}
            <kbd className="hidden sm:flex items-center gap-1 px-2 py-1 text-xs bg-secondary border rounded-lg text-muted-foreground">
              ESC
            </kbd>
          </div>

          <div className="max-h-[60vh] overflow-y-auto scrollbar-hide">
            {!query ? (
              /* Default state */
              <div className="p-4">
                {/* Quick links */}
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                  Quick Links
                </p>
                <div className="space-y-1 mb-4">
                  {QUICK_LINKS.map((link, i) => (
                    <button
                      key={link.href}
                      onClick={() => navigate(link.href)}
                      className={cn(
                        'w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-colors text-left',
                        i === selectedIdx ? 'bg-primary/10 text-primary' : 'hover:bg-secondary'
                      )}
                      onMouseEnter={() => setSelectedIdx(i)}
                    >
                      <link.icon className="w-4 h-4 text-muted-foreground shrink-0" />
                      {link.label}
                      <ArrowRight className="w-3.5 h-3.5 ml-auto text-muted-foreground" />
                    </button>
                  ))}
                </div>

                {/* Trending */}
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                  Trending Searches
                </p>
                <div className="flex flex-wrap gap-2">
                  {TRENDING.map((term) => (
                    <button
                      key={term}
                      onClick={() => setQuery(term)}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-secondary hover:bg-secondary/80 rounded-full text-sm transition-colors"
                    >
                      <TrendingUp className="w-3 h-3 text-primary" />
                      {term}
                    </button>
                  ))}
                </div>
              </div>
            ) : results.length > 0 ? (
              /* Search results */
              <div className="p-2">
                <p className="px-3 py-1.5 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                  Courses
                </p>
                {results.map((result, i) => (
                  <button
                    key={result.id}
                    onClick={() => navigate(result.href)}
                    className={cn(
                      'w-full flex items-start gap-3 px-3 py-3 rounded-xl text-left transition-colors',
                      i === selectedIdx ? 'bg-primary/10' : 'hover:bg-secondary'
                    )}
                    onMouseEnter={() => setSelectedIdx(i)}
                  >
                    <div className="w-8 h-8 bg-secondary rounded-lg flex items-center justify-center shrink-0 mt-0.5">
                      <BookOpen className="w-4 h-4 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium line-clamp-1">{result.title}</p>
                      {result.subtitle && (
                        <p className="text-xs text-muted-foreground mt-0.5">{result.subtitle}</p>
                      )}
                      {(result.rating || result.students) && (
                        <div className="flex items-center gap-2 mt-1">
                          {result.rating && (
                            <span className="flex items-center gap-0.5 text-xs text-amber-500">
                              <Star className="w-2.5 h-2.5 fill-amber-500" />
                              {result.rating}
                            </span>
                          )}
                          {result.students && (
                            <span className="text-xs text-muted-foreground">
                              {result.students.toLocaleString()} students
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-muted-foreground shrink-0 mt-1" />
                  </button>
                ))}
              </div>
            ) : !loading && query ? (
              /* No results */
              <div className="p-8 text-center">
                <Search className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                <p className="text-sm font-medium mb-1">No results for &ldquo;{query}&rdquo;</p>
                <p className="text-xs text-muted-foreground mb-4">Try different keywords</p>
                <button
                  onClick={() => navigate(`/courses?q=${encodeURIComponent(query)}`)}
                  className="text-sm text-primary hover:underline"
                >
                  Browse all courses →
                </button>
              </div>
            ) : null}
          </div>

          {/* Footer */}
          <div className="px-4 py-2.5 border-t bg-secondary/20 flex items-center justify-between">
            <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
              <span className="flex items-center gap-1">
                <kbd className="px-1.5 py-0.5 bg-background border rounded text-[10px]">↑↓</kbd> navigate
              </span>
              <span className="flex items-center gap-1">
                <kbd className="px-1.5 py-0.5 bg-background border rounded text-[10px]">↵</kbd> select
              </span>
              <span className="flex items-center gap-1">
                <kbd className="px-1.5 py-0.5 bg-background border rounded text-[10px]">ESC</kbd> close
              </span>
            </div>
            <span className="text-[10px] text-muted-foreground">
              Powered by LearnForge AI
            </span>
          </div>
        </DialogPrimitive.Content>
      </DialogPrimitive.Portal>
    </DialogPrimitive.Root>
  );
}
