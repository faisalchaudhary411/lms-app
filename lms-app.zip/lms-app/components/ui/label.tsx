export { Label } from './primitives';
