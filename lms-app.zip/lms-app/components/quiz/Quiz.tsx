'use client';

import { useState, useEffect, useRef } from 'react';
import {
  CheckCircle2, XCircle, Clock, Trophy, RefreshCw,
  ChevronRight, ChevronLeft, AlertCircle, Info
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import Confetti from 'react-confetti';

interface QuizOption {
  id: string;
  text: string;
}

interface QuizQuestion {
  id: string;
  text: string;
  type: 'MCQ' | 'TRUE_FALSE';
  options: QuizOption[];
  explanation?: string;
  points: number;
}

interface QuizProps {
  quizId: string;
  title: string;
  questions: QuizQuestion[];
  timeLimit?: number; // minutes
  passingScore: number;
  maxAttempts: number;
  attemptNumber: number;
  onComplete: (score: number, passed: boolean) => void;
  onRetry?: () => void;
}

type Phase = 'intro' | 'taking' | 'reviewing' | 'results';

export function Quiz({
  quizId,
  title,
  questions,
  timeLimit,
  passingScore,
  maxAttempts,
  attemptNumber,
  onComplete,
  onRetry,
}: QuizProps) {
  const [phase, setPhase] = useState<Phase>('intro');
  const [currentQ, setCurrentQ] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [timeLeft, setTimeLeft] = useState(timeLimit ? timeLimit * 60 : 0);
  const [showConfetti, setShowConfetti] = useState(false);
  const [results, setResults] = useState<{
    score: number;
    passed: boolean;
    correctCount: number;
  } | null>(null);
  const timerRef = useRef<NodeJS.Timeout>();

  // Timer
  useEffect(() => {
    if (phase !== 'taking' || !timeLimit) return;

    timerRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timerRef.current);
          submitQuiz();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timerRef.current);
  }, [phase, timeLimit]);

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  const question = questions[currentQ];
  const isAnswered = answers[question?.id] !== undefined;
  const totalPoints = questions.reduce((sum, q) => sum + q.points, 0);

  const selectAnswer = (optionId: string) => {
    if (phase !== 'taking') return;
    setAnswers((prev) => ({ ...prev, [question.id]: optionId }));
  };

  const submitQuiz = () => {
    clearInterval(timerRef.current);

    let earned = 0;
    let correct = 0;
    questions.forEach((q) => {
      const chosen = answers[q.id];
      const correctOption = q.options.find(
        (o) => o.id === chosen && q.options.findIndex((opt) => opt.id === chosen) === 0 // simplified
      );
      // In real app: compare with correctAnswer from API
      if (chosen) { earned += q.points; correct++; }
    });

    const score = Math.round((earned / totalPoints) * 100);
    const passed = score >= passingScore;

    setResults({ score, passed, correctCount: correct });
    setPhase('results');

    if (passed) {
      setShowConfetti(true);
      setTimeout(() => setShowConfetti(false), 5000);
    }

    onComplete(score, passed);
  };

  // INTRO PHASE
  if (phase === 'intro') {
    return (
      <div className="bg-card border rounded-xl p-8 text-center max-w-lg mx-auto">
        <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <Trophy className="w-8 h-8 text-primary" />
        </div>
        <h2 className="text-xl font-display font-bold mb-2">{title}</h2>
        <div className="flex items-center justify-center gap-4 text-sm text-muted-foreground mb-6">
          <span>{questions.length} questions</span>
          {timeLimit && (
            <>
              <span>·</span>
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                {timeLimit} minutes
              </span>
            </>
          )}
          <span>·</span>
          <span>Pass: {passingScore}%</span>
        </div>

        <div className="bg-amber-500/10 border border-amber-500/20 rounded-lg p-4 mb-6 text-left">
          <div className="flex items-start gap-2">
            <Info className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
            <div className="text-sm text-muted-foreground">
              <p className="font-medium text-foreground mb-1">Before you begin</p>
              <ul className="space-y-1 list-disc list-inside text-xs">
                <li>You have {maxAttempts - attemptNumber + 1} attempts remaining</li>
                {timeLimit && <li>Timer starts when you click Begin</li>}
                <li>Read each question carefully before answering</li>
              </ul>
            </div>
          </div>
        </div>

        <Button onClick={() => setPhase('taking')} size="lg" className="w-full">
          Begin Quiz
        </Button>
      </div>
    );
  }

  // RESULTS PHASE
  if (phase === 'results' && results) {
    return (
      <div className="bg-card border rounded-xl p-8 max-w-lg mx-auto">
        {showConfetti && <Confetti recycle={false} numberOfPieces={200} />}

        <div className="text-center mb-8">
          {results.passed ? (
            <div className="w-20 h-20 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4 animate-bounce-subtle">
              <CheckCircle2 className="w-10 h-10 text-primary" />
            </div>
          ) : (
            <div className="w-20 h-20 bg-destructive/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <XCircle className="w-10 h-10 text-destructive" />
            </div>
          )}

          <h2 className="text-2xl font-display font-bold mb-1">
            {results.passed ? 'Quiz Passed! 🎉' : 'Not Quite There'}
          </h2>
          <p className="text-muted-foreground text-sm">
            {results.passed
              ? 'Excellent work! You demonstrated mastery of this topic.'
              : `You need ${passingScore}% to pass. Review the material and try again.`}
          </p>
        </div>

        {/* Score circle */}
        <div className="flex items-center justify-center mb-6">
          <div className="relative w-32 h-32">
            <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
              <circle
                cx="50" cy="50" r="40"
                fill="none"
                stroke="hsl(var(--secondary))"
                strokeWidth="8"
              />
              <circle
                cx="50" cy="50" r="40"
                fill="none"
                stroke={results.passed ? 'hsl(var(--primary))' : 'hsl(var(--destructive))'}
                strokeWidth="8"
                strokeLinecap="round"
                strokeDasharray={`${(results.score / 100) * 251.2} 251.2`}
                className="transition-all duration-1000"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-3xl font-display font-bold">{results.score}%</span>
              <span className="text-xs text-muted-foreground">Score</span>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          {[
            { label: 'Correct', value: results.correctCount, color: 'text-primary' },
            { label: 'Wrong', value: questions.length - results.correctCount, color: 'text-destructive' },
            { label: 'Points', value: `${Math.round((results.score / 100) * totalPoints)}/${totalPoints}`, color: 'text-foreground' },
          ].map((stat) => (
            <div key={stat.label} className="bg-secondary/50 rounded-lg p-3 text-center">
              <div className={cn('text-xl font-bold', stat.color)}>{stat.value}</div>
              <div className="text-xs text-muted-foreground">{stat.label}</div>
            </div>
          ))}
        </div>

        <div className="flex gap-3">
          <Button
            variant="outline"
            className="flex-1 gap-2"
            onClick={() => setPhase('reviewing')}
          >
            Review Answers
          </Button>
          {!results.passed && attemptNumber < maxAttempts && (
            <Button className="flex-1 gap-2" onClick={onRetry}>
              <RefreshCw className="w-4 h-4" />
              Retry Quiz
            </Button>
          )}
          {results.passed && (
            <Button className="flex-1" onClick={() => window.history.back()}>
              Continue
            </Button>
          )}
        </div>
      </div>
    );
  }

  // TAKING PHASE
  return (
    <div className="bg-card border rounded-xl overflow-hidden max-w-2xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b bg-secondary/30">
        <div className="flex items-center gap-3">
          <span className="text-sm font-medium text-muted-foreground">
            Question {currentQ + 1} of {questions.length}
          </span>
          <div className="h-1.5 w-32 bg-background rounded-full overflow-hidden">
            <div
              className="h-full bg-primary rounded-full transition-all"
              style={{ width: `${((currentQ + 1) / questions.length) * 100}%` }}
            />
          </div>
        </div>

        {timeLimit && (
          <div className={cn(
            'flex items-center gap-1.5 text-sm font-mono font-bold px-3 py-1 rounded-lg',
            timeLeft < 60
              ? 'bg-destructive/10 text-destructive animate-pulse'
              : 'bg-secondary text-foreground'
          )}>
            <Clock className="w-3.5 h-3.5" />
            {formatTime(timeLeft)}
          </div>
        )}
      </div>

      {/* Question */}
      <div className="p-6">
        <div className="flex items-start gap-3 mb-6">
          <Badge variant="outline" className="shrink-0 text-xs">
            {question.points} pt{question.points !== 1 ? 's' : ''}
          </Badge>
          <h3 className="text-base font-medium leading-relaxed">{question.text}</h3>
        </div>

        {/* Options */}
        <div className="space-y-3">
          {question.options.map((option, i) => {
            const isSelected = answers[question.id] === option.id;

            return (
              <button
                key={option.id}
                onClick={() => selectAnswer(option.id)}
                className={cn(
                  'w-full flex items-center gap-4 p-4 rounded-xl border text-left transition-all duration-150',
                  isSelected
                    ? 'border-primary bg-primary/10 text-primary'
                    : 'border-border hover:border-primary/40 hover:bg-secondary/50'
                )}
              >
                <div className={cn(
                  'w-7 h-7 rounded-full border-2 flex items-center justify-center text-xs font-bold shrink-0 transition-all',
                  isSelected
                    ? 'border-primary bg-primary text-primary-foreground'
                    : 'border-border text-muted-foreground'
                )}>
                  {String.fromCharCode(65 + i)}
                </div>
                <span className={cn('text-sm', isSelected ? 'text-primary font-medium' : '')}>
                  {option.text}
                </span>
                {isSelected && (
                  <CheckCircle2 className="w-4 h-4 text-primary ml-auto shrink-0" />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between p-4 border-t bg-secondary/20">
        <Button
          variant="outline"
          size="sm"
          disabled={currentQ === 0}
          onClick={() => setCurrentQ((q) => q - 1)}
        >
          <ChevronLeft className="w-4 h-4 mr-1" />
          Previous
        </Button>

        {/* Progress dots */}
        <div className="flex gap-1.5">
          {questions.map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrentQ(i)}
              className={cn(
                'w-2 h-2 rounded-full transition-all',
                i === currentQ
                  ? 'bg-primary w-4'
                  : answers[questions[i].id]
                  ? 'bg-primary/40'
                  : 'bg-border'
              )}
            />
          ))}
        </div>

        {currentQ < questions.length - 1 ? (
          <Button size="sm" onClick={() => setCurrentQ((q) => q + 1)}>
            Next
            <ChevronRight className="w-4 h-4 ml-1" />
          </Button>
        ) : (
          <Button
            size="sm"
            onClick={submitQuiz}
            disabled={Object.keys(answers).length < questions.length}
          >
            Submit Quiz
          </Button>
        )}
      </div>
    </div>
  );
}
