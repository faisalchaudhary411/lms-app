'use client';

import { useState } from 'react';
import {
  Users, BookOpen, DollarSign, TrendingUp, Shield, AlertCircle,
  Search, Filter, MoreHorizontal, Ban, CheckCircle2, Eye,
  ArrowUpDown, ChevronLeft, ChevronRight, Star, Clock
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

// ── Admin Stats ──────────────────────────────────────────────────────────────

const PLATFORM_STATS = [
  { label: 'Total Users', value: '1.2M', change: '+12.4%', icon: Users, color: 'text-blue-500', bg: 'bg-blue-500/10' },
  { label: 'Total Courses', value: '15,432', change: '+3.2%', icon: BookOpen, color: 'text-violet-500', bg: 'bg-violet-500/10' },
  { label: 'Monthly Revenue', value: '$284K', change: '+18.7%', icon: DollarSign, color: 'text-primary', bg: 'bg-primary/10' },
  { label: 'Active Instructors', value: '8,943', change: '+6.1%', icon: TrendingUp, color: 'text-amber-500', bg: 'bg-amber-500/10' },
  { label: 'Pending Reviews', value: '127', change: 'Needs attention', icon: AlertCircle, color: 'text-orange-500', bg: 'bg-orange-500/10' },
  { label: 'Flagged Content', value: '14', change: 'Requires review', icon: Shield, color: 'text-red-500', bg: 'bg-red-500/10' },
];

export function AdminStats() {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
      {PLATFORM_STATS.map((stat, i) => (
        <div
          key={stat.label}
          className="bg-card border rounded-xl p-4 animate-fade-up"
          style={{ animationDelay: `${i * 50}ms` }}
        >
          <div className={`w-8 h-8 ${stat.bg} rounded-lg flex items-center justify-center mb-3`}>
            <stat.icon className={`w-4 h-4 ${stat.color}`} />
          </div>
          <div className="text-xl font-display font-bold">{stat.value}</div>
          <div className="text-xs text-muted-foreground">{stat.label}</div>
          <div className={`text-xs mt-1 font-medium ${stat.color}`}>{stat.change}</div>
        </div>
      ))}
    </div>
  );
}

// ── Admin Course Approvals ────────────────────────────────────────────────────

const PENDING_COURSES = [
  {
    id: '1',
    title: 'Complete Machine Learning with Python',
    instructor: 'Sarah Johnson',
    submittedAt: new Date('2024-05-28'),
    category: 'Data Science',
    lessons: 87,
    duration: '24h',
    level: 'Intermediate',
  },
  {
    id: '2',
    title: 'Docker & Kubernetes: The Complete Guide',
    instructor: 'Mike Chen',
    submittedAt: new Date('2024-05-27'),
    category: 'DevOps',
    lessons: 64,
    duration: '18h',
    level: 'Advanced',
  },
  {
    id: '3',
    title: 'UI/UX Design Fundamentals',
    instructor: 'Emma Wilson',
    submittedAt: new Date('2024-05-26'),
    category: 'Design',
    lessons: 52,
    duration: '12h',
    level: 'Beginner',
  },
];

export function AdminCourseApprovals() {
  const [courses, setCourses] = useState(PENDING_COURSES);

  const handleAction = (id: string, action: 'approve' | 'reject') => {
    setCourses((prev) => prev.filter((c) => c.id !== id));
    // Call API in real app
  };

  return (
    <div className="bg-card border rounded-xl p-6">
      <div className="flex items-center justify-between mb-5">
        <h3 className="font-display font-bold">Course Approvals</h3>
        <Badge variant="secondary" className="bg-orange-500/10 text-orange-500">
          {courses.length} pending
        </Badge>
      </div>

      {courses.length === 0 ? (
        <div className="text-center py-8">
          <CheckCircle2 className="w-8 h-8 text-primary mx-auto mb-2" />
          <p className="text-sm text-muted-foreground">All courses reviewed!</p>
        </div>
      ) : (
        <div className="space-y-3">
          {courses.map((course) => (
            <div key={course.id} className="p-3 border rounded-lg bg-secondary/20 hover:bg-secondary/40 transition-colors">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-sm font-medium line-clamp-1">{course.title}</p>
                  <div className="flex items-center gap-2 mt-1 flex-wrap">
                    <span className="text-xs text-muted-foreground">{course.instructor}</span>
                    <Badge variant="outline" className="text-[10px] px-1.5 py-0">{course.category}</Badge>
                    <span className="text-[10px] text-muted-foreground">{course.lessons} lessons · {course.duration}</span>
                  </div>
                  <p className="text-[10px] text-muted-foreground mt-1 flex items-center gap-1">
                    <Clock className="w-2.5 h-2.5" />
                    Submitted {format(course.submittedAt, 'MMM d')}
                  </p>
                </div>
                <div className="flex gap-1.5 shrink-0">
                  <Button size="sm" variant="ghost" className="w-8 h-8 p-0 text-muted-foreground hover:text-foreground">
                    <Eye className="w-3.5 h-3.5" />
                  </Button>
                  <Button
                    size="sm"
                    className="h-7 px-2 text-xs bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground"
                    onClick={() => handleAction(course.id, 'approve')}
                  >
                    Approve
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-7 px-2 text-xs text-destructive border-destructive/30 hover:bg-destructive hover:text-destructive-foreground"
                    onClick={() => handleAction(course.id, 'reject')}
                  >
                    Reject
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Admin User Table ──────────────────────────────────────────────────────────

const MOCK_USERS = [
  { id: '1', name: 'Alice Johnson', email: 'alice@example.com', role: 'STUDENT', status: 'active', courses: 8, joinedAt: new Date('2023-09-15'), image: '' },
  { id: '2', name: 'Bob Smith', email: 'bob@example.com', role: 'INSTRUCTOR', status: 'active', courses: 3, revenue: 12450, joinedAt: new Date('2023-04-20'), image: '' },
  { id: '3', name: 'Carol White', email: 'carol@example.com', role: 'STUDENT', status: 'suspended', courses: 2, joinedAt: new Date('2024-01-08'), image: '' },
  { id: '4', name: 'David Lee', email: 'david@example.com', role: 'INSTRUCTOR', status: 'active', courses: 7, revenue: 34780, joinedAt: new Date('2022-11-30'), image: '' },
  { id: '5', name: 'Eva Martinez', email: 'eva@example.com', role: 'STUDENT', status: 'active', courses: 14, joinedAt: new Date('2023-07-22'), image: '' },
  { id: '6', name: 'Frank Brown', email: 'frank@example.com', role: 'ADMIN', status: 'active', courses: 0, joinedAt: new Date('2022-01-01'), image: '' },
];

const ROLE_COLORS: Record<string, string> = {
  STUDENT: 'text-blue-500 bg-blue-500/10 border-blue-500/20',
  INSTRUCTOR: 'text-violet-500 bg-violet-500/10 border-violet-500/20',
  ADMIN: 'text-red-500 bg-red-500/10 border-red-500/20',
  ENTERPRISE_ADMIN: 'text-amber-500 bg-amber-500/10 border-amber-500/20',
};

export function AdminUserTable() {
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('ALL');
  const [users, setUsers] = useState(MOCK_USERS);
  const [page, setPage] = useState(1);
  const PER_PAGE = 5;

  const filtered = users.filter((u) => {
    const matchSearch = u.name.toLowerCase().includes(search.toLowerCase()) ||
      u.email.toLowerCase().includes(search.toLowerCase());
    const matchRole = roleFilter === 'ALL' || u.role === roleFilter;
    return matchSearch && matchRole;
  });

  const paginated = filtered.slice((page - 1) * PER_PAGE, page * PER_PAGE);
  const totalPages = Math.ceil(filtered.length / PER_PAGE);

  const handleSuspend = (id: string) => {
    setUsers((prev) => prev.map((u) =>
      u.id === id ? { ...u, status: u.status === 'suspended' ? 'active' : 'suspended' } : u
    ));
  };

  return (
    <div className="bg-card border rounded-xl overflow-hidden">
      {/* Header */}
      <div className="p-6 border-b">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display font-bold">User Management</h3>
          <span className="text-sm text-muted-foreground">{filtered.length} users</span>
        </div>
        <div className="flex gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1); }}
              placeholder="Search users..."
              className="pl-9 h-9"
            />
          </div>
          <select
            value={roleFilter}
            onChange={(e) => { setRoleFilter(e.target.value); setPage(1); }}
            className="px-3 py-1.5 text-sm bg-background border rounded-lg outline-none focus:ring-2 ring-primary/30"
          >
            <option value="ALL">All Roles</option>
            <option value="STUDENT">Students</option>
            <option value="INSTRUCTOR">Instructors</option>
            <option value="ADMIN">Admins</option>
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b bg-secondary/30">
              <th className="text-left px-6 py-3 text-xs font-semibold text-muted-foreground">User</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground">Role</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground">Status</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground">Courses</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground">Joined</th>
              <th className="px-4 py-3"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {paginated.map((user) => (
              <tr key={user.id} className="hover:bg-secondary/20 transition-colors">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-8 h-8">
                      <AvatarImage src={user.image} />
                      <AvatarFallback className="bg-primary/20 text-primary text-xs font-bold">
                        {user.name[0]}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium text-sm">{user.name}</p>
                      <p className="text-xs text-muted-foreground">{user.email}</p>
                    </div>
                  </div>
                </td>
                <td className="px-4 py-4">
                  <span className={cn('text-xs font-medium px-2 py-0.5 rounded-full border', ROLE_COLORS[user.role])}>
                    {user.role}
                  </span>
                </td>
                <td className="px-4 py-4">
                  <span className={cn(
                    'text-xs font-medium px-2 py-0.5 rounded-full',
                    user.status === 'active'
                      ? 'text-primary bg-primary/10'
                      : 'text-destructive bg-destructive/10'
                  )}>
                    {user.status}
                  </span>
                </td>
                <td className="px-4 py-4 text-muted-foreground">{user.courses}</td>
                <td className="px-4 py-4 text-muted-foreground text-xs">
                  {format(user.joinedAt, 'MMM d, yyyy')}
                </td>
                <td className="px-4 py-4">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="w-8 h-8">
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>
                        <Eye className="mr-2 w-4 h-4" />
                        View Profile
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleSuspend(user.id)}>
                        <Ban className="mr-2 w-4 h-4" />
                        {user.status === 'suspended' ? 'Unsuspend' : 'Suspend'} User
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-between px-6 py-4 border-t">
        <p className="text-xs text-muted-foreground">
          Showing {Math.min((page - 1) * PER_PAGE + 1, filtered.length)}–{Math.min(page * PER_PAGE, filtered.length)} of {filtered.length}
        </p>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" disabled={page === 1} onClick={() => setPage(p => p - 1)}>
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <span className="text-xs px-2">{page} / {totalPages}</span>
          <Button variant="outline" size="sm" disabled={page === totalPages} onClick={() => setPage(p => p + 1)}>
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
