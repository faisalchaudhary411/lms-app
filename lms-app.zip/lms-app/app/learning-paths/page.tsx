import Link from 'next/link';
import Image from 'next/image';
import { Navbar } from '@/components/layout/Navbar';
import { Footer } from '@/components/layout/Footer';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  BookOpen, Clock, Users, TrendingUp, Award, ChevronRight,
  Zap, Star, GraduationCap
} from 'lucide-react';
import { cn } from '@/lib/utils';

const PATHS = [
  {
    id: '1', title: 'Full-Stack Web Developer', slug: 'full-stack-web-developer',
    type: 'CAREER_TRACK', thumbnail: 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=800&h=450&fit=crop',
    description: 'Master HTML, CSS, JavaScript, React, Node.js, and databases to build complete web applications from scratch.',
    courses: 8, duration: '6 months', difficulty: 'BEGINNER', enrolled: 14200, avgRating: 4.8,
    price: 199, outcomes: ['Build full-stack web apps', 'Land junior dev roles', 'Master React & Node.js'],
    skills: ['HTML/CSS', 'JavaScript', 'React', 'Node.js', 'PostgreSQL', 'REST APIs'],
    gradient: 'from-blue-600 to-violet-600',
  },
  {
    id: '2', title: 'Data Scientist', slug: 'data-scientist',
    type: 'SPECIALIZATION', thumbnail: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=450&fit=crop',
    description: 'Learn Python, statistics, machine learning, and data visualisation to become a data-driven decision maker.',
    courses: 6, duration: '4 months', difficulty: 'INTERMEDIATE', enrolled: 9800, avgRating: 4.7,
    price: 149, outcomes: ['Analyse data with Python & R', 'Build ML models', 'Create dashboards'],
    skills: ['Python', 'Pandas', 'Scikit-learn', 'SQL', 'Tableau', 'Statistics'],
    gradient: 'from-violet-600 to-pink-600',
  },
  {
    id: '3', title: 'AI / ML Engineer', slug: 'ai-ml-engineer',
    type: 'SPECIALIZATION', thumbnail: 'https://images.unsplash.com/photo-1677442135703-1787eea5ce01?w=800&h=450&fit=crop',
    description: 'Go from Python basics to deploying production ML models. Cover deep learning, NLP, and computer vision.',
    courses: 9, duration: '8 months', difficulty: 'ADVANCED', enrolled: 7600, avgRating: 4.9,
    price: 249, outcomes: ['Deploy ML models to production', 'Build LLM applications', 'Master TensorFlow & PyTorch'],
    skills: ['Python', 'TensorFlow', 'PyTorch', 'NLP', 'Computer Vision', 'MLOps'],
    gradient: 'from-orange-600 to-red-600',
  },
  {
    id: '4', title: 'Cloud Architect', slug: 'cloud-architect',
    type: 'CERTIFICATE', thumbnail: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&h=450&fit=crop',
    description: 'Prepare for AWS Solutions Architect certification. Master cloud infrastructure, security, and cost optimisation.',
    courses: 5, duration: '3 months', difficulty: 'INTERMEDIATE', enrolled: 6200, avgRating: 4.8,
    price: 129, outcomes: ['Pass AWS SAA exam', 'Design scalable architectures', 'Reduce cloud costs'],
    skills: ['AWS', 'EC2', 'S3', 'Lambda', 'CloudFormation', 'VPC'],
    gradient: 'from-amber-500 to-orange-600',
  },
  {
    id: '5', title: 'UX/Product Designer', slug: 'ux-product-designer',
    type: 'CAREER_TRACK', thumbnail: 'https://images.unsplash.com/photo-1558655146-9f40138edfeb?w=800&h=450&fit=crop',
    description: 'Master the entire design process from user research to high-fidelity prototyping with Figma.',
    courses: 7, duration: '5 months', difficulty: 'BEGINNER', enrolled: 8900, avgRating: 4.6,
    price: 179, outcomes: ['Build a design portfolio', 'Get UX design jobs', 'Master Figma'],
    skills: ['Figma', 'User Research', 'Prototyping', 'Design Systems', 'Usability Testing'],
    gradient: 'from-pink-500 to-rose-600',
  },
  {
    id: '6', title: 'DevOps Engineer', slug: 'devops-engineer',
    type: 'SPECIALIZATION', thumbnail: 'https://images.unsplash.com/photo-1605745341112-85968b19335b?w=800&h=450&fit=crop',
    description: 'Learn CI/CD pipelines, Docker, Kubernetes, and infrastructure as code to automate deployments.',
    courses: 7, duration: '5 months', difficulty: 'ADVANCED', enrolled: 5400, avgRating: 4.7,
    price: 199, outcomes: ['Build CI/CD pipelines', 'Master Kubernetes', 'Automate infrastructure'],
    skills: ['Docker', 'Kubernetes', 'GitHub Actions', 'Terraform', 'AWS', 'Linux'],
    gradient: 'from-teal-500 to-cyan-600',
  },
];

const TYPE_LABELS: Record<string, string> = {
  CAREER_TRACK: '🚀 Career Track',
  SPECIALIZATION: '🎯 Specialization',
  CERTIFICATE: '📜 Certificate',
  DEGREE: '🎓 Degree',
  BOOTCAMP: '⚡ Bootcamp',
};

const LEVEL_COLORS: Record<string, string> = {
  BEGINNER: 'text-primary bg-primary/10 border-primary/20',
  INTERMEDIATE: 'text-blue-500 bg-blue-500/10 border-blue-500/20',
  ADVANCED: 'text-violet-500 bg-violet-500/10 border-violet-500/20',
};

export default function LearningPathsPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="pt-20">
        {/* Hero */}
        <section className="py-20 bg-gradient-to-b from-primary/5 to-background border-b">
          <div className="container mx-auto px-4 max-w-6xl text-center">
            <Badge variant="secondary" className="mb-4 text-xs">Learning Paths</Badge>
            <h1 className="text-4xl sm:text-5xl font-display font-bold mb-4 leading-tight">
              Structured paths to your dream career
            </h1>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto mb-8">
              Curated multi-course programs designed to take you from zero to job-ready.
              Learn in the right order, faster.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-6 text-sm text-muted-foreground">
              {[
                { icon: GraduationCap, text: '45K+ students enrolled' },
                { icon: Award, text: 'Industry-recognised certificates' },
                { icon: TrendingUp, text: '87% land jobs within 6 months' },
              ].map((item) => (
                <div key={item.text} className="flex items-center gap-2">
                  <item.icon className="w-4 h-4 text-primary" />
                  {item.text}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Paths grid */}
        <section className="py-16">
          <div className="container mx-auto px-4 max-w-6xl">
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
              {PATHS.map((path, i) => (
                <Link
                  key={path.id}
                  href={`/learning-paths/${path.slug}`}
                  className="bg-card border rounded-2xl overflow-hidden hover:border-primary/30 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 group flex flex-col animate-fade-up"
                  style={{ animationDelay: `${i * 80}ms` }}
                >
                  {/* Thumbnail */}
                  <div className="relative h-44 overflow-hidden">
                    <Image
                      src={path.thumbnail}
                      alt={path.title}
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className={cn('absolute inset-0 bg-gradient-to-br opacity-80', path.gradient)} />
                    <div className="absolute inset-0 flex flex-col justify-between p-5">
                      <div className="flex items-start justify-between">
                        <Badge className="bg-white/20 text-white border-0 text-[10px]">
                          {TYPE_LABELS[path.type]}
                        </Badge>
                        <Badge className={cn('text-[10px] border', LEVEL_COLORS[path.difficulty])}>
                          {path.difficulty}
                        </Badge>
                      </div>
                      <div>
                        <h2 className="text-xl font-display font-bold text-white leading-tight">{path.title}</h2>
                      </div>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-5 flex-1 flex flex-col">
                    <p className="text-sm text-muted-foreground line-clamp-2 mb-4 leading-relaxed">
                      {path.description}
                    </p>

                    {/* Skills */}
                    <div className="flex flex-wrap gap-1.5 mb-4">
                      {path.skills.slice(0, 4).map((skill) => (
                        <span key={skill} className="tag-pill text-[10px]">{skill}</span>
                      ))}
                      {path.skills.length > 4 && (
                        <span className="tag-pill text-[10px]">+{path.skills.length - 4}</span>
                      )}
                    </div>

                    {/* Meta */}
                    <div className="flex items-center gap-4 text-xs text-muted-foreground mb-4">
                      <span className="flex items-center gap-1">
                        <BookOpen className="w-3 h-3" />{path.courses} courses
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />{path.duration}
                      </span>
                      <span className="flex items-center gap-1">
                        <Users className="w-3 h-3" />{path.enrolled.toLocaleString()}
                      </span>
                      <span className="flex items-center gap-1 text-amber-500 font-semibold">
                        <Star className="w-3 h-3 fill-amber-500" />{path.avgRating}
                      </span>
                    </div>

                    {/* Price + CTA */}
                    <div className="flex items-center justify-between mt-auto pt-4 border-t">
                      <div>
                        <span className="text-lg font-display font-bold">${path.price}</span>
                        <span className="text-xs text-muted-foreground ml-1">one-time</span>
                      </div>
                      <Button size="sm" className="gap-1.5">
                        Explore Path <ChevronRight className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-20 border-t bg-gradient-to-b from-primary/5 to-background">
          <div className="container mx-auto px-4 max-w-3xl text-center">
            <Zap className="w-12 h-12 text-primary mx-auto mb-4" />
            <h2 className="text-3xl font-display font-bold mb-3">Not sure where to start?</h2>
            <p className="text-muted-foreground mb-8">
              Take our 2-minute skill assessment and we&apos;ll recommend the perfect learning path for your goals.
            </p>
            <div className="flex gap-3 justify-center">
              <Button size="lg" className="gap-2">
                <Zap className="w-4 h-4" />Take Skill Assessment
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link href="/courses">Browse Courses</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
