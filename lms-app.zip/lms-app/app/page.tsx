import { Navbar } from '@/components/layout/Navbar';
import { HeroSection } from '@/components/layout/HeroSection';
import { PricingSection } from '@/components/layout/PricingSection';
import { Footer } from '@/components/layout/Footer';
import {
  StatsSection,
  FeaturedCategories,
  FeaturedCourses,
  LearningPaths,
  InstructorsSection,
  TestimonialsSection,
} from '@/components/dashboard/DashboardComponents';

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        <HeroSection />
        <StatsSection />
        <FeaturedCategories />
        <FeaturedCourses />
        <LearningPaths />
        <InstructorsSection />
        <TestimonialsSection />
        <PricingSection />
      </main>
      <Footer />
    </div>
  );
}
