import Image from 'next/image';
import Link from 'next/link';
import { Navbar } from '@/components/layout/Navbar';
import { Footer } from '@/components/layout/Footer';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Star, Users, BookOpen, Check, Search } from 'lucide-react';
import { Input } from '@/components/ui/input';

const INSTRUCTORS = [
  { id: '1', slug: 'andrew-mead', name: 'Andrew Mead', headline: 'Full-Stack Developer & University Teacher', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop&crop=face', rating: 4.8, students: 283451, courses: 12, reviews: 52400, isVerified: true, expertise: ['React', 'Node.js', 'GraphQL'], bio: 'Andrew is a full-stack developer and teacher at The University of Pennsylvania. Teaching 280K+ students.' },
  { id: '2', slug: 'sarah-johnson', name: 'Sarah Johnson', headline: 'Data Scientist at Google · PhD Statistics', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop&crop=face', rating: 4.9, students: 194320, courses: 8, reviews: 38200, isVerified: true, expertise: ['Python', 'ML', 'Deep Learning'], bio: 'Data Scientist with 10+ years experience at Google, specialising in ML infrastructure and NLP.' },
  { id: '3', slug: 'mike-chen', name: 'Mike Chen', headline: 'AWS Certified Solutions Architect', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=face', rating: 4.8, students: 156700, courses: 6, reviews: 28900, isVerified: true, expertise: ['AWS', 'DevOps', 'Kubernetes'], bio: 'AWS Community Hero and Solutions Architect. Helped 150+ companies migrate to cloud.' },
  { id: '4', slug: 'emma-wilson', name: 'Emma Wilson', headline: 'Lead UX Designer at Meta', avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&h=200&fit=crop&crop=face', rating: 4.7, students: 134200, courses: 9, reviews: 24500, isVerified: true, expertise: ['Figma', 'UX Research', 'Design Systems'], bio: 'Senior UX designer with 12 years in product design, having shipped products used by billions.' },
  { id: '5', slug: 'colt-steele', name: 'Colt Steele', headline: 'Bootcamp Instructor & Developer', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop&crop=face', rating: 4.9, students: 178500, courses: 15, reviews: 42100, isVerified: true, expertise: ['JavaScript', 'Python', 'SQL'], bio: 'Former bootcamp lead instructor turned online educator. Making complex topics approachable.' },
  { id: '6', slug: 'alex-kumar', name: 'Alex Kumar', headline: 'DevOps Lead & Container Expert', avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=200&h=200&fit=crop&crop=face', rating: 4.7, students: 98400, courses: 7, reviews: 18300, isVerified: false, expertise: ['Docker', 'Kubernetes', 'Terraform'], bio: 'DevOps practitioner with 8 years building scalable infrastructure at startups and enterprises.' },
  { id: '7', slug: 'dr-smith', name: 'Dr. Angela Yu', headline: 'Physician turned Developer & Tech Lead', avatar: 'https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=200&h=200&fit=crop&crop=face', rating: 4.8, students: 112400, courses: 5, reviews: 24300, isVerified: true, expertise: ['Python', 'iOS', 'Flutter'], bio: 'Doctor turned developer. Lead instructor at the London App Brewery.' },
  { id: '8', slug: 'stephen-grider', name: 'Stephen Grider', headline: 'Engineering Architect & Technical Author', avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200&h=200&fit=crop&crop=face', rating: 4.8, students: 267000, courses: 18, reviews: 48700, isVerified: true, expertise: ['React', 'TypeScript', 'gRPC'], bio: 'Building and scaling apps with React and NodeJS. Author of several technical books.' },
];

export default function InstructorsPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="pt-20">
        {/* Hero */}
        <section className="py-16 border-b bg-gradient-to-b from-secondary/30 to-background">
          <div className="container mx-auto px-4 max-w-6xl text-center">
            <Badge variant="secondary" className="mb-4 text-xs">Expert Instructors</Badge>
            <h1 className="text-4xl font-display font-bold mb-3">Learn from world-class experts</h1>
            <p className="text-muted-foreground max-w-xl mx-auto mb-8">
              Our instructors are industry professionals with real-world experience teaching what actually matters.
            </p>
            <div className="flex items-center gap-3 max-w-md mx-auto">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input placeholder="Search instructors..." className="pl-9 h-11" />
              </div>
            </div>
          </div>
        </section>

        {/* Instructors grid */}
        <section className="py-16">
          <div className="container mx-auto px-4 max-w-6xl">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {INSTRUCTORS.map((inst, i) => (
                <Link
                  key={inst.id}
                  href={`/instructors/${inst.slug}`}
                  className="bg-card border rounded-2xl p-6 hover:border-primary/30 hover:shadow-md hover:-translate-y-0.5 transition-all group text-center animate-fade-up"
                  style={{ animationDelay: `${i * 60}ms` }}
                >
                  {/* Avatar */}
                  <div className="relative w-20 h-20 mx-auto mb-4">
                    <Image src={inst.avatar} alt={inst.name} fill className="rounded-full object-cover" />
                    {inst.isVerified && (
                      <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-primary rounded-full flex items-center justify-center shadow-sm">
                        <Check className="w-3 h-3 text-white" />
                      </div>
                    )}
                  </div>

                  <h3 className="font-display font-bold mb-0.5 group-hover:text-primary transition-colors">{inst.name}</h3>
                  <p className="text-xs text-muted-foreground line-clamp-2 mb-3">{inst.headline}</p>

                  {/* Expertise */}
                  <div className="flex flex-wrap justify-center gap-1 mb-4">
                    {inst.expertise.slice(0, 3).map((skill) => (
                      <span key={skill} className="tag-pill text-[10px]">{skill}</span>
                    ))}
                  </div>

                  {/* Stats */}
                  <div className="grid grid-cols-3 gap-2 pt-3 border-t">
                    <div>
                      <div className="text-sm font-bold text-amber-500 flex items-center justify-center gap-0.5">
                        <Star className="w-3 h-3 fill-amber-500" />{inst.rating}
                      </div>
                      <div className="text-[10px] text-muted-foreground">rating</div>
                    </div>
                    <div>
                      <div className="text-sm font-bold">{inst.students >= 1000 ? `${Math.round(inst.students / 1000)}K` : inst.students}</div>
                      <div className="text-[10px] text-muted-foreground">students</div>
                    </div>
                    <div>
                      <div className="text-sm font-bold">{inst.courses}</div>
                      <div className="text-[10px] text-muted-foreground">courses</div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>

            <div className="text-center mt-10">
              <Button variant="outline" size="lg">Load More Instructors</Button>
            </div>
          </div>
        </section>

        {/* Become instructor CTA */}
        <section className="py-20 border-t bg-gradient-to-b from-primary/5 to-background">
          <div className="container mx-auto px-4 max-w-4xl">
            <div className="bg-gradient-to-r from-primary/10 via-emerald-500/5 to-background border border-primary/20 rounded-3xl p-10 flex flex-col md:flex-row items-center gap-8">
              <div className="flex-1">
                <h2 className="text-3xl font-display font-bold mb-3">Become an instructor</h2>
                <p className="text-muted-foreground leading-relaxed mb-4">
                  Share your expertise with 4 million+ learners. Earn money doing what you love and build your personal brand.
                </p>
                <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                  {['Set your own schedule', 'Keep up to 70% revenue', 'Free tools & support', 'Global audience'].map((b) => (
                    <div key={b} className="flex items-center gap-1.5">
                      <Check className="w-3.5 h-3.5 text-primary" />{b}
                    </div>
                  ))}
                </div>
              </div>
              <Button size="lg" className="shrink-0" asChild>
                <Link href="/instructor">Start Teaching Today</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
