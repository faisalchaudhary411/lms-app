// app/api/quizzes/attempt/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { z } from 'zod';

const attemptSchema = z.object({
  quizId: z.string(),
  answers: z.array(z.object({
    questionId: z.string(),
    answer: z.string(),
  })),
  timeTaken: z.number(),
});

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const { quizId, answers, timeTaken } = attemptSchema.parse(await req.json());

    const quiz = await prisma.quiz.findUnique({
      where: { id: quizId },
      include: { questions: { include: { options: true } } },
    });
    if (!quiz) return NextResponse.json({ error: 'Quiz not found' }, { status: 404 });

    // Check attempt limit
    const existingAttempts = await prisma.quizAttempt.count({
      where: { quizId, userId: session.user.id },
    });
    if (existingAttempts >= quiz.maxAttempts) {
      return NextResponse.json({ error: 'Maximum attempts reached' }, { status: 403 });
    }

    // Grade answers
    let totalPoints = 0;
    let earnedPoints = 0;
    const gradedAnswers = answers.map((a) => {
      const question = quiz.questions.find((q) => q.id === a.questionId);
      if (!question) return { ...a, isCorrect: false, pointsEarned: 0 };
      const isCorrect = a.answer === question.correctAnswer;
      totalPoints += question.points;
      if (isCorrect) earnedPoints += question.points;
      return { questionId: a.questionId, answer: a.answer, isCorrect, pointsEarned: isCorrect ? question.points : 0 };
    });

    const score = totalPoints > 0 ? Math.round((earnedPoints / totalPoints) * 100) : 0;
    const isPassed = score >= quiz.passingScore;

    const attempt = await prisma.quizAttempt.create({
      data: {
        userId: session.user.id,
        quizId,
        answers: gradedAnswers as any,
        score,
        isPassed,
        timeTaken,
      },
    });

    // Award XP for passing
    if (isPassed) {
      await prisma.user.update({
        where: { id: session.user.id },
        data: { xpPoints: { increment: 25 }, totalXp: { increment: 25 } },
      });
    }

    return NextResponse.json({
      attemptId: attempt.id,
      score,
      isPassed,
      passingScore: quiz.passingScore,
      answers: gradedAnswers,
      totalPoints,
      earnedPoints,
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.errors[0].message }, { status: 400 });
    }
    return NextResponse.json({ error: 'Failed to submit quiz' }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const quizId = searchParams.get('quizId');
  if (!quizId) return NextResponse.json({ error: 'quizId required' }, { status: 400 });

  const attempts = await prisma.quizAttempt.findMany({
    where: { quizId, userId: session.user.id },
    orderBy: { completedAt: 'desc' },
  });

  return NextResponse.json(attempts);
}
