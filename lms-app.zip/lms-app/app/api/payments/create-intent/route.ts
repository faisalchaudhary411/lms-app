// app/api/payments/create-intent/route.ts
import { NextRequest, NextResponse } from 'next/server';
import Stripe from 'stripe';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2024-04-10' });

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const { courseId, couponCode } = await req.json();

    const course = await prisma.course.findUnique({ where: { id: courseId } });
    if (!course) return NextResponse.json({ error: 'Course not found' }, { status: 404 });

    if (course.isFree) return NextResponse.json({ error: 'Course is free' }, { status: 400 });

    let price = course.discountPrice ?? course.price;
    let discountAmount = 0;

    // Apply coupon
    if (couponCode) {
      const coupon = await prisma.coupon.findUnique({
        where: { code: couponCode },
        include: { courses: true },
      });
      if (coupon && coupon.isActive && new Date() < coupon.validTo) {
        if (coupon.courses.length === 0 || coupon.courses.some((c) => c.courseId === courseId)) {
          discountAmount = coupon.discountType === 'PERCENTAGE'
            ? (price * coupon.discountValue) / 100
            : coupon.discountValue;
          price = Math.max(0, price - discountAmount);
        }
      }
    }

    const amountInCents = Math.round(price * 100);

    const paymentIntent = await stripe.paymentIntents.create({
      amount: amountInCents,
      currency: 'usd',
      metadata: {
        userId: session.user.id,
        courseId,
        couponCode: couponCode || '',
      },
      automatic_payment_methods: { enabled: true },
    });

    return NextResponse.json({ clientSecret: paymentIntent.client_secret });
  } catch (error) {
    return NextResponse.json({ error: 'Payment intent creation failed' }, { status: 500 });
  }
}
