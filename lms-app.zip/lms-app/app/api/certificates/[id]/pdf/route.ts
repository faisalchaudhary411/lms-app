// app/api/certificates/[id]/pdf/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { format } from 'date-fns';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const certificate = await prisma.certificate.findUnique({
    where: { id: params.id },
    include: {
      user: { select: { name: true } },
      course: {
        include: {
          instructor: { include: { user: { select: { name: true } } } },
        },
      },
    },
  });

  if (!certificate) return NextResponse.json({ error: 'Certificate not found' }, { status: 404 });
  if (certificate.userId !== session.user.id) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

  // Generate PDF using a lightweight approach: build HTML and convert.
  // In production, use a service like Puppeteer, react-pdf, or a PDF microservice.
  // For now, redirect to a printable HTML certificate view that the browser can "Print to PDF".
  const verifyUrl = `${process.env.NEXT_PUBLIC_URL}/certificates/verify/${certificate.verificationId}`;

  const html = `
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>Certificate - ${certificate.course.title}</title>
<style>
  @page { size: A4 landscape; margin: 0; }
  body { font-family: Georgia, serif; margin: 0; padding: 60px; background: white; color: #1a1a1a; }
  .cert { border: 4px solid #22c55e; border-radius: 16px; padding: 60px; text-align: center; height: 100%; box-sizing: border-box; }
  .label { font-size: 12px; letter-spacing: 4px; color: #16a34a; text-transform: uppercase; font-weight: 600; margin-bottom: 24px; }
  .name { font-size: 42px; font-weight: bold; margin: 16px 0; }
  .course { font-size: 22px; font-weight: bold; color: #374151; max-width: 600px; margin: 16px auto; }
  .meta { color: #6b7280; font-size: 13px; margin-top: 12px; }
  .footer { display: flex; justify-content: space-between; margin-top: 60px; padding-top: 20px; }
  .sig { font-family: cursive; font-size: 20px; border-bottom: 1px solid #ccc; padding-bottom: 4px; }
</style>
</head>
<body>
  <div class="cert">
    <div class="label">Certificate of Completion</div>
    <p>This certifies that</p>
    <div class="name">${certificate.user.name}</div>
    <p>has successfully completed</p>
    <div class="course">${certificate.course.title}</div>
    <div class="meta">Issued ${format(new Date(certificate.issuedAt), 'MMMM d, yyyy')} · Verification ID: ${certificate.verificationId}</div>
    <div class="footer">
      <div class="sig">${certificate.course.instructor.user.name}</div>
      <div class="sig">${verifyUrl}</div>
    </div>
  </div>
</body>
</html>`;

  return new NextResponse(html, {
    headers: { 'Content-Type': 'text/html' },
  });
}
