// app/api/instructor/courses/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { slugify } from '@/lib/utils';
import { z } from 'zod';

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const profile = await prisma.instructorProfile.findUnique({
    where: { userId: session.user.id },
  });
  if (!profile) return NextResponse.json({ error: 'Not an instructor' }, { status: 403 });

  const courses = await prisma.course.findMany({
    where: { instructorId: profile.id },
    include: {
      category: { select: { name: true } },
      _count: { select: { enrollments: true, reviews: true } },
    },
    orderBy: { updatedAt: 'desc' },
  });

  return NextResponse.json(courses);
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    let profile = await prisma.instructorProfile.findUnique({
      where: { userId: session.user.id },
    });

    // Auto-create instructor profile if missing
    if (!profile) {
      profile = await prisma.instructorProfile.create({
        data: { userId: session.user.id },
      });
      await prisma.user.update({
        where: { id: session.user.id },
        data: { role: 'INSTRUCTOR' },
      });
    }

    const body = await req.json();
    const baseSlug = slugify(body.title || 'untitled');

    // Ensure unique slug
    const existingSlug = await prisma.course.findUnique({ where: { slug: baseSlug } });
    const slug = existingSlug ? `${baseSlug}-${Date.now()}` : baseSlug;

    // Find or create category
    let category = await prisma.category.findFirst({
      where: { name: body.category },
    });
    if (!category) {
      category = await prisma.category.create({
        data: {
          name: body.category || 'General',
          slug: slugify(body.category || 'general'),
          icon: '📚',
        },
      });
    }

    const course = await prisma.course.create({
      data: {
        title: body.title || 'Untitled Course',
        slug,
        description: body.description || '',
        shortDescription: body.shortDescription || '',
        thumbnail: body.thumbnail || '',
        price: parseFloat(body.price) || 0,
        isFree: body.isFree || false,
        level: body.level || 'ALL_LEVELS',
        language: body.language || 'English',
        outcomes: body.outcomes || [],
        requirements: body.requirements || [],
        tags: body.tags || [],
        categoryId: category.id,
        instructorId: profile.id,
        status: 'DRAFT',
      },
    });

    // Create sections and lessons if provided
    if (body.sections?.length) {
      for (let i = 0; i < body.sections.length; i++) {
        const sec = body.sections[i];
        const section = await prisma.section.create({
          data: {
            courseId: course.id,
            title: sec.title,
            order: i,
          },
        });
        if (sec.lessons?.length) {
          for (let j = 0; j < sec.lessons.length; j++) {
            const lesson = sec.lessons[j];
            await prisma.lesson.create({
              data: {
                sectionId: section.id,
                title: lesson.title,
                type: lesson.type,
                order: j,
              },
            });
          }
        }
      }
    }

    return NextResponse.json(course, { status: 201 });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to create course' }, { status: 500 });
  }
}
