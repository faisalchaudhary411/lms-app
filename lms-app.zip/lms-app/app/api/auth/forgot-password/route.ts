// app/api/auth/forgot-password/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { sendPasswordResetEmail } from '@/lib/email';
import { generateVerificationId } from '@/lib/utils';

export async function POST(req: NextRequest) {
  try {
    const { email } = z.object({ email: z.string().email() }).parse(await req.json());

    const user = await prisma.user.findUnique({ where: { email } });
    // Always respond with success for security (don't reveal if email exists)
    if (!user) return NextResponse.json({ success: true });

    const token = generateVerificationId();
    const expires = new Date(Date.now() + 60 * 60 * 1000); // 1 hour

    await prisma.passwordResetToken.deleteMany({ where: { userId: user.id } });
    await prisma.passwordResetToken.create({
      data: { userId: user.id, token, expires },
    });

    await sendPasswordResetEmail(email, user.name || 'Learner', token);

    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: 'Request failed' }, { status: 500 });
  }
}
