// app/api/lessons/progress/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const { lessonId, position, isCompleted } = await req.json();

    const lesson = await prisma.lesson.findUnique({
      where: { id: lessonId },
      include: { section: { include: { course: true } } },
    });
    if (!lesson) return NextResponse.json({ error: 'Lesson not found' }, { status: 404 });

    const enrollment = await prisma.enrollment.findUnique({
      where: {
        userId_courseId: {
          userId: session.user.id,
          courseId: lesson.section.courseId,
        },
      },
    });
    if (!enrollment) return NextResponse.json({ error: 'Not enrolled' }, { status: 403 });

    const progress = await prisma.lessonProgress.upsert({
      where: {
        userId_lessonId_enrollmentId: {
          userId: session.user.id,
          lessonId,
          enrollmentId: enrollment.id,
        },
      },
      update: {
        videoPosition: position,
        isCompleted: isCompleted || false,
        completedAt: isCompleted ? new Date() : undefined,
      },
      create: {
        userId: session.user.id,
        lessonId,
        enrollmentId: enrollment.id,
        videoPosition: position,
        isCompleted: isCompleted || false,
        completedAt: isCompleted ? new Date() : undefined,
      },
    });

    // Update enrollment progress if lesson completed
    if (isCompleted) {
      const allProgress = await prisma.lessonProgress.findMany({
        where: { enrollmentId: enrollment.id, isCompleted: true },
      });

      const course = lesson.section.course;
      const completionPct = Math.round((allProgress.length / course.totalLessons) * 100);
      const courseCompleted = completionPct >= 100;

      await prisma.enrollment.update({
        where: { id: enrollment.id },
        data: {
          progress: completionPct,
          completedLessons: allProgress.map((p) => p.lessonId),
          currentLessonId: lessonId,
          lastAccessedAt: new Date(),
          isCompleted: courseCompleted,
          completedAt: courseCompleted ? new Date() : undefined,
        },
      });

      // Award XP
      await prisma.user.update({
        where: { id: session.user.id },
        data: { xpPoints: { increment: 10 }, totalXp: { increment: 10 } },
      });

      // Issue certificate on completion
      if (courseCompleted && course.hasCertificate) {
        const existingCert = await prisma.certificate.findUnique({
          where: { enrollmentId: enrollment.id },
        });
        if (!existingCert) {
          const cert = await prisma.certificate.create({
            data: {
              userId: session.user.id,
              courseId: course.id,
              enrollmentId: enrollment.id,
              skills: course.tags,
            },
          });
          await prisma.notification.create({
            data: {
              userId: session.user.id,
              type: 'CERTIFICATE_EARNED',
              title: '🎉 Certificate earned!',
              message: `Congratulations! You completed "${course.title}"`,
              link: `/dashboard/certificates/${cert.id}`,
            },
          });
        }
      }
    }

    // Update last accessed
    await prisma.enrollment.update({
      where: { id: enrollment.id },
      data: { currentPosition: position, lastAccessedAt: new Date() },
    });

    return NextResponse.json(progress);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to update progress' }, { status: 500 });
  }
}
