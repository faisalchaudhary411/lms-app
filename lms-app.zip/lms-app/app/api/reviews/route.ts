// app/api/reviews/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { z } from 'zod';

const createSchema = z.object({
  courseId: z.string(),
  rating: z.number().min(1).max(5),
  title: z.string().max(100).optional(),
  content: z.string().min(10).max(2000),
});

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const courseId = searchParams.get('courseId');
  const page = parseInt(searchParams.get('page') || '1');
  const limit = parseInt(searchParams.get('limit') || '10');
  const sort = searchParams.get('sort') || 'recent';

  if (!courseId) return NextResponse.json({ error: 'courseId required' }, { status: 400 });

  const orderBy: any =
    sort === 'highest' ? { rating: 'desc' }
    : sort === 'lowest' ? { rating: 'asc' }
    : sort === 'helpful' ? { helpfulCount: 'desc' }
    : { createdAt: 'desc' };

  const [reviews, total, ratingDist] = await Promise.all([
    prisma.review.findMany({
      where: { courseId },
      include: { user: { select: { id: true, name: true, image: true } } },
      orderBy,
      skip: (page - 1) * limit,
      take: limit,
    }),
    prisma.review.count({ where: { courseId } }),
    prisma.review.groupBy({
      by: ['rating'],
      where: { courseId },
      _count: { rating: true },
    }),
  ]);

  const distribution: Record<number, number> = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
  ratingDist.forEach((r) => { distribution[r.rating] = r._count.rating; });

  return NextResponse.json({
    reviews,
    total,
    page,
    totalPages: Math.ceil(total / limit),
    distribution,
  });
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const data = createSchema.parse(await req.json());

    // Must be enrolled
    const enrollment = await prisma.enrollment.findUnique({
      where: { userId_courseId: { userId: session.user.id, courseId: data.courseId } },
    });
    if (!enrollment) return NextResponse.json({ error: 'Must be enrolled to review' }, { status: 403 });

    // One review per course
    const existing = await prisma.review.findUnique({
      where: { userId_courseId: { userId: session.user.id, courseId: data.courseId } },
    });
    if (existing) {
      // Update existing review
      const updated = await prisma.review.update({
        where: { id: existing.id },
        data: { rating: data.rating, title: data.title, content: data.content },
        include: { user: { select: { id: true, name: true, image: true } } },
      });
      await updateCourseRating(data.courseId);
      return NextResponse.json(updated);
    }

    const review = await prisma.review.create({
      data: { ...data, userId: session.user.id },
      include: { user: { select: { id: true, name: true, image: true } } },
    });

    await updateCourseRating(data.courseId);
    return NextResponse.json(review, { status: 201 });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.errors[0].message }, { status: 400 });
    }
    return NextResponse.json({ error: 'Failed to submit review' }, { status: 500 });
  }
}

async function updateCourseRating(courseId: string) {
  const agg = await prisma.review.aggregate({
    where: { courseId },
    _avg: { rating: true },
    _count: { rating: true },
  });
  await prisma.course.update({
    where: { id: courseId },
    data: {
      avgRating: Math.round((agg._avg.rating || 0) * 10) / 10,
      totalReviews: agg._count.rating,
    },
  });
}

export async function DELETE(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const reviewId = searchParams.get('id');
  if (!reviewId) return NextResponse.json({ error: 'Review ID required' }, { status: 400 });

  const review = await prisma.review.findUnique({ where: { id: reviewId } });
  if (!review || review.userId !== session.user.id) {
    return NextResponse.json({ error: 'Not authorised' }, { status: 403 });
  }

  await prisma.review.delete({ where: { id: reviewId } });
  await updateCourseRating(review.courseId);
  return NextResponse.json({ success: true });
}
