// app/api/wishlist/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const wishlist = await prisma.wishlist.findMany({
    where: { userId: session.user.id },
    include: {
      course: {
        include: {
          instructor: { include: { user: { select: { name: true, image: true } } } },
          category: { select: { name: true, slug: true } },
        },
      },
    },
    orderBy: { addedAt: 'desc' },
  });

  return NextResponse.json(wishlist);
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { courseId } = await req.json();
  if (!courseId) return NextResponse.json({ error: 'courseId required' }, { status: 400 });

  const existing = await prisma.wishlist.findUnique({
    where: { userId_courseId: { userId: session.user.id, courseId } },
  });

  if (existing) {
    await prisma.wishlist.delete({ where: { id: existing.id } });
    return NextResponse.json({ wishlisted: false });
  }

  const item = await prisma.wishlist.create({
    data: { userId: session.user.id, courseId },
  });
  return NextResponse.json({ wishlisted: true, item }, { status: 201 });
}

export async function DELETE(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const courseId = searchParams.get('courseId');
  if (!courseId) return NextResponse.json({ error: 'courseId required' }, { status: 400 });

  await prisma.wishlist.deleteMany({
    where: { userId: session.user.id, courseId },
  });
  return NextResponse.json({ success: true });
}
