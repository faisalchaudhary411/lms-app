// app/api/discussions/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { z } from 'zod';

const createSchema = z.object({
  courseId: z.string(),
  lessonId: z.string().optional(),
  title: z.string().min(5).max(200),
  content: z.string().min(10),
});

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const courseId = searchParams.get('courseId');
  const lessonId = searchParams.get('lessonId');
  const page = parseInt(searchParams.get('page') || '1');
  const limit = 20;

  const where: any = {};
  if (courseId) where.courseId = courseId;
  if (lessonId) where.lessonId = lessonId;

  const [discussions, total] = await Promise.all([
    prisma.discussion.findMany({
      where,
      include: {
        user: { select: { id: true, name: true, image: true, role: true } },
        _count: { select: { replies: true } },
      },
      orderBy: [{ isPinned: 'desc' }, { createdAt: 'desc' }],
      skip: (page - 1) * limit,
      take: limit,
    }),
    prisma.discussion.count({ where }),
  ]);

  return NextResponse.json({ discussions, total, page, totalPages: Math.ceil(total / limit) });
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const data = createSchema.parse(await req.json());

    const discussion = await prisma.discussion.create({
      data: { ...data, userId: session.user.id },
      include: { user: { select: { id: true, name: true, image: true } } },
    });

    return NextResponse.json(discussion, { status: 201 });
  } catch (error) {
    if (error instanceof z.ZodError) return NextResponse.json({ error: error.errors[0].message }, { status: 400 });
    return NextResponse.json({ error: 'Failed to create discussion' }, { status: 500 });
  }
}
