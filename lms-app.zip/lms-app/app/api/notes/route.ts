// app/api/notes/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const lessonId = searchParams.get('lessonId');

  const notes = await prisma.note.findMany({
    where: {
      userId: session.user.id,
      ...(lessonId ? { lessonId } : {}),
    },
    orderBy: { timestamp: 'asc' },
  });

  return NextResponse.json(notes);
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { lessonId, timestamp, content } = await req.json();

  const note = await prisma.note.create({
    data: { userId: session.user.id, lessonId, timestamp, content },
  });

  return NextResponse.json(note, { status: 201 });
}

export async function DELETE(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const id = searchParams.get('id');
  if (!id) return NextResponse.json({ error: 'Note ID required' }, { status: 400 });

  await prisma.note.deleteMany({ where: { id, userId: session.user.id } });
  return NextResponse.json({ success: true });
}
