// app/api/search/suggestions/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const q = searchParams.get('q') || '';

  if (q.length < 2) return NextResponse.json({ courses: [], categories: [], instructors: [] });

  const [courses, categories, instructors] = await Promise.all([
    prisma.course.findMany({
      where: {
        status: 'PUBLISHED',
        OR: [
          { title: { contains: q, mode: 'insensitive' } },
          { tags: { has: q } },
        ],
      },
      select: {
        id: true, title: true, slug: true, thumbnail: true,
        avgRating: true, totalStudents: true,
        instructor: { select: { user: { select: { name: true } } } },
      },
      take: 6,
      orderBy: { totalStudents: 'desc' },
    }),
    prisma.category.findMany({
      where: { name: { contains: q, mode: 'insensitive' } },
      select: { id: true, name: true, slug: true, icon: true, courseCount: true },
      take: 3,
    }),
    prisma.instructorProfile.findMany({
      where: { user: { name: { contains: q, mode: 'insensitive' } } },
      select: {
        id: true, avgRating: true, totalStudents: true,
        user: { select: { name: true, image: true } },
      },
      take: 3,
    }),
  ]);

  return NextResponse.json({ courses, categories, instructors });
}
