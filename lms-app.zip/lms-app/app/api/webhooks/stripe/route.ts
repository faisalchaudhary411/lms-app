// app/api/webhooks/stripe/route.ts
import { NextRequest, NextResponse } from 'next/server';
import Stripe from 'stripe';
import { prisma } from '@/lib/prisma';
import { headers } from 'next/headers';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2024-04-10' });

export async function POST(req: NextRequest) {
  const body = await req.text();
  const sig = headers().get('stripe-signature')!;

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(body, sig, process.env.STRIPE_WEBHOOK_SECRET!);
  } catch (err: any) {
    return NextResponse.json({ error: `Webhook Error: ${err.message}` }, { status: 400 });
  }

  switch (event.type) {
    case 'payment_intent.succeeded': {
      const pi = event.data.object as Stripe.PaymentIntent;
      const { userId, courseId, couponCode } = pi.metadata;

      const course = await prisma.course.findUnique({ where: { id: courseId } });
      if (!course) break;

      const price = course.discountPrice ?? course.price;

      // Create order
      const order = await prisma.order.create({
        data: {
          userId,
          subtotal: price,
          discount: 0,
          tax: price * 0.08,
          total: pi.amount / 100,
          couponCode: couponCode || null,
          paymentIntentId: pi.id,
          status: 'COMPLETED',
          items: {
            create: { courseId, price: course.price, discountPrice: course.discountPrice },
          },
        },
      });

      // Auto-enroll
      const existing = await prisma.enrollment.findUnique({
        where: { userId_courseId: { userId, courseId } },
      });
      if (!existing) {
        await prisma.enrollment.create({ data: { userId, courseId } });
        await prisma.course.update({
          where: { id: courseId },
          data: { totalStudents: { increment: 1 } },
        });
        await prisma.notification.create({
          data: {
            userId,
            type: 'ENROLLMENT_CONFIRMED',
            title: 'Purchase successful!',
            message: `You're now enrolled in "${course.title}". Happy learning!`,
            link: `/learn/${course.slug}`,
          },
        });
      }

      // Update coupon usage
      if (couponCode) {
        await prisma.coupon.updateMany({
          where: { code: couponCode },
          data: { usedCount: { increment: 1 } },
        });
      }

      // Award XP for purchase
      await prisma.user.update({
        where: { id: userId },
        data: { xpPoints: { increment: 50 }, totalXp: { increment: 50 } },
      });

      break;
    }

    case 'payment_intent.payment_failed': {
      const pi = event.data.object as Stripe.PaymentIntent;
      const { userId, courseId } = pi.metadata;
      await prisma.notification.create({
        data: {
          userId,
          type: 'COURSE_UPDATE',
          title: 'Payment failed',
          message: 'Your payment could not be processed. Please try again.',
          link: `/courses`,
        },
      });
      break;
    }

    case 'customer.subscription.created':
    case 'customer.subscription.updated': {
      const sub = event.data.object as Stripe.Subscription;
      const userId = sub.metadata.userId;
      const plan = sub.metadata.plan as any;
      await prisma.subscription.upsert({
        where: { stripeSubscriptionId: sub.id },
        update: {
          status: sub.status.toUpperCase() as any,
          currentPeriodEnd: new Date(sub.current_period_end * 1000),
          cancelAtPeriodEnd: sub.cancel_at_period_end,
        },
        create: {
          userId,
          plan,
          stripeSubscriptionId: sub.id,
          status: sub.status.toUpperCase() as any,
          currentPeriodStart: new Date(sub.current_period_start * 1000),
          currentPeriodEnd: new Date(sub.current_period_end * 1000),
        },
      });
      await prisma.user.update({
        where: { id: userId },
        data: {
          subscriptionPlan: plan,
          subscriptionExpiry: new Date(sub.current_period_end * 1000),
        },
      });
      break;
    }
  }

  return NextResponse.json({ received: true });
}
