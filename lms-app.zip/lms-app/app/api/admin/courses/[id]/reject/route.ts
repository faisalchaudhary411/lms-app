// app/api/admin/courses/[id]/reject/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

async function requireAdmin() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return null;
  const user = await prisma.user.findUnique({ where: { id: session.user.id } });
  if (user?.role !== 'ADMIN') return null;
  return user;
}

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

  const { reason } = await req.json().catch(() => ({ reason: '' }));

  const course = await prisma.course.update({
    where: { id: params.id },
    data: { status: 'DRAFT' },
    include: { instructor: { include: { user: true } } },
  });

  await prisma.notification.create({
    data: {
      userId: course.instructor.userId,
      type: 'COURSE_UPDATE',
      title: 'Course needs changes',
      message: reason
        ? `Your course "${course.title}" was sent back for revisions: ${reason}`
        : `Your course "${course.title}" was sent back for revisions. Please review and resubmit.`,
      link: `/instructor/courses/${course.id}/edit`,
    },
  });

  return NextResponse.json(course);
}
