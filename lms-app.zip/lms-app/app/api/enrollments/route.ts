// app/api/enrollments/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const { courseId } = await req.json();

    const course = await prisma.course.findUnique({ where: { id: courseId } });
    if (!course) return NextResponse.json({ error: 'Course not found' }, { status: 404 });

    if (!course.isFree) {
      const order = await prisma.order.findFirst({
        where: {
          userId: session.user.id,
          status: 'COMPLETED',
          items: { some: { courseId } },
        },
      });
      if (!order) return NextResponse.json({ error: 'Purchase required' }, { status: 403 });
    }

    const existing = await prisma.enrollment.findUnique({
      where: { userId_courseId: { userId: session.user.id, courseId } },
    });
    if (existing) return NextResponse.json(existing);

    const enrollment = await prisma.enrollment.create({
      data: { userId: session.user.id, courseId },
    });

    // Update course student count
    await prisma.course.update({
      where: { id: courseId },
      data: { totalStudents: { increment: 1 } },
    });

    // Create notification
    await prisma.notification.create({
      data: {
        userId: session.user.id,
        type: 'ENROLLMENT_CONFIRMED',
        title: 'Successfully enrolled!',
        message: `You are now enrolled in "${course.title}". Start learning now!`,
        link: `/learn/${course.slug}`,
      },
    });

    return NextResponse.json(enrollment, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: 'Enrollment failed' }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const enrollments = await prisma.enrollment.findMany({
    where: { userId: session.user.id },
    include: {
      course: {
        include: {
          instructor: { include: { user: { select: { name: true, image: true } } } },
          category: { select: { name: true } },
        },
      },
    },
    orderBy: { lastAccessedAt: 'desc' },
  });

  return NextResponse.json(enrollments);
}
