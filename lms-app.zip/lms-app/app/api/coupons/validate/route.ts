// app/api/coupons/validate/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const code = searchParams.get('code');
  const courseId = searchParams.get('courseId');

  if (!code) return NextResponse.json({ valid: false, error: 'Code required' }, { status: 400 });

  const coupon = await prisma.coupon.findUnique({
    where: { code: code.toUpperCase() },
    include: { courses: true },
  });

  if (!coupon) return NextResponse.json({ valid: false, error: 'Coupon not found' });
  if (!coupon.isActive) return NextResponse.json({ valid: false, error: 'Coupon is inactive' });

  const now = new Date();
  if (now < coupon.validFrom) return NextResponse.json({ valid: false, error: 'Coupon not yet active' });
  if (now > coupon.validTo) return NextResponse.json({ valid: false, error: 'Coupon has expired' });
  if (coupon.usedCount >= coupon.maxUses) return NextResponse.json({ valid: false, error: 'Coupon usage limit reached' });

  // Check if coupon applies to this course (empty courses list = applies to all)
  if (coupon.courses.length > 0 && courseId) {
    const applies = coupon.courses.some((c) => c.courseId === courseId);
    if (!applies) return NextResponse.json({ valid: false, error: 'Coupon not valid for this course' });
  }

  return NextResponse.json({
    valid: true,
    code: coupon.code,
    discountType: coupon.discountType,
    discount: coupon.discountValue,
  });
}
