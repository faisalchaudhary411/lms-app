// app/api/assignments/submit/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { z } from 'zod';

const submitSchema = z.object({
  assignmentId: z.string(),
  text: z.string().optional(),
  files: z.array(z.object({
    name: z.string(),
    url: z.string(),
    size: z.number(),
    type: z.string(),
  })).optional(),
});

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const data = submitSchema.parse(await req.json());

    const assignment = await prisma.assignment.findUnique({ where: { id: data.assignmentId } });
    if (!assignment) return NextResponse.json({ error: 'Assignment not found' }, { status: 404 });

    // Check existing submissions
    const existing = await prisma.assignmentSubmission.findMany({
      where: { assignmentId: data.assignmentId, userId: session.user.id },
      orderBy: { attempt: 'desc' },
    });

    if (existing.length >= assignment.maxResubmissions + 1 && !assignment.allowResubmission) {
      return NextResponse.json({ error: 'Maximum submissions reached' }, { status: 403 });
    }

    if (assignment.dueDate && new Date() > assignment.dueDate) {
      return NextResponse.json({ error: 'Submission deadline has passed' }, { status: 403 });
    }

    const submission = await prisma.assignmentSubmission.create({
      data: {
        userId: session.user.id,
        assignmentId: data.assignmentId,
        text: data.text,
        files: (data.files || []) as any,
        status: 'SUBMITTED',
        attempt: (existing[0]?.attempt ?? 0) + 1,
      },
    });

    // Notify instructor
    const lesson = await prisma.lesson.findUnique({
      where: { id: assignment.lessonId },
      include: { section: { include: { course: { include: { instructor: { include: { user: true } } } } } } },
    });
    if (lesson?.section?.course?.instructor?.userId) {
      await prisma.notification.create({
        data: {
          userId: lesson.section.course.instructor.userId,
          type: 'COURSE_UPDATE',
          title: 'New assignment submission',
          message: `A student submitted "${assignment.title}" for grading`,
          link: `/instructor/submissions/${submission.id}`,
        },
      });
    }

    return NextResponse.json(submission, { status: 201 });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.errors[0].message }, { status: 400 });
    }
    return NextResponse.json({ error: 'Submission failed' }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const assignmentId = searchParams.get('assignmentId');

  const submissions = await prisma.assignmentSubmission.findMany({
    where: {
      userId: session.user.id,
      ...(assignmentId ? { assignmentId } : {}),
    },
    orderBy: { submittedAt: 'desc' },
  });

  return NextResponse.json(submissions);
}
