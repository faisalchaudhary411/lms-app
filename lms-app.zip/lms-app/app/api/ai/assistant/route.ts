// app/api/ai/assistant/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const { message, history } = await req.json();

    // Fetch user context
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: {
        enrollments: {
          include: { course: { include: { category: true } } },
          orderBy: { lastAccessedAt: 'desc' },
          take: 5,
        },
        achievements: { include: { badge: true } },
      },
    });

    const enrolledCourses = user?.enrollments.map((e) => ({
      title: e.course.title,
      category: e.course.category.name,
      progress: e.progress,
    })) || [];

    const systemPrompt = `You are an intelligent learning assistant for LearnForge, a premium online learning platform.

User context:
- Name: ${user?.name || 'Learner'}
- XP Points: ${user?.xpPoints || 0}
- Level: ${user?.level || 1}
- Learning streak: ${user?.learningStreak || 0} days
- Currently enrolled: ${enrolledCourses.map((c) => `${c.title} (${c.progress}% complete)`).join(', ') || 'No courses yet'}

Your role:
1. Give personalized course recommendations based on their learning history
2. Analyze skill gaps and suggest targeted courses
3. Provide motivational support and learning tips
4. Answer questions about courses and learning paths
5. Help with career planning and skill development

Always be encouraging, specific, and actionable. When recommending courses, be concise.
Respond in JSON format with these fields:
- message: string (your response, 2-4 sentences)
- suggestions: string[] (2-3 quick follow-up questions the user might ask, optional)
- courses: { title: string, href: string }[] (1-3 course recommendations when relevant, optional)`;

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY || '',
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-haiku-4-5-20251001',
        max_tokens: 600,
        system: systemPrompt,
        messages: [
          ...history.slice(-6).map((m: any) => ({ role: m.role, content: m.content })),
          { role: 'user', content: message },
        ],
      }),
    });

    const data = await response.json();
    const rawText = data.content?.[0]?.text || '{"message":"I\'m here to help! What would you like to learn?"}';

    let parsed: any;
    try {
      parsed = JSON.parse(rawText.replace(/```json|```/g, '').trim());
    } catch {
      parsed = { message: rawText };
    }

    return NextResponse.json(parsed);
  } catch (error) {
    return NextResponse.json({
      message: "I'm having trouble connecting right now. Please try again in a moment.",
    });
  }
}
