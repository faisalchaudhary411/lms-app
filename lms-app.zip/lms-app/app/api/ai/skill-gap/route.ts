// app/api/ai/skill-gap/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const { targetRole } = await req.json();

    const enrollments = await prisma.enrollment.findMany({
      where: { userId: session.user.id },
      include: { course: { select: { tags: true, title: true, category: { select: { name: true } } } } },
    });

    const acquiredSkills = [...new Set(enrollments.flatMap((e) => e.course.tags))];

    const prompt = `A learner wants to become a "${targetRole}". They currently have these skills from completed courses: ${acquiredSkills.join(', ') || 'none yet'}.

Analyze the skill gap and return ONLY valid JSON in this format:
{
  "targetRole": "${targetRole}",
  "requiredSkills": ["skill1", "skill2", ...],
  "acquiredSkills": ["skill from their list that matches"],
  "missingSkills": ["skills they need but don't have"],
  "readinessPercent": 0-100,
  "recommendations": [
    { "skill": "skill name", "priority": "high|medium|low", "reason": "why this matters" }
  ]
}

Base requiredSkills on real industry expectations for this role. Be specific and realistic.`;

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY || '',
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-haiku-4-5-20251001',
        max_tokens: 1200,
        messages: [{ role: 'user', content: prompt }],
      }),
    });

    const data = await response.json();
    const text = data.content?.[0]?.text || '{}';
    const parsed = JSON.parse(text.replace(/```json|```/g, '').trim());

    return NextResponse.json(parsed);
  } catch (error) {
    return NextResponse.json({ error: 'Skill gap analysis failed' }, { status: 500 });
  }
}
