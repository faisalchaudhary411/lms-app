// app/api/ai/generate-quiz/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const { topic, difficulty, count = 5 } = await req.json();

    const prompt = `Generate ${count} multiple choice quiz questions about "${topic}" at ${difficulty} difficulty level.

Return ONLY valid JSON in this exact format:
{
  "questions": [
    {
      "text": "Question text here",
      "options": [
        { "id": "a", "text": "Option A" },
        { "id": "b", "text": "Option B" },
        { "id": "c", "text": "Option C" },
        { "id": "d", "text": "Option D" }
      ],
      "correctAnswer": "a",
      "explanation": "Brief explanation why this is correct",
      "points": 1
    }
  ]
}

Requirements:
- All questions must be factually accurate
- Distractors should be plausible but clearly wrong
- Explanations should be educational
- ${difficulty === 'BEGINNER' ? 'Use simple language and fundamental concepts' : difficulty === 'INTERMEDIATE' ? 'Include practical application scenarios' : 'Use advanced technical concepts and edge cases'}`;

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY || '',
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-haiku-4-5-20251001',
        max_tokens: 2000,
        messages: [{ role: 'user', content: prompt }],
      }),
    });

    const data = await response.json();
    const text = data.content?.[0]?.text || '';
    const parsed = JSON.parse(text.replace(/```json|```/g, '').trim());

    return NextResponse.json(parsed);
  } catch (error) {
    return NextResponse.json({ error: 'Quiz generation failed' }, { status: 500 });
  }
}
