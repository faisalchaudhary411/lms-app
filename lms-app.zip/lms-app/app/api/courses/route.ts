// app/api/courses/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const q = searchParams.get('q') || '';
    const category = searchParams.get('category') || '';
    const level = searchParams.get('level') || '';
    const price = searchParams.get('price') || '';
    const rating = parseFloat(searchParams.get('rating') || '0');
    const sort = searchParams.get('sort') || 'RELEVANCE';
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '12');

    const where: any = { status: 'PUBLISHED' };

    if (q) {
      where.OR = [
        { title: { contains: q, mode: 'insensitive' } },
        { shortDescription: { contains: q, mode: 'insensitive' } },
        { tags: { has: q } },
      ];
    }

    if (category) where.category = { slug: category };
    if (level) where.level = level;
    if (price === 'FREE') where.isFree = true;
    if (price === 'PAID') where.isFree = false;
    if (rating > 0) where.avgRating = { gte: rating };

    const orderBy: any = {
      RELEVANCE: { totalStudents: 'desc' },
      NEWEST: { publishedAt: 'desc' },
      HIGHEST_RATED: { avgRating: 'desc' },
      MOST_POPULAR: { totalStudents: 'desc' },
      PRICE_LOW: { price: 'asc' },
      PRICE_HIGH: { price: 'desc' },
    }[sort] || { totalStudents: 'desc' };

    const [courses, total] = await Promise.all([
      prisma.course.findMany({
        where,
        orderBy,
        skip: (page - 1) * limit,
        take: limit,
        include: {
          category: { select: { name: true, slug: true } },
          instructor: {
            include: { user: { select: { name: true, image: true } } },
          },
          _count: { select: { enrollments: true, reviews: true } },
        },
      }),
      prisma.course.count({ where }),
    ]);

    return NextResponse.json({
      data: courses,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
      hasNext: page * limit < total,
      hasPrev: page > 1,
    });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch courses' }, { status: 500 });
  }
}
