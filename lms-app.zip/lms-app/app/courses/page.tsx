import { Suspense } from 'react';
import { Navbar } from '@/components/layout/Navbar';
import { Footer } from '@/components/layout/Footer';
import {
  CourseFilters,
  CourseGrid,
  CourseSearchBar,
  CourseSortBar,
  CategoryTabs,
} from '@/components/course/CourseGrid';
import { SkeletonCourseGrid } from '@/components/ui/skeletons';

export const metadata = {
  title: 'Browse Courses',
  description: 'Discover 15,000+ expert-led courses across all topics.',
};

interface CoursesPageProps {
  searchParams: {
    q?: string;
    category?: string;
    level?: string;
    price?: string;
    rating?: string;
    duration?: string;
    language?: string;
    sort?: string;
    page?: string;
  };
}

export default function CoursesPage({ searchParams }: CoursesPageProps) {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="pt-20">
        {/* Search header */}
        <div className="border-b bg-card">
          <div className="container mx-auto px-4 max-w-7xl py-6">
            {searchParams.q ? (
              <div className="mb-4">
                <h1 className="text-2xl font-display font-bold">
                  Results for &ldquo;{searchParams.q}&rdquo;
                </h1>
                <p className="text-muted-foreground text-sm mt-1">
                  Showing courses matching your search
                </p>
              </div>
            ) : (
              <div className="mb-4">
                <h1 className="text-2xl font-display font-bold">Browse Courses</h1>
                <p className="text-muted-foreground text-sm mt-1">
                  15,000+ courses across 500+ categories
                </p>
              </div>
            )}
            <CourseSearchBar initialQuery={searchParams.q} />
          </div>

          {/* Category tabs */}
          <Suspense>
            <CategoryTabs activeCategory={searchParams.category} />
          </Suspense>
        </div>

        <div className="container mx-auto px-4 max-w-7xl py-8">
          <div className="flex gap-8">
            {/* Filters sidebar */}
            <aside className="hidden lg:block w-64 shrink-0">
              <CourseFilters searchParams={searchParams} />
            </aside>

            {/* Results */}
            <div className="flex-1 min-w-0">
              <CourseSortBar searchParams={searchParams} />
              <Suspense
                key={JSON.stringify(searchParams)}
                fallback={<SkeletonCourseGrid />}
              >
                <CourseGrid searchParams={searchParams} />
              </Suspense>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
