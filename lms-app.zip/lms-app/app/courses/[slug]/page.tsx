import { notFound } from 'next/navigation';
import Image from 'next/image';
import { Suspense } from 'react';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { Navbar } from '@/components/layout/Navbar';
import { Footer } from '@/components/layout/Footer';
import {
  CourseHero,
  CourseCurriculum,
  CourseReviews,
  CourseInstructor,
  CourseDiscussions,
  RelatedCourses,
} from '@/components/course/CourseComponents';
import { CourseSidebar } from '@/components/course/CourseSidebar';

interface CoursePageProps {
  params: { slug: string };
}

// Mock data - replace with prisma call
async function getCourse(slug: string) {
  return {
    id: '1',
    slug,
    title: 'The Complete React Developer Course (w/ Hooks and Redux)',
    shortDescription: 'Build powerful React apps from scratch. Master React, Hooks, Redux, TypeScript, Testing, and more.',
    description: `<p>Become a professional React developer by building real-world projects.</p>
    <p>This comprehensive course covers everything you need to know about modern React development, including hooks, context, Redux, TypeScript, testing, and performance optimization.</p>`,
    thumbnail: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=800&h=450&fit=crop',
    previewVideo: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    price: 89.99,
    discountPrice: 14.99,
    isFree: false,
    level: 'BEGINNER' as const,
    language: 'English',
    durationMinutes: 4380, // 73 hours
    totalLessons: 312,
    totalStudents: 94823,
    avgRating: 4.7,
    totalReviews: 18432,
    hasCertificate: true,
    isDownloadable: true,
    tags: ['React', 'JavaScript', 'Frontend', 'Hooks', 'Redux'],
    outcomes: [
      'Build powerful, fast, user-friendly and reactive web apps',
      'Apply for high-paid jobs as a React developer',
      'Understand the latest features of React including Hooks, Context API and more',
      'Learn Redux, React Router, TypeScript integration',
      'Write tests with Jest and React Testing Library',
    ],
    requirements: [
      'Basic JavaScript knowledge (variables, functions, arrays)',
      'Basic HTML & CSS understanding',
      'No React experience needed',
    ],
    category: { id: '1', name: 'Web Development', slug: 'web-development' },
    instructor: {
      id: '1',
      isVerified: true,
      totalStudents: 283451,
      avgRating: 4.8,
      totalCourses: 12,
      user: {
        name: 'Andrew Mead',
        image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face',
        headline: 'Full-Stack Web Developer & Teacher',
      },
      bio: 'Andrew is a full-stack developer and teacher at The University of Pennsylvania. He has taught over 280,000 students through his Udemy courses.',
    },
    sections: [
      {
        id: 's1',
        title: 'Getting Started with React',
        duration: 120,
        lessons: [
          { id: 'l1', title: 'Course Introduction', type: 'VIDEO', videoDuration: 180, isPreview: true },
          { id: 'l2', title: 'Setting Up Your Environment', type: 'VIDEO', videoDuration: 420, isPreview: true },
          { id: 'l3', title: 'Creating Your First React App', type: 'VIDEO', videoDuration: 840, isPreview: false },
          { id: 'l4', title: 'React Fundamentals Quiz', type: 'QUIZ', isPreview: false },
        ],
      },
      {
        id: 's2',
        title: 'React Components & JSX',
        duration: 240,
        lessons: [
          { id: 'l5', title: 'Understanding Components', type: 'VIDEO', videoDuration: 1200, isPreview: false },
          { id: 'l6', title: 'Props and PropTypes', type: 'VIDEO', videoDuration: 960, isPreview: false },
          { id: 'l7', title: 'State Management Basics', type: 'VIDEO', videoDuration: 1440, isPreview: false },
          { id: 'l8', title: 'Reading: Component Patterns', type: 'READING', isPreview: false },
        ],
      },
      {
        id: 's3',
        title: 'React Hooks Deep Dive',
        duration: 360,
        lessons: [
          { id: 'l9', title: 'useState Hook', type: 'VIDEO', videoDuration: 1800, isPreview: false },
          { id: 'l10', title: 'useEffect Hook', type: 'VIDEO', videoDuration: 2100, isPreview: false },
          { id: 'l11', title: 'useCallback & useMemo', type: 'VIDEO', videoDuration: 1500, isPreview: false },
          { id: 'l12', title: 'Custom Hooks', type: 'VIDEO', videoDuration: 1800, isPreview: false },
          { id: 'l13', title: 'Hooks Assignment', type: 'ASSIGNMENT', isPreview: false },
        ],
      },
    ],
    publishedAt: new Date('2024-01-15'),
    updatedAt: new Date('2024-05-20'),
  };
}

export async function generateMetadata({ params }: CoursePageProps) {
  const course = await getCourse(params.slug);
  return {
    title: course.title,
    description: course.shortDescription,
    openGraph: {
      title: course.title,
      description: course.shortDescription,
      images: [course.thumbnail],
    },
  };
}

export default async function CourseDetailPage({ params }: CoursePageProps) {
  const [course, session] = await Promise.all([
    getCourse(params.slug),
    getServerSession(authOptions),
  ]);

  if (!course) notFound();

  const isEnrolled = false; // Check enrollment from DB in real app

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="pt-16">
        <CourseHero course={course} session={session} isEnrolled={isEnrolled} />

        <div className="container mx-auto px-4 max-w-7xl py-10">
          <div className="flex gap-8">
            {/* Main content */}
            <div className="flex-1 min-w-0 space-y-10">
              {/* What you'll learn */}
              <section>
                <h2 className="text-xl font-display font-bold mb-4">What you&apos;ll learn</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-6 border rounded-xl bg-card">
                  {course.outcomes.map((outcome, i) => (
                    <div key={i} className="flex items-start gap-3">
                      <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center shrink-0 mt-0.5">
                        <svg className="w-3 h-3 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                      <span className="text-sm text-muted-foreground">{outcome}</span>
                    </div>
                  ))}
                </div>
              </section>

              {/* Requirements */}
              <section>
                <h2 className="text-xl font-display font-bold mb-4">Requirements</h2>
                <ul className="space-y-2">
                  {course.requirements.map((req, i) => (
                    <li key={i} className="flex items-start gap-3 text-sm text-muted-foreground">
                      <span className="w-1.5 h-1.5 bg-muted-foreground rounded-full mt-2 shrink-0" />
                      {req}
                    </li>
                  ))}
                </ul>
              </section>

              {/* Curriculum */}
              <CourseCurriculum sections={course.sections} isEnrolled={isEnrolled} />

              {/* Instructor */}
              <CourseInstructor instructor={course.instructor} />

              {/* Reviews */}
              <CourseReviews courseId={course.id} avgRating={course.avgRating} totalReviews={course.totalReviews} />

              {/* Discussions preview */}
              <CourseDiscussions courseId={course.id} session={session} isEnrolled={isEnrolled} />
            </div>

            {/* Sticky sidebar */}
            <div className="hidden lg:block w-80 shrink-0">
              <div className="sticky top-24">
                <CourseSidebar course={course} session={session} isEnrolled={isEnrolled} />
              </div>
            </div>
          </div>

          {/* Related courses */}
          <div className="mt-14">
            <RelatedCourses courseId={course.id} categoryId={course.category.id} />
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
