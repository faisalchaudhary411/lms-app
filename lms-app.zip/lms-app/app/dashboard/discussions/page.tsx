'use client';

import { useState } from 'react';
import {
  MessageSquare, Search, Plus, ChevronUp, Pin, CheckCircle2,
  Megaphone, Clock, Tag, Filter, Users, BookOpen, TrendingUp
} from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

const MOCK_DISCUSSIONS = [
  {
    id: '1', title: 'Best practices for React state management in 2024?',
    content: 'I\'ve been using useState and useContext but wondering if I should switch to Zustand or Redux Toolkit for larger apps. What are your thoughts?',
    author: { name: 'Alex Chen', image: '', initials: 'AC' },
    course: 'Complete React Developer',
    upvotes: 47, replyCount: 23, isPinned: false, isAnnouncement: false, isResolved: true,
    tags: ['React', 'State Management'], createdAt: new Date(Date.now() - 1000 * 60 * 60 * 3),
  },
  {
    id: '2', title: '📢 New course content: React Server Components module added',
    content: 'We\'ve just added a comprehensive module on React Server Components covering the latest patterns. Check the curriculum for Sections 14–16.',
    author: { name: 'Andrew Mead', image: '', initials: 'AM' },
    course: 'Complete React Developer',
    upvotes: 128, replyCount: 41, isPinned: true, isAnnouncement: true, isResolved: false,
    tags: ['Announcement'], createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24),
  },
  {
    id: '3', title: 'Confused about useEffect dependency array – when to include functions?',
    content: 'I keep getting the exhaustive-deps ESLint warning. Can someone explain when I should and shouldn\'t include functions in the dependency array?',
    author: { name: 'Sarah Kim', image: '', initials: 'SK' },
    course: 'Complete React Developer',
    upvotes: 32, replyCount: 15, isPinned: false, isAnnouncement: false, isResolved: false,
    tags: ['React', 'Hooks'], createdAt: new Date(Date.now() - 1000 * 60 * 60 * 8),
  },
  {
    id: '4', title: 'Python virtual environments – venv vs conda vs poetry?',
    content: 'Starting a new data science project and not sure which environment manager to use. What does the community recommend for ML projects?',
    author: { name: 'Mike Torres', image: '', initials: 'MT' },
    course: 'Python for Data Science',
    upvotes: 24, replyCount: 18, isPinned: false, isAnnouncement: false, isResolved: true,
    tags: ['Python', 'Tools'], createdAt: new Date(Date.now() - 1000 * 60 * 60 * 12),
  },
  {
    id: '5', title: 'How to prepare for AWS Cloud Practitioner exam?',
    content: 'Taking the exam in 3 weeks. What study materials outside the course do you recommend? Any practice exams?',
    author: { name: 'Priya Patel', image: '', initials: 'PP' },
    course: 'AWS Cloud Practitioner',
    upvotes: 56, replyCount: 31, isPinned: false, isAnnouncement: false, isResolved: true,
    tags: ['AWS', 'Certification'], createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2),
  },
];

const FILTERS = ['All', 'Announcements', 'Questions', 'Resolved', 'My Posts'];

export default function DiscussionsPage() {
  const [search, setSearch] = useState('');
  const [activeFilter, setActiveFilter] = useState('All');
  const [upvoted, setUpvoted] = useState<Set<string>>(new Set());
  const [showNewPost, setShowNewPost] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');

  const filtered = MOCK_DISCUSSIONS.filter((d) => {
    const matchSearch = d.title.toLowerCase().includes(search.toLowerCase()) ||
      d.content.toLowerCase().includes(search.toLowerCase());
    const matchFilter =
      activeFilter === 'All' ||
      (activeFilter === 'Announcements' && d.isAnnouncement) ||
      (activeFilter === 'Questions' && !d.isAnnouncement) ||
      (activeFilter === 'Resolved' && d.isResolved);
    return matchSearch && matchFilter;
  });

  const handleUpvote = (id: string) => {
    setUpvoted((prev) => {
      const n = new Set(prev);
      n.has(id) ? n.delete(id) : n.add(id);
      return n;
    });
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-display font-bold">Discussions</h1>
            <p className="text-muted-foreground mt-1">Ask questions, share knowledge, help others</p>
          </div>
          <Button onClick={() => setShowNewPost(!showNewPost)} className="gap-2 shrink-0">
            <Plus className="w-4 h-4" />
            New Post
          </Button>
        </div>

        {/* New post form */}
        {showNewPost && (
          <div className="bg-card border rounded-2xl p-6 animate-fade-up">
            <h3 className="font-display font-bold mb-4">Start a Discussion</h3>
            <div className="space-y-3">
              <Input
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="Your question or discussion title..."
                className="h-11"
              />
              <textarea
                value={newContent}
                onChange={(e) => setNewContent(e.target.value)}
                placeholder="Add more context, code snippets, or details..."
                className="w-full px-3 py-2.5 text-sm bg-background border rounded-xl outline-none focus:ring-2 ring-primary/30 resize-none h-28"
              />
              <div className="flex items-center gap-3">
                <select className="px-3 py-2 text-sm bg-background border rounded-xl outline-none flex-1">
                  <option>Select course (optional)</option>
                  <option>Complete React Developer</option>
                  <option>Python for Data Science</option>
                  <option>AWS Cloud Practitioner</option>
                </select>
                <Button disabled={!newTitle.trim()} onClick={() => { setShowNewPost(false); setNewTitle(''); setNewContent(''); }}>
                  Post Discussion
                </Button>
                <Button variant="ghost" onClick={() => setShowNewPost(false)}>Cancel</Button>
              </div>
            </div>
          </div>
        )}

        {/* Stats row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[
            { label: 'Total Discussions', value: '1,247', icon: MessageSquare, color: 'text-blue-500', bg: 'bg-blue-500/10' },
            { label: 'Your Posts', value: '12', icon: Users, color: 'text-primary', bg: 'bg-primary/10' },
            { label: 'Resolved', value: '89%', icon: CheckCircle2, color: 'text-primary', bg: 'bg-primary/10' },
            { label: 'Active Today', value: '43', icon: TrendingUp, color: 'text-amber-500', bg: 'bg-amber-500/10' },
          ].map((stat) => (
            <div key={stat.label} className="bg-card border rounded-xl p-4 flex items-center gap-3">
              <div className={cn('w-9 h-9 rounded-lg flex items-center justify-center shrink-0', stat.bg)}>
                <stat.icon className={cn('w-4 h-4', stat.color)} />
              </div>
              <div>
                <div className="font-bold">{stat.value}</div>
                <div className="text-xs text-muted-foreground">{stat.label}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Controls */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-48">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search discussions..."
              className="pl-9 h-9"
            />
          </div>
          <div className="flex gap-1">
            {FILTERS.map((f) => (
              <button
                key={f}
                onClick={() => setActiveFilter(f)}
                className={cn(
                  'px-3 py-1.5 text-xs font-medium rounded-lg transition-all',
                  activeFilter === f ? 'bg-primary/10 text-primary' : 'text-muted-foreground hover:bg-secondary'
                )}
              >
                {f}
              </button>
            ))}
          </div>
        </div>

        {/* Discussion list */}
        <div className="space-y-3">
          {filtered.map((post) => (
            <div
              key={post.id}
              className={cn(
                'bg-card border rounded-xl p-5 hover:border-primary/30 transition-all cursor-pointer group',
                post.isPinned && 'border-primary/20 bg-primary/[0.02]'
              )}
            >
              <div className="flex gap-4">
                {/* Upvote */}
                <div className="flex flex-col items-center gap-1 shrink-0">
                  <button
                    onClick={(e) => { e.stopPropagation(); handleUpvote(post.id); }}
                    className={cn(
                      'w-8 h-8 rounded-lg flex items-center justify-center transition-all',
                      upvoted.has(post.id)
                        ? 'bg-primary/10 text-primary'
                        : 'text-muted-foreground hover:bg-secondary hover:text-foreground'
                    )}
                  >
                    <ChevronUp className="w-4 h-4" />
                  </button>
                  <span className={cn('text-xs font-semibold', upvoted.has(post.id) && 'text-primary')}>
                    {post.upvotes + (upvoted.has(post.id) ? 1 : 0)}
                  </span>
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start gap-2 flex-wrap mb-1.5">
                    {post.isPinned && <Pin className="w-3.5 h-3.5 text-primary shrink-0 mt-0.5" />}
                    {post.isAnnouncement && (
                      <Badge className="text-[10px] bg-amber-500/10 text-amber-500 border-amber-500/20 shrink-0">
                        📢 Announcement
                      </Badge>
                    )}
                    {post.isResolved && (
                      <Badge className="text-[10px] bg-primary/10 text-primary border-0 shrink-0">
                        ✓ Resolved
                      </Badge>
                    )}
                  </div>

                  <h3 className="font-semibold text-sm leading-snug group-hover:text-primary transition-colors mb-1.5">
                    {post.title}
                  </h3>
                  <p className="text-xs text-muted-foreground line-clamp-2 leading-relaxed mb-3">
                    {post.content}
                  </p>

                  <div className="flex items-center gap-4 flex-wrap">
                    <div className="flex items-center gap-2">
                      <Avatar className="w-5 h-5">
                        <AvatarFallback className="bg-primary/20 text-primary text-[10px] font-bold">
                          {post.author.initials}
                        </AvatarFallback>
                      </Avatar>
                      <span className="text-xs text-muted-foreground">{post.author.name}</span>
                    </div>

                    <span className="flex items-center gap-1 text-xs text-muted-foreground">
                      <BookOpen className="w-3 h-3" />
                      {post.course}
                    </span>

                    <span className="flex items-center gap-1 text-xs text-muted-foreground">
                      <MessageSquare className="w-3 h-3" />
                      {post.replyCount} replies
                    </span>

                    <span className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Clock className="w-3 h-3" />
                      {format(post.createdAt, 'MMM d, h:mm a')}
                    </span>

                    <div className="flex gap-1 ml-auto">
                      {post.tags.map((tag) => (
                        <span key={tag} className="tag-pill text-[10px] py-0.5">{tag}</span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-16 border rounded-xl">
            <MessageSquare className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
            <p className="font-semibold mb-1">No discussions found</p>
            <p className="text-sm text-muted-foreground mb-4">Be the first to start a discussion!</p>
            <Button onClick={() => setShowNewPost(true)} className="gap-2">
              <Plus className="w-4 h-4" />
              New Post
            </Button>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
