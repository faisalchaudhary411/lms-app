import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { redirect } from 'next/navigation';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { AchievementsGrid } from '@/components/dashboard/AchievementsGrid';

export const metadata = { title: 'Achievements' };

export default async function AchievementsPage() {
  const session = await getServerSession(authOptions);
  if (!session) redirect('/auth/login');

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-display font-bold">Achievements</h1>
          <p className="text-muted-foreground mt-1">Your badges, XP, and milestones</p>
        </div>
        <AchievementsGrid />
      </div>
    </DashboardLayout>
  );
}
