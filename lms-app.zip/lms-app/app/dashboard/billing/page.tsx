'use client';

import { useState } from 'react';
import { CreditCard, Download, Check, Zap, Building2, AlertCircle, ExternalLink } from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

const ORDERS = [
  { id: 'ord_001', date: new Date('2024-05-14'), description: 'The Complete React Developer Course', amount: 14.99, status: 'COMPLETED' },
  { id: 'ord_002', date: new Date('2024-04-02'), description: 'Pro Plan – Monthly', amount: 29.00, status: 'COMPLETED' },
  { id: 'ord_003', date: new Date('2024-03-02'), description: 'Pro Plan – Monthly', amount: 29.00, status: 'COMPLETED' },
  { id: 'ord_004', date: new Date('2024-02-10'), description: 'JavaScript Complete Guide', amount: 15.99, status: 'COMPLETED' },
  { id: 'ord_005', date: new Date('2024-02-02'), description: 'Pro Plan – Monthly', amount: 29.00, status: 'REFUNDED' },
];

export default function BillingPage() {
  const [cancelConfirm, setCancelConfirm] = useState(false);

  return (
    <DashboardLayout>
      <div className="space-y-6 max-w-3xl">
        <div>
          <h1 className="text-2xl font-display font-bold">Billing & Payments</h1>
          <p className="text-muted-foreground mt-1">Manage your subscription and purchase history</p>
        </div>

        {/* Current plan */}
        <div className="bg-gradient-to-br from-primary/10 via-emerald-500/5 to-background border border-primary/20 rounded-2xl p-6">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-primary/20 rounded-2xl flex items-center justify-center">
                <Zap className="w-6 h-6 text-primary" />
              </div>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <h2 className="font-display font-bold text-lg">Pro Plan</h2>
                  <Badge className="bg-primary/10 text-primary border-0">Active</Badge>
                </div>
                <p className="text-sm text-muted-foreground">$29.00/month · Next billing June 2, 2024</p>
                <div className="flex flex-wrap gap-2 mt-3">
                  {['Unlimited courses', 'AI assistant', 'Offline access', 'Certificates', 'Priority support'].map((f) => (
                    <span key={f} className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Check className="w-3 h-3 text-primary" />{f}
                    </span>
                  ))}
                </div>
              </div>
            </div>
            <div className="flex gap-2 shrink-0">
              <Button variant="outline" size="sm">Upgrade</Button>
              {!cancelConfirm ? (
                <Button variant="ghost" size="sm" className="text-muted-foreground" onClick={() => setCancelConfirm(true)}>
                  Cancel
                </Button>
              ) : (
                <Button variant="destructive" size="sm" onClick={() => setCancelConfirm(false)}>
                  Confirm Cancel
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* Payment method */}
        <div className="bg-card border rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-display font-bold">Payment Method</h3>
            <Button variant="outline" size="sm">Update</Button>
          </div>
          <div className="flex items-center gap-4 p-4 border rounded-xl bg-secondary/20">
            <div className="w-12 h-8 bg-gradient-to-br from-blue-500 to-violet-600 rounded-lg flex items-center justify-center">
              <CreditCard className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="text-sm font-medium">Visa ending in 4242</p>
              <p className="text-xs text-muted-foreground">Expires 08/2026</p>
            </div>
            <Badge variant="secondary" className="ml-auto text-xs">Default</Badge>
          </div>
        </div>

        {/* Billing history */}
        <div className="bg-card border rounded-2xl overflow-hidden">
          <div className="flex items-center justify-between p-6 border-b">
            <h3 className="font-display font-bold">Purchase History</h3>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="w-3.5 h-3.5" />Export CSV
            </Button>
          </div>
          <div className="divide-y divide-border/50">
            {ORDERS.map((order) => (
              <div key={order.id} className="flex items-center gap-4 px-6 py-4 hover:bg-secondary/20 transition-colors">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium line-clamp-1">{order.description}</p>
                  <p className="text-xs text-muted-foreground">{format(order.date, 'MMMM d, yyyy')} · {order.id}</p>
                </div>
                <Badge className={cn('text-xs shrink-0',
                  order.status === 'COMPLETED' ? 'bg-primary/10 text-primary border-0' :
                  order.status === 'REFUNDED' ? 'bg-destructive/10 text-destructive border-0' : ''
                )}>
                  {order.status}
                </Badge>
                <div className={cn('text-sm font-bold shrink-0 w-16 text-right',
                  order.status === 'REFUNDED' && 'line-through text-muted-foreground')}>
                  ${order.amount.toFixed(2)}
                </div>
                <Button variant="ghost" size="icon" className="w-8 h-8 shrink-0">
                  <Download className="w-3.5 h-3.5" />
                </Button>
              </div>
            ))}
          </div>
        </div>

        {/* Refund policy */}
        <div className="flex items-start gap-3 p-4 bg-secondary/30 rounded-xl text-sm text-muted-foreground">
          <AlertCircle className="w-4 h-4 text-primary shrink-0 mt-0.5" />
          <p>
            All course purchases come with a <strong className="text-foreground">30-day money-back guarantee</strong>.
            To request a refund, contact support within 30 days of purchase.{' '}
            <a href="/refunds" className="text-primary hover:underline inline-flex items-center gap-0.5">
              Refund Policy <ExternalLink className="w-3 h-3" />
            </a>
          </p>
        </div>
      </div>
    </DashboardLayout>
  );
}
