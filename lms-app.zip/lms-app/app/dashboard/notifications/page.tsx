'use client';

import { useState } from 'react';
import {
  Bell, Check, CheckCheck, Trash2, Filter,
  BookOpen, Award, MessageSquare, Calendar, Megaphone,
  AlertCircle, ExternalLink
} from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import Link from 'next/link';
import toast from 'react-hot-toast';

const TYPE_META: Record<string, { icon: any; color: string; bg: string; label: string }> = {
  CERTIFICATE_EARNED:   { icon: Award,          color: 'text-amber-500',  bg: 'bg-amber-500/10',  label: 'Certificate'   },
  ASSIGNMENT_GRADED:    { icon: CheckCheck,      color: 'text-primary',    bg: 'bg-primary/10',    label: 'Assignment'    },
  DEADLINE_REMINDER:    { icon: Calendar,        color: 'text-red-500',    bg: 'bg-red-500/10',    label: 'Deadline'      },
  REPLY_TO_POST:        { icon: MessageSquare,   color: 'text-blue-500',   bg: 'bg-blue-500/10',   label: 'Discussion'    },
  NEW_ANNOUNCEMENT:     { icon: Megaphone,       color: 'text-violet-500', bg: 'bg-violet-500/10', label: 'Announcement'  },
  ENROLLMENT_CONFIRMED: { icon: BookOpen,        color: 'text-primary',    bg: 'bg-primary/10',    label: 'Enrollment'    },
  LIVE_CLASS_STARTING:  { icon: AlertCircle,     color: 'text-red-500',    bg: 'bg-red-500/10',    label: 'Live'          },
  COURSE_UPDATE:        { icon: BookOpen,        color: 'text-blue-500',   bg: 'bg-blue-500/10',   label: 'Update'        },
};

const MOCK_NOTIFICATIONS = [
  { id: '1', type: 'CERTIFICATE_EARNED', title: '🎉 Certificate earned!', message: 'You completed "The Complete React Developer Course" and your certificate is ready.', link: '/dashboard/certificates', isRead: false, createdAt: new Date(Date.now() - 1000 * 60 * 5) },
  { id: '2', type: 'ASSIGNMENT_GRADED', title: 'Assignment graded', message: 'Your "React Hooks Deep Dive" assignment received 92/100. Great work!', link: '/dashboard/my-courses', isRead: false, createdAt: new Date(Date.now() - 1000 * 60 * 45) },
  { id: '3', type: 'DEADLINE_REMINDER', title: 'Deadline in 24 hours', message: 'Your "NumPy Arrays" assignment in Python for Data Science is due tomorrow at 11:59 PM.', link: '/dashboard/my-courses', isRead: false, createdAt: new Date(Date.now() - 1000 * 60 * 120) },
  { id: '4', type: 'NEW_ANNOUNCEMENT', title: 'New course content added', message: 'Andrew Mead added 3 new lessons on React Server Components to your enrolled course.', link: '/learn/complete-react-developer', isRead: true, createdAt: new Date(Date.now() - 1000 * 60 * 60 * 5) },
  { id: '5', type: 'REPLY_TO_POST', title: 'Instructor replied to your question', message: '"Great question! useCallback should be used when you need to pass a callback to a child component that relies on reference equality…"', link: '/courses/complete-react-developer/discussions', isRead: true, createdAt: new Date(Date.now() - 1000 * 60 * 60 * 8) },
  { id: '6', type: 'LIVE_CLASS_STARTING', title: 'Live class starting in 15 min', message: '"Advanced TypeScript Patterns" with Chris Lee starts at 3:00 PM. Join now to get a good seat!', link: '/live', isRead: true, createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24) },
  { id: '7', type: 'ENROLLMENT_CONFIRMED', title: 'Enrollment confirmed', message: 'You are now enrolled in "Docker & Kubernetes: The Complete Guide". Start learning now!', link: '/learn/docker-kubernetes', isRead: true, createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2) },
  { id: '8', type: 'COURSE_UPDATE', title: 'Course updated', message: 'Python for Data Science was updated with a new module on Pandas 2.0 features.', link: '/learn/python-data-science', isRead: true, createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3) },
];

type NotifFilter = 'all' | 'unread' | string;

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState(MOCK_NOTIFICATIONS);
  const [filter, setFilter] = useState<NotifFilter>('all');

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  const markRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => n.id === id ? { ...n, isRead: true } : n));
  };

  const markAllRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
    toast.success('All notifications marked as read');
  };

  const deleteNotif = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  const clearAll = () => {
    setNotifications([]);
    toast.success('All notifications cleared');
  };

  const FILTERS: { value: NotifFilter; label: string }[] = [
    { value: 'all', label: 'All' },
    { value: 'unread', label: `Unread (${unreadCount})` },
    ...Object.entries(TYPE_META).map(([value, meta]) => ({ value, label: meta.label })),
  ];

  const filtered = notifications.filter((n) => {
    if (filter === 'all') return true;
    if (filter === 'unread') return !n.isRead;
    return n.type === filter;
  });

  return (
    <DashboardLayout>
      <div className="space-y-6 max-w-3xl">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-display font-bold flex items-center gap-2">
              <Bell className="w-5 h-5 text-primary" />
              Notifications
              {unreadCount > 0 && (
                <Badge className="bg-primary/10 text-primary border-0">{unreadCount} new</Badge>
              )}
            </h1>
            <p className="text-muted-foreground mt-1">Stay up to date with your learning activity</p>
          </div>
          <div className="flex gap-2">
            {unreadCount > 0 && (
              <Button variant="outline" size="sm" className="gap-1.5" onClick={markAllRead}>
                <CheckCheck className="w-3.5 h-3.5" />Mark all read
              </Button>
            )}
            <Button variant="ghost" size="sm" className="gap-1.5 text-muted-foreground" onClick={clearAll}>
              <Trash2 className="w-3.5 h-3.5" />Clear all
            </Button>
          </div>
        </div>

        {/* Filter chips */}
        <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-1">
          {FILTERS.slice(0, 6).map((f) => (
            <button
              key={f.value}
              onClick={() => setFilter(f.value)}
              className={cn(
                'px-3 py-1.5 text-xs font-medium rounded-full border whitespace-nowrap transition-all shrink-0',
                filter === f.value
                  ? 'bg-primary text-primary-foreground border-primary'
                  : 'border-border text-muted-foreground hover:border-primary/40'
              )}
            >
              {f.label}
            </button>
          ))}
        </div>

        {/* Notification list */}
        {filtered.length === 0 ? (
          <div className="text-center py-16 border rounded-2xl">
            <Bell className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
            <p className="font-semibold mb-1">No notifications</p>
            <p className="text-sm text-muted-foreground">
              {filter === 'unread' ? "You're all caught up!" : "Nothing here yet."}
            </p>
          </div>
        ) : (
          <div className="space-y-1">
            {filtered.map((notif) => {
              const meta = TYPE_META[notif.type] || { icon: Bell, color: 'text-muted-foreground', bg: 'bg-secondary', label: '' };
              const Icon = meta.icon;
              return (
                <div
                  key={notif.id}
                  className={cn(
                    'flex gap-4 p-4 rounded-2xl border transition-all cursor-pointer group hover:border-primary/20',
                    !notif.isRead ? 'bg-primary/[0.03] border-primary/10' : 'bg-card border-border/50 hover:bg-secondary/30'
                  )}
                  onClick={() => markRead(notif.id)}
                >
                  {/* Icon */}
                  <div className={cn('w-10 h-10 rounded-xl flex items-center justify-center shrink-0', meta.bg)}>
                    <Icon className={cn('w-5 h-5', meta.color)} />
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className={cn('text-sm font-semibold', !notif.isRead && 'text-foreground')}>
                          {notif.title}
                        </p>
                        <Badge className={cn('text-[10px] border-0 shrink-0', meta.bg, meta.color)}>
                          {meta.label}
                        </Badge>
                      </div>
                      {!notif.isRead && (
                        <div className="w-2 h-2 bg-primary rounded-full shrink-0 mt-1.5" />
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground mt-0.5 leading-relaxed line-clamp-2">
                      {notif.message}
                    </p>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-xs text-muted-foreground">
                        {format(notif.createdAt, 'MMM d, h:mm a')}
                      </span>
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        {notif.link && (
                          <Link
                            href={notif.link}
                            onClick={(e) => e.stopPropagation()}
                            className="text-xs text-primary hover:underline flex items-center gap-0.5"
                          >
                            View <ExternalLink className="w-2.5 h-2.5" />
                          </Link>
                        )}
                        <button
                          onClick={(e) => { e.stopPropagation(); deleteNotif(notif.id); }}
                          className="p-1 text-muted-foreground hover:text-destructive transition-colors ml-2"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Notification preferences link */}
        <div className="flex items-center justify-center pt-2">
          <Link href="/dashboard/settings" className="text-sm text-primary hover:underline flex items-center gap-1.5">
            <Bell className="w-3.5 h-3.5" />
            Manage notification preferences
          </Link>
        </div>
      </div>
    </DashboardLayout>
  );
}
