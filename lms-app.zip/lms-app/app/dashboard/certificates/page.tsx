import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { redirect } from 'next/navigation';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { CertificatesList } from '@/components/dashboard/CertificatesList';

export const metadata = { title: 'My Certificates' };

export default async function CertificatesPage() {
  const session = await getServerSession(authOptions);
  if (!session) redirect('/auth/login');

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-display font-bold">My Certificates</h1>
          <p className="text-muted-foreground mt-1">Share and verify your achievements</p>
        </div>
        <CertificatesList />
      </div>
    </DashboardLayout>
  );
}
