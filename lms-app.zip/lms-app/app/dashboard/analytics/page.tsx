'use client';

import { useState } from 'react';
import {
  LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from 'recharts';
import {
  Clock, BookOpen, Target, TrendingUp, Flame, Brain, Calendar, ChevronDown
} from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

const WEEKLY_MINUTES = [
  { day: 'Mon', minutes: 45 }, { day: 'Tue', minutes: 72 }, { day: 'Wed', minutes: 38 },
  { day: 'Thu', minutes: 90 }, { day: 'Fri', minutes: 65 }, { day: 'Sat', minutes: 120 },
  { day: 'Sun', minutes: 55 },
];

const MONTHLY_PROGRESS = [
  { week: 'W1', completed: 8, quizzes: 3 }, { week: 'W2', completed: 12, quizzes: 5 },
  { week: 'W3', completed: 7, quizzes: 2 }, { week: 'W4', completed: 15, quizzes: 7 },
];

const SKILL_DISTRIBUTION = [
  { name: 'Web Dev', value: 45, color: '#3b82f6' },
  { name: 'Data Science', value: 25, color: '#8b5cf6' },
  { name: 'Cloud', value: 15, color: '#06b6d4' },
  { name: 'Design', value: 10, color: '#f59e0b' },
  { name: 'Other', value: 5, color: '#6b7280' },
];

const QUIZ_HISTORY = [
  { date: 'May 1', score: 72 }, { date: 'May 5', score: 85 }, { date: 'May 8', score: 78 },
  { date: 'May 12', score: 90 }, { date: 'May 15', score: 88 }, { date: 'May 19', score: 95 },
  { date: 'May 22', score: 92 }, { date: 'May 26', score: 87 }, { date: 'May 30', score: 96 },
];

const HEATMAP_DATA = Array.from({ length: 52 }, (_, week) =>
  Array.from({ length: 7 }, (_, day) => ({
    week, day,
    count: Math.random() > 0.4 ? Math.floor(Math.random() * 4) : 0,
  }))
);

const TooltipStyle = {
  background: 'hsl(var(--card))',
  border: '1px solid hsl(var(--border))',
  borderRadius: '12px',
  fontSize: '12px',
  color: 'hsl(var(--foreground))',
};

export default function AnalyticsPage() {
  const [period, setPeriod] = useState<'week' | 'month' | 'year'>('month');

  return (
    <DashboardLayout>
      <div className="space-y-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-display font-bold">Learning Analytics</h1>
            <p className="text-muted-foreground mt-1">Track your progress and performance</p>
          </div>
          <div className="flex items-center gap-1 bg-secondary rounded-xl p-1">
            {(['week', 'month', 'year'] as const).map((p) => (
              <button
                key={p}
                onClick={() => setPeriod(p)}
                className={cn(
                  'px-3 py-1.5 text-xs font-medium rounded-lg capitalize transition-all',
                  period === p ? 'bg-card shadow-sm text-foreground' : 'text-muted-foreground hover:text-foreground'
                )}
              >
                {p}
              </button>
            ))}
          </div>
        </div>

        {/* Top stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { label: 'Total Hours', value: '247h', sub: '+18h this week', icon: Clock, color: 'text-blue-500', bg: 'bg-blue-500/10' },
            { label: 'Lessons Done', value: '312', sub: '+15 this week', icon: BookOpen, color: 'text-primary', bg: 'bg-primary/10' },
            { label: 'Avg Quiz Score', value: '87%', sub: '+5% vs last month', icon: Brain, color: 'text-violet-500', bg: 'bg-violet-500/10' },
            { label: 'Completion Rate', value: '72%', sub: 'Above avg 68%', icon: Target, color: 'text-amber-500', bg: 'bg-amber-500/10' },
          ].map((stat) => (
            <div key={stat.label} className="bg-card border rounded-xl p-5">
              <div className={cn('w-9 h-9 rounded-lg flex items-center justify-center mb-3', stat.bg)}>
                <stat.icon className={cn('w-4 h-4', stat.color)} />
              </div>
              <div className="text-2xl font-display font-bold">{stat.value}</div>
              <div className="text-xs text-muted-foreground mt-0.5">{stat.label}</div>
              <div className={cn('text-xs mt-1 font-medium', stat.color)}>{stat.sub}</div>
            </div>
          ))}
        </div>

        {/* Daily learning time */}
        <div className="bg-card border rounded-xl p-6">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 className="font-display font-bold">Daily Learning Time</h3>
              <p className="text-sm text-muted-foreground mt-0.5">Minutes spent learning this week</p>
            </div>
            <div className="text-right">
              <p className="text-xl font-bold">485 min</p>
              <p className="text-xs text-primary flex items-center gap-1 justify-end">
                <TrendingUp className="w-3 h-3" /> +12% vs last week
              </p>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={WEEKLY_MINUTES} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="day" tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v}m`} />
              <Tooltip contentStyle={TooltipStyle} formatter={(v: any) => [`${v} min`, 'Learning time']} />
              <Bar dataKey="minutes" fill="hsl(142, 71%, 45%)" radius={[6, 6, 0, 0]}>
                {WEEKLY_MINUTES.map((_, i) => (
                  <Cell key={i} fill={i === 5 ? 'hsl(142, 71%, 45%)' : 'hsl(142, 71%, 45%, 0.6)'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Two column charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Lessons completed */}
          <div className="bg-card border rounded-xl p-6">
            <h3 className="font-display font-bold mb-1">Monthly Progress</h3>
            <p className="text-sm text-muted-foreground mb-4">Lessons & quizzes completed by week</p>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={MONTHLY_PROGRESS} barGap={4} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis dataKey="week" tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={TooltipStyle} />
                <Legend wrapperStyle={{ fontSize: '11px' }} />
                <Bar name="Lessons" dataKey="completed" fill="hsl(142, 71%, 45%)" radius={[4, 4, 0, 0]} />
                <Bar name="Quizzes" dataKey="quizzes" fill="hsl(217, 91%, 60%)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Skill distribution */}
          <div className="bg-card border rounded-xl p-6">
            <h3 className="font-display font-bold mb-1">Skill Distribution</h3>
            <p className="text-sm text-muted-foreground mb-4">Time spent by category</p>
            <div className="flex items-center gap-6">
              <ResponsiveContainer width={160} height={160}>
                <PieChart>
                  <Pie data={SKILL_DISTRIBUTION} cx="50%" cy="50%" innerRadius={50} outerRadius={75} paddingAngle={3} dataKey="value">
                    {SKILL_DISTRIBUTION.map((entry, i) => (
                      <Cell key={i} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={TooltipStyle} formatter={(v: any) => [`${v}%`, '']} />
                </PieChart>
              </ResponsiveContainer>
              <div className="flex-1 space-y-2">
                {SKILL_DISTRIBUTION.map((item) => (
                  <div key={item.name} className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: item.color }} />
                    <span className="text-sm flex-1">{item.name}</span>
                    <span className="text-sm font-semibold">{item.value}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Quiz performance trend */}
        <div className="bg-card border rounded-xl p-6">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 className="font-display font-bold">Quiz Performance Trend</h3>
              <p className="text-sm text-muted-foreground mt-0.5">Your quiz scores over time</p>
            </div>
            <Badge className="bg-primary/10 text-primary border-0">Avg: 87%</Badge>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={QUIZ_HISTORY} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="quizGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(142, 71%, 45%)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="hsl(142, 71%, 45%)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="date" tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} domain={[60, 100]} tickFormatter={(v) => `${v}%`} />
              <Tooltip contentStyle={TooltipStyle} formatter={(v: any) => [`${v}%`, 'Score']} />
              <Area type="monotone" dataKey="score" stroke="hsl(142, 71%, 45%)" strokeWidth={2.5} fill="url(#quizGrad)" dot={{ fill: 'hsl(142, 71%, 45%)', r: 4 }} activeDot={{ r: 6 }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Activity heatmap */}
        <div className="bg-card border rounded-xl p-6">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 className="font-display font-bold">Learning Activity</h3>
              <p className="text-sm text-muted-foreground mt-0.5">Your learning activity over the past year</p>
            </div>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <span>Less</span>
              {['bg-secondary', 'bg-primary/20', 'bg-primary/40', 'bg-primary/70', 'bg-primary'].map((bg, i) => (
                <div key={i} className={cn('w-3 h-3 rounded-sm', bg)} />
              ))}
              <span>More</span>
            </div>
          </div>
          <div className="overflow-x-auto scrollbar-hide">
            <div className="flex gap-1 min-w-max">
              {HEATMAP_DATA.map((week, wi) => (
                <div key={wi} className="flex flex-col gap-1">
                  {week.map((day, di) => {
                    const colors = ['bg-secondary', 'bg-primary/20', 'bg-primary/40', 'bg-primary/70', 'bg-primary'];
                    return (
                      <div
                        key={di}
                        className={cn('w-3 h-3 rounded-sm transition-colors hover:ring-1 ring-primary cursor-pointer', colors[day.count])}
                        title={`${day.count} lessons`}
                      />
                    );
                  })}
                </div>
              ))}
            </div>
          </div>
          <div className="flex items-center justify-between mt-3 text-xs text-muted-foreground">
            <span>Jun 2023</span>
            <span>May 2024</span>
          </div>
        </div>

        {/* Course completion rates */}
        <div className="bg-card border rounded-xl p-6">
          <h3 className="font-display font-bold mb-5">Course Progress Breakdown</h3>
          <div className="space-y-4">
            {[
              { title: 'The Complete React Developer', progress: 68, lessons: 212, total: 312 },
              { title: 'AWS Cloud Practitioner Cert', progress: 85, lessons: 102, total: 120 },
              { title: 'Python for Data Science', progress: 34, lessons: 82, total: 240 },
              { title: 'UI/UX Design Masterclass', progress: 12, lessons: 18, total: 148 },
              { title: 'JavaScript Complete Guide', progress: 100, lessons: 390, total: 390 },
            ].map((course) => (
              <div key={course.title}>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-sm font-medium line-clamp-1 flex-1 mr-4">{course.title}</span>
                  <div className="flex items-center gap-3 shrink-0">
                    <span className="text-xs text-muted-foreground">{course.lessons}/{course.total}</span>
                    <span className={cn(
                      'text-xs font-semibold',
                      course.progress === 100 ? 'text-primary' : 'text-foreground'
                    )}>
                      {course.progress}%
                    </span>
                  </div>
                </div>
                <div className="progress-bar h-2">
                  <div className="progress-fill" style={{ width: `${course.progress}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
