import { Suspense } from 'react';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { redirect } from 'next/navigation';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { ContinueLearning } from '@/components/dashboard/ContinueLearning';
import { DashboardStats } from '@/components/dashboard/DashboardStats';
import { LearningStreak } from '@/components/dashboard/LearningStreak';
import { AIAssistantWidget } from '@/components/dashboard/AIAssistantWidget';
import {
  RecommendedCourses,
  UpcomingDeadlines,
  RecentCertificates,
  WeeklyGoal,
} from '@/components/dashboard/DashboardComponents';
import { SkeletonDashboard } from '@/components/ui/skeletons';

export const metadata = {
  title: 'Dashboard',
};

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);

  if (!session) {
    redirect('/auth/login');
  }

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Welcome header */}
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-2xl font-display font-bold">
              Good morning, {session.user?.name?.split(' ')[0]} 👋
            </h1>
            <p className="text-muted-foreground mt-1">
              Ready to continue your learning journey?
            </p>
          </div>
          <AIAssistantWidget />
        </div>

        {/* Stats row */}
        <Suspense fallback={<SkeletonDashboard />}>
          <DashboardStats userId={session.user?.id} />
        </Suspense>

        {/* Main grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left column (2/3) */}
          <div className="lg:col-span-2 space-y-6">
            <Suspense fallback={<div className="h-64 shimmer rounded-xl" />}>
              <ContinueLearning userId={session.user?.id} />
            </Suspense>

            <Suspense fallback={<div className="h-64 shimmer rounded-xl" />}>
              <RecommendedCourses userId={session.user?.id} />
            </Suspense>
          </div>

          {/* Right column (1/3) */}
          <div className="space-y-6">
            <LearningStreak userId={session.user?.id} />
            <WeeklyGoal userId={session.user?.id} />
            <UpcomingDeadlines userId={session.user?.id} />
            <RecentCertificates userId={session.user?.id} />
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
