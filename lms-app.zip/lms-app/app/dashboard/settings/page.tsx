'use client';

import { useState } from 'react';
import { useSession } from 'next-auth/react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import {
  User, Lock, Bell, Shield, Smartphone, Globe, Palette,
  Camera, Loader2, Check, Trash2, AlertTriangle
} from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';
import toast from 'react-hot-toast';

const profileSchema = z.object({
  name: z.string().min(2),
  bio: z.string().max(300).optional(),
  headline: z.string().max(100).optional(),
  website: z.string().url().optional().or(z.literal('')),
  twitter: z.string().optional(),
  linkedin: z.string().optional(),
  github: z.string().optional(),
});

const TABS = [
  { id: 'profile', label: 'Profile', icon: User },
  { id: 'security', label: 'Security', icon: Lock },
  { id: 'notifications', label: 'Notifications', icon: Bell },
  { id: 'privacy', label: 'Privacy', icon: Shield },
  { id: 'appearance', label: 'Appearance', icon: Palette },
  { id: 'sessions', label: 'Sessions', icon: Smartphone },
];

export default function SettingsPage() {
  const { data: session, update } = useSession();
  const [activeTab, setActiveTab] = useState('profile');
  const [saving, setSaving] = useState(false);
  const [darkMode, setDarkMode] = useState(true);

  const { register, handleSubmit, formState: { errors, isDirty } } = useForm({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      name: session?.user?.name || '',
      bio: '',
      headline: '',
      website: '',
      twitter: '',
      linkedin: '',
      github: '',
    },
  });

  const onSaveProfile = async (data: any) => {
    setSaving(true);
    try {
      await fetch('/api/user/profile', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      await update({ name: data.name });
      toast.success('Profile updated!');
    } catch {
      toast.error('Failed to save changes');
    } finally {
      setSaving(false);
    }
  };

  const MOCK_SESSIONS = [
    { id: '1', device: 'MacBook Pro', browser: 'Chrome 124', location: 'San Francisco, US', lastActive: 'Now', current: true },
    { id: '2', device: 'iPhone 15', browser: 'Safari Mobile', location: 'San Francisco, US', lastActive: '2 hours ago', current: false },
    { id: '3', device: 'Windows PC', browser: 'Firefox 125', location: 'New York, US', lastActive: '5 days ago', current: false },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-display font-bold">Account Settings</h1>
          <p className="text-muted-foreground mt-1">Manage your account preferences</p>
        </div>

        <div className="flex gap-8 flex-col lg:flex-row">
          {/* Tabs sidebar */}
          <nav className="lg:w-52 shrink-0">
            <div className="flex lg:flex-col gap-1 overflow-x-auto scrollbar-hide pb-1 lg:pb-0">
              {TABS.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={cn(
                    'flex items-center gap-2.5 px-3 py-2.5 text-sm font-medium rounded-xl transition-all whitespace-nowrap',
                    activeTab === tab.id
                      ? 'bg-primary/10 text-primary'
                      : 'text-muted-foreground hover:text-foreground hover:bg-secondary'
                  )}
                >
                  <tab.icon className="w-4 h-4 shrink-0" />
                  {tab.label}
                </button>
              ))}
            </div>
          </nav>

          {/* Content */}
          <div className="flex-1 max-w-2xl">
            {activeTab === 'profile' && (
              <form onSubmit={handleSubmit(onSaveProfile)} className="space-y-6">
                <div className="bg-card border rounded-2xl p-6">
                  <h2 className="font-display font-bold mb-5">Public Profile</h2>

                  {/* Avatar */}
                  <div className="flex items-center gap-5 mb-6">
                    <div className="relative">
                      <Avatar className="w-20 h-20">
                        <AvatarImage src={session?.user?.image || ''} />
                        <AvatarFallback className="bg-primary/20 text-primary font-bold text-2xl">
                          {session?.user?.name?.[0] || 'U'}
                        </AvatarFallback>
                      </Avatar>
                      <button
                        type="button"
                        className="absolute -bottom-1 -right-1 w-7 h-7 bg-primary rounded-full flex items-center justify-center shadow-md hover:bg-primary/90 transition-colors"
                      >
                        <Camera className="w-3.5 h-3.5 text-white" />
                      </button>
                    </div>
                    <div>
                      <p className="font-medium text-sm">{session?.user?.name}</p>
                      <p className="text-xs text-muted-foreground mb-2">{session?.user?.email}</p>
                      <Button type="button" variant="outline" size="sm">Change Photo</Button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="sm:col-span-2 space-y-2">
                      <Label>Full Name</Label>
                      <Input {...register('name')} className="h-10" />
                      {errors.name && <p className="text-xs text-destructive">{String(errors.name.message)}</p>}
                    </div>

                    <div className="sm:col-span-2 space-y-2">
                      <Label>Headline</Label>
                      <Input {...register('headline')} placeholder="e.g., Full-Stack Developer" className="h-10" />
                    </div>

                    <div className="sm:col-span-2 space-y-2">
                      <Label>Bio</Label>
                      <textarea
                        {...register('bio')}
                        placeholder="Tell us about yourself..."
                        className="w-full px-3 py-2.5 text-sm bg-background border rounded-xl outline-none focus:ring-2 ring-primary/30 resize-none h-24"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Website</Label>
                      <Input {...register('website')} placeholder="https://yoursite.com" className="h-10" />
                    </div>
                    <div className="space-y-2">
                      <Label>Twitter</Label>
                      <Input {...register('twitter')} placeholder="@username" className="h-10" />
                    </div>
                    <div className="space-y-2">
                      <Label>LinkedIn</Label>
                      <Input {...register('linkedin')} placeholder="linkedin.com/in/..." className="h-10" />
                    </div>
                    <div className="space-y-2">
                      <Label>GitHub</Label>
                      <Input {...register('github')} placeholder="github.com/..." className="h-10" />
                    </div>
                  </div>
                </div>

                <Button type="submit" disabled={saving || !isDirty} className="gap-2">
                  {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                  Save Changes
                </Button>
              </form>
            )}

            {activeTab === 'security' && (
              <div className="space-y-5">
                <div className="bg-card border rounded-2xl p-6">
                  <h2 className="font-display font-bold mb-5">Change Password</h2>
                  <div className="space-y-4 max-w-sm">
                    <div className="space-y-2">
                      <Label>Current Password</Label>
                      <Input type="password" placeholder="••••••••" className="h-10" />
                    </div>
                    <div className="space-y-2">
                      <Label>New Password</Label>
                      <Input type="password" placeholder="••••••••" className="h-10" />
                    </div>
                    <div className="space-y-2">
                      <Label>Confirm New Password</Label>
                      <Input type="password" placeholder="••••••••" className="h-10" />
                    </div>
                    <Button>Update Password</Button>
                  </div>
                </div>

                <div className="bg-card border rounded-2xl p-6">
                  <div className="flex items-start justify-between">
                    <div>
                      <h2 className="font-display font-bold">Two-Factor Authentication</h2>
                      <p className="text-sm text-muted-foreground mt-1">
                        Add an extra layer of security to your account
                      </p>
                    </div>
                    <Button variant="outline" size="sm">Enable 2FA</Button>
                  </div>
                </div>

                <div className="bg-destructive/5 border border-destructive/20 rounded-2xl p-6">
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="w-5 h-5 text-destructive shrink-0 mt-0.5" />
                    <div>
                      <h2 className="font-semibold text-destructive">Delete Account</h2>
                      <p className="text-sm text-muted-foreground mt-1 mb-3">
                        Permanently delete your account and all your data. This action cannot be undone.
                      </p>
                      <Button variant="destructive" size="sm" className="gap-2">
                        <Trash2 className="w-3.5 h-3.5" />
                        Delete My Account
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'notifications' && (
              <div className="bg-card border rounded-2xl p-6 space-y-5">
                <h2 className="font-display font-bold">Notification Preferences</h2>
                {[
                  { label: 'Course announcements', description: 'Updates from instructors in enrolled courses', default: true },
                  { label: 'Assignment deadlines', description: 'Reminders before assignment due dates', default: true },
                  { label: 'Discussion replies', description: 'When someone replies to your posts', default: true },
                  { label: 'Certificate earned', description: 'When you complete a course and earn a certificate', default: true },
                  { label: 'New course recommendations', description: 'Personalized course suggestions', default: false },
                  { label: 'Promotional emails', description: 'Discounts, flash sales, and special offers', default: false },
                  { label: 'Weekly learning summary', description: 'Your weekly progress report', default: true },
                ].map((pref) => (
                  <div key={pref.label}>
                    <div className="flex items-center justify-between gap-4">
                      <div>
                        <p className="text-sm font-medium">{pref.label}</p>
                        <p className="text-xs text-muted-foreground">{pref.description}</p>
                      </div>
                      <button
                        className={cn(
                          'relative w-10 h-5 rounded-full transition-colors shrink-0',
                          pref.default ? 'bg-primary' : 'bg-secondary border'
                        )}
                      >
                        <span className={cn(
                          'absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform',
                          pref.default ? 'translate-x-5' : 'translate-x-0.5'
                        )} />
                      </button>
                    </div>
                    <Separator className="mt-4" />
                  </div>
                ))}
                <Button>Save Preferences</Button>
              </div>
            )}

            {activeTab === 'sessions' && (
              <div className="bg-card border rounded-2xl p-6">
                <div className="flex items-center justify-between mb-5">
                  <h2 className="font-display font-bold">Active Sessions</h2>
                  <Button variant="outline" size="sm" className="text-destructive border-destructive/30">
                    Sign Out All
                  </Button>
                </div>
                <div className="space-y-4">
                  {MOCK_SESSIONS.map((s) => (
                    <div key={s.id} className="flex items-center justify-between gap-4 p-4 border rounded-xl">
                      <div className="flex items-center gap-3">
                        <div className={cn('w-9 h-9 rounded-lg flex items-center justify-center', s.current ? 'bg-primary/10' : 'bg-secondary')}>
                          <Smartphone className={cn('w-4 h-4', s.current ? 'text-primary' : 'text-muted-foreground')} />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <p className="text-sm font-medium">{s.device}</p>
                            {s.current && <span className="text-[10px] bg-primary/10 text-primary px-1.5 py-0.5 rounded-full font-medium">Current</span>}
                          </div>
                          <p className="text-xs text-muted-foreground">{s.browser} · {s.location}</p>
                          <p className="text-xs text-muted-foreground">{s.lastActive}</p>
                        </div>
                      </div>
                      {!s.current && (
                        <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive hover:bg-destructive/10">
                          Revoke
                        </Button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'appearance' && (
              <div className="bg-card border rounded-2xl p-6 space-y-6">
                <h2 className="font-display font-bold">Appearance</h2>

                <div>
                  <Label className="mb-3 block">Theme</Label>
                  <div className="grid grid-cols-3 gap-3">
                    {['Light', 'Dark', 'System'].map((theme) => (
                      <button
                        key={theme}
                        className={cn(
                          'p-4 border-2 rounded-xl text-sm font-medium transition-all',
                          (theme === 'Dark' && darkMode) || (theme === 'Light' && !darkMode)
                            ? 'border-primary bg-primary/5 text-primary'
                            : 'border-border hover:border-primary/40'
                        )}
                        onClick={() => setDarkMode(theme === 'Dark')}
                      >
                        <div className={cn('w-full aspect-video rounded-lg mb-2', theme === 'Light' ? 'bg-white border' : theme === 'Dark' ? 'bg-gray-900' : 'bg-gradient-to-r from-white to-gray-900')} />
                        {theme}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <Label className="mb-3 block">Language</Label>
                  <select className="w-full max-w-xs px-3 py-2.5 text-sm bg-background border rounded-xl outline-none focus:ring-2 ring-primary/30">
                    {['English', 'Spanish', 'French', 'German', 'Portuguese', 'Hindi', 'Japanese'].map((l) => (
                      <option key={l}>{l}</option>
                    ))}
                  </select>
                </div>

                <Button>Save Preferences</Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
