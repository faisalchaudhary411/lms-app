'use client';

import { useState } from 'react';
import { Shield, Smartphone, Key, Eye, EyeOff, Check, AlertTriangle, Loader2 } from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import toast from 'react-hot-toast';

export default function SecurityPage() {
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [savingPassword, setSavingPassword] = useState(false);
  const [twoFAEnabled, setTwoFAEnabled] = useState(false);
  const [passwords, setPasswords] = useState({ current: '', newPass: '', confirm: '' });

  const handleChangePassword = async () => {
    if (!passwords.current || !passwords.newPass) { toast.error('Please fill all fields'); return; }
    if (passwords.newPass !== passwords.confirm) { toast.error('Passwords do not match'); return; }
    if (passwords.newPass.length < 8) { toast.error('Password must be at least 8 characters'); return; }
    setSavingPassword(true);
    try {
      await fetch('/api/user/change-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ currentPassword: passwords.current, newPassword: passwords.newPass }),
      });
      setPasswords({ current: '', newPass: '', confirm: '' });
      toast.success('Password updated successfully!');
    } catch { toast.error('Failed to update password'); }
    finally { setSavingPassword(false); }
  };

  const SESSIONS = [
    { id: '1', device: 'MacBook Pro 16"', browser: 'Chrome 124', os: 'macOS 14', location: 'San Francisco, US', lastActive: 'Now', current: true },
    { id: '2', device: 'iPhone 15 Pro', browser: 'Safari 17', os: 'iOS 17', location: 'San Francisco, US', lastActive: '3 hours ago', current: false },
    { id: '3', device: 'iPad Air', browser: 'Safari 17', os: 'iPadOS 17', location: 'New York, US', lastActive: '5 days ago', current: false },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6 max-w-2xl">
        <div>
          <h1 className="text-2xl font-display font-bold">Security</h1>
          <p className="text-muted-foreground mt-1">Manage your account security settings</p>
        </div>

        {/* Password */}
        <div className="bg-card border rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-5">
            <div className="w-9 h-9 bg-primary/10 rounded-lg flex items-center justify-center">
              <Key className="w-4 h-4 text-primary" />
            </div>
            <div>
              <h3 className="font-display font-bold">Change Password</h3>
              <p className="text-xs text-muted-foreground">Last changed 3 months ago</p>
            </div>
          </div>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Current Password</Label>
              <div className="relative">
                <Input type={showCurrent ? 'text' : 'password'} value={passwords.current} onChange={(e) => setPasswords((p) => ({ ...p, current: e.target.value }))} placeholder="••••••••" className="pr-10 h-11" />
                <button onClick={() => setShowCurrent(!showCurrent)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                  {showCurrent ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            <div className="space-y-2">
              <Label>New Password</Label>
              <div className="relative">
                <Input type={showNew ? 'text' : 'password'} value={passwords.newPass} onChange={(e) => setPasswords((p) => ({ ...p, newPass: e.target.value }))} placeholder="Min. 8 characters" className="pr-10 h-11" />
                <button onClick={() => setShowNew(!showNew)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                  {showNew ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Confirm New Password</Label>
              <Input type="password" value={passwords.confirm} onChange={(e) => setPasswords((p) => ({ ...p, confirm: e.target.value }))} placeholder="••••••••" className="h-11" />
            </div>
            <Button onClick={handleChangePassword} disabled={savingPassword} className="gap-2">
              {savingPassword ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
              Update Password
            </Button>
          </div>
        </div>

        {/* Two-factor authentication */}
        <div className="bg-card border rounded-2xl p-6">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 bg-violet-500/10 rounded-lg flex items-center justify-center shrink-0">
                <Smartphone className="w-4 h-4 text-violet-500" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-display font-bold">Two-Factor Authentication</h3>
                  <Badge className={twoFAEnabled ? 'bg-primary/10 text-primary border-0' : 'bg-secondary border-0 text-muted-foreground'}>
                    {twoFAEnabled ? 'Enabled' : 'Disabled'}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground mt-1">
                  Add an extra layer of security using an authenticator app like Google Authenticator or Authy.
                </p>
                {!twoFAEnabled && (
                  <div className="flex items-start gap-2 mt-3 p-3 bg-amber-500/10 rounded-lg">
                    <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                    <p className="text-xs text-amber-600 dark:text-amber-400">Your account is not protected with 2FA. Enable it to keep your account secure.</p>
                  </div>
                )}
              </div>
            </div>
            <Button variant={twoFAEnabled ? 'outline' : 'default'} size="sm" onClick={() => { setTwoFAEnabled(!twoFAEnabled); toast.success(twoFAEnabled ? '2FA disabled' : '2FA enabled!'); }} className="shrink-0">
              {twoFAEnabled ? 'Disable 2FA' : 'Enable 2FA'}
            </Button>
          </div>
        </div>

        {/* Active sessions */}
        <div className="bg-card border rounded-2xl overflow-hidden">
          <div className="flex items-center justify-between p-6 border-b">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 bg-blue-500/10 rounded-lg flex items-center justify-center">
                <Shield className="w-4 h-4 text-blue-500" />
              </div>
              <div>
                <h3 className="font-display font-bold">Active Sessions</h3>
                <p className="text-xs text-muted-foreground">{SESSIONS.length} devices logged in</p>
              </div>
            </div>
            <Button variant="outline" size="sm" className="text-destructive border-destructive/30 hover:bg-destructive hover:text-white">
              Sign Out All
            </Button>
          </div>
          <div className="divide-y divide-border/50">
            {SESSIONS.map((s) => (
              <div key={s.id} className="flex items-center gap-4 p-5">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${s.current ? 'bg-primary/10' : 'bg-secondary'}`}>
                  <Smartphone className={`w-5 h-5 ${s.current ? 'text-primary' : 'text-muted-foreground'}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="text-sm font-medium">{s.device}</p>
                    {s.current && <Badge className="text-[10px] bg-primary/10 text-primary border-0 px-1.5">Current</Badge>}
                  </div>
                  <p className="text-xs text-muted-foreground">{s.browser} · {s.os}</p>
                  <p className="text-xs text-muted-foreground">{s.location} · {s.lastActive}</p>
                </div>
                {!s.current && (
                  <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive hover:bg-destructive/10 shrink-0">
                    Revoke
                  </Button>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Delete account */}
        <div className="bg-destructive/5 border border-destructive/20 rounded-2xl p-6">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-destructive shrink-0 mt-0.5" />
            <div>
              <h3 className="font-semibold text-destructive mb-1">Danger Zone</h3>
              <p className="text-sm text-muted-foreground mb-3">
                Deleting your account is permanent and cannot be undone. All your data, enrollments, and certificates will be permanently removed.
              </p>
              <Button variant="destructive" size="sm">Delete My Account</Button>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
