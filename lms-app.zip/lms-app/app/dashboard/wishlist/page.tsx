'use client';

import { useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { Heart, ShoppingCart, Trash2, Star, Clock, Users, BookOpen } from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn, formatMinutes } from '@/lib/utils';
import toast from 'react-hot-toast';

const MOCK_WISHLIST = [
  { id: 'w1', addedAt: new Date(), course: { id: '1', slug: 'nextjs-fullstack', title: 'Full-Stack Next.js 14 & React', thumbnail: 'https://images.unsplash.com/photo-1627398242454-45a1465c2479?w=400&h=225&fit=crop', price: 99.99, discountPrice: 17.99, level: 'INTERMEDIATE', durationMinutes: 3060, totalStudents: 58300, avgRating: 4.7, totalReviews: 7823, instructor: { user: { name: 'Chris Lee' } } } },
  { id: 'w2', addedAt: new Date(), course: { id: '2', slug: 'docker-kubernetes', title: 'Docker & Kubernetes: The Complete Guide', thumbnail: 'https://images.unsplash.com/photo-1605745341112-85968b19335b?w=400&h=225&fit=crop', price: 89.99, discountPrice: 14.99, level: 'ADVANCED', durationMinutes: 2700, totalStudents: 43210, avgRating: 4.6, totalReviews: 5621, instructor: { user: { name: 'Alex Kumar' } } } },
  { id: 'w3', addedAt: new Date(), course: { id: '3', slug: 'machine-learning', title: 'Machine Learning A–Z: Python & R', thumbnail: 'https://images.unsplash.com/photo-1509228468518-180b8ef8ade0?w=400&h=225&fit=crop', price: 119.99, discountPrice: 19.99, level: 'INTERMEDIATE', durationMinutes: 4500, totalStudents: 112400, avgRating: 4.8, totalReviews: 24387, instructor: { user: { name: 'Dr. Smith' } } } },
  { id: 'w4', addedAt: new Date(), course: { id: '4', slug: 'typescript-advanced', title: 'TypeScript: The Complete Developer Guide', thumbnail: 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=400&h=225&fit=crop', price: 84.99, discountPrice: 13.99, level: 'INTERMEDIATE', durationMinutes: 2640, totalStudents: 67234, avgRating: 4.8, totalReviews: 9823, instructor: { user: { name: 'Stephen Grider' } } } },
];

export default function WishlistPage() {
  const [wishlist, setWishlist] = useState(MOCK_WISHLIST);

  const removeFromWishlist = (id: string) => {
    setWishlist((prev) => prev.filter((w) => w.id !== id));
    toast.success('Removed from wishlist');
  };

  const addAllToCart = () => {
    toast.success(`${wishlist.length} courses added to cart!`);
  };

  const totalSavings = wishlist.reduce(
    (sum, w) => sum + (w.course.price - (w.course.discountPrice || w.course.price)), 0
  );

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-2xl font-display font-bold flex items-center gap-2">
              <Heart className="w-5 h-5 text-red-500 fill-red-500" />
              My Wishlist
            </h1>
            <p className="text-muted-foreground mt-1">{wishlist.length} courses saved</p>
          </div>
          {wishlist.length > 0 && (
            <Button onClick={addAllToCart} className="gap-2">
              <ShoppingCart className="w-4 h-4" />
              Add All to Cart
            </Button>
          )}
        </div>

        {wishlist.length === 0 ? (
          <div className="text-center py-20 border rounded-2xl">
            <Heart className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
            <p className="font-semibold mb-1">Your wishlist is empty</p>
            <p className="text-sm text-muted-foreground mb-5">Save courses you want to take later</p>
            <Button asChild><Link href="/courses">Browse Courses</Link></Button>
          </div>
        ) : (
          <>
            {/* Savings banner */}
            {totalSavings > 0 && (
              <div className="bg-primary/10 border border-primary/20 rounded-xl p-4 flex items-center gap-3">
                <div className="text-2xl">🎉</div>
                <div>
                  <p className="font-semibold text-sm">You&apos;re saving ${totalSavings.toFixed(2)}!</p>
                  <p className="text-xs text-muted-foreground">Current promotions applied to your wishlist</p>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
              {wishlist.map((item) => (
                <div key={item.id} className="bg-card border rounded-2xl overflow-hidden hover:border-primary/30 hover:shadow-md transition-all group flex flex-col">
                  {/* Thumbnail */}
                  <div className="relative aspect-video overflow-hidden bg-secondary">
                    <Image
                      src={item.course.thumbnail}
                      alt={item.course.title}
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-2 right-2">
                      {item.course.discountPrice && (
                        <Badge className="bg-red-500 text-white border-0 text-[10px] font-bold">
                          {Math.round(((item.course.price - item.course.discountPrice) / item.course.price) * 100)}% OFF
                        </Badge>
                      )}
                    </div>
                  </div>

                  <div className="p-4 flex-1 flex flex-col">
                    <Link href={`/courses/${item.course.slug}`}>
                      <h3 className="font-semibold text-sm leading-snug line-clamp-2 hover:text-primary transition-colors mb-1">
                        {item.course.title}
                      </h3>
                    </Link>
                    <p className="text-xs text-muted-foreground mb-2">{item.course.instructor.user.name}</p>

                    {/* Meta */}
                    <div className="flex items-center gap-3 text-xs text-muted-foreground mb-3">
                      <span className="flex items-center gap-0.5 text-amber-500 font-semibold">
                        <Star className="w-2.5 h-2.5 fill-amber-500" />
                        {item.course.avgRating}
                      </span>
                      <span>({item.course.totalReviews.toLocaleString()})</span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-2.5 h-2.5" />
                        {formatMinutes(item.course.durationMinutes)}
                      </span>
                      <Badge variant="outline" className="text-[10px] px-1.5 py-0">
                        {item.course.level.replace('_', ' ')}
                      </Badge>
                    </div>

                    {/* Price & actions */}
                    <div className="flex items-center justify-between gap-3 mt-auto">
                      <div className="flex items-baseline gap-2">
                        <span className="text-lg font-bold">
                          ${(item.course.discountPrice || item.course.price).toFixed(2)}
                        </span>
                        {item.course.discountPrice && (
                          <span className="text-sm text-muted-foreground line-through">
                            ${item.course.price.toFixed(2)}
                          </span>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="w-8 h-8 text-muted-foreground hover:text-destructive"
                          onClick={() => removeFromWishlist(item.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                        <Button size="sm" className="gap-1.5" asChild>
                          <Link href={`/checkout?courseId=${item.course.id}`}>
                            <ShoppingCart className="w-3.5 h-3.5" />
                            Buy Now
                          </Link>
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </DashboardLayout>
  );
}
