import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { redirect } from 'next/navigation';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { MyCoursesList } from '@/components/dashboard/MyCoursesList';

export const metadata = { title: 'My Courses' };

export default async function MyCoursesPage() {
  const session = await getServerSession(authOptions);
  if (!session) redirect('/auth/login');

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-display font-bold">My Courses</h1>
          <p className="text-muted-foreground mt-1">Track your learning progress</p>
        </div>
        <MyCoursesList userId={session.user?.id} />
      </div>
    </DashboardLayout>
  );
}
