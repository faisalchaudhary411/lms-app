'use client';

import { useState, useRef, useEffect } from 'react';
import { Navbar } from '@/components/layout/Navbar';
import {
  Play, RotateCcw, Copy, Check, Download, Share2, Settings,
  Terminal, Code2, ChevronDown, Loader2, BookOpen, Maximize2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import toast from 'react-hot-toast';

const LANGUAGES = [
  { id: 'javascript', label: 'JavaScript', ext: '.js', color: 'text-yellow-500' },
  { id: 'typescript', label: 'TypeScript', ext: '.ts', color: 'text-blue-500' },
  { id: 'python', label: 'Python', ext: '.py', color: 'text-green-500' },
  { id: 'html', label: 'HTML/CSS', ext: '.html', color: 'text-orange-500' },
  { id: 'sql', label: 'SQL', ext: '.sql', color: 'text-violet-500' },
];

const STARTER_CODE: Record<string, string> = {
  javascript: `// Welcome to LearnForge Playground 🎯
// Write your JavaScript code below

function fibonacci(n) {
  if (n <= 1) return n;
  return fibonacci(n - 1) + fibonacci(n - 2);
}

// Generate first 10 Fibonacci numbers
const results = Array.from({ length: 10 }, (_, i) => fibonacci(i));
console.log('Fibonacci sequence:', results);

// Array methods practice
const numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
const evenSquares = numbers
  .filter(n => n % 2 === 0)
  .map(n => n ** 2);

console.log('Even squares:', evenSquares);
`,
  typescript: `// TypeScript Playground
interface User {
  id: number;
  name: string;
  email: string;
  role: 'admin' | 'student' | 'instructor';
}

type UserWithOptional = Partial<User> & Pick<User, 'id'>;

function greetUser(user: User): string {
  return \`Hello, \${user.name}! You are a \${user.role}.\`;
}

const user: User = {
  id: 1,
  name: 'Alice',
  email: 'alice@example.com',
  role: 'student'
};

console.log(greetUser(user));

// Generic function
function getProperty<T, K extends keyof T>(obj: T, key: K): T[K] {
  return obj[key];
}

console.log(getProperty(user, 'name'));
`,
  python: `# Python Playground 🐍
# Write your Python code below

def bubble_sort(arr):
    """Simple bubble sort implementation"""
    n = len(arr)
    for i in range(n):
        for j in range(0, n - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
    return arr

# List comprehensions
numbers = [3, 1, 4, 1, 5, 9, 2, 6, 5, 3]
sorted_nums = bubble_sort(numbers.copy())
print(f"Original: {numbers}")
print(f"Sorted: {sorted_nums}")

# Dictionary operations
word_count = {}
sentence = "the quick brown fox jumps over the lazy dog"
for word in sentence.split():
    word_count[word] = word_count.get(word, 0) + 1

print(f"\\nWord frequencies: {word_count}")
print(f"Most common: '{max(word_count, key=word_count.get)}'")
`,
  html: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>HTML/CSS Playground</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: system-ui, sans-serif;
      background: linear-gradient(135deg, #0f172a, #1e293b);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 2rem;
    }
    .card {
      background: white;
      border-radius: 16px;
      padding: 2rem;
      max-width: 400px;
      width: 100%;
      box-shadow: 0 25px 50px rgba(0,0,0,0.3);
    }
    h1 { color: #0f172a; margin-bottom: 0.5rem; }
    p { color: #64748b; margin-bottom: 1.5rem; }
    .btn {
      background: #22c55e;
      color: white;
      border: none;
      padding: 0.75rem 1.5rem;
      border-radius: 8px;
      font-size: 1rem;
      cursor: pointer;
      transition: background 0.2s;
    }
    .btn:hover { background: #16a34a; }
    .tag { display: inline-flex; align-items: center; gap: 4px;
      background: #f0fdf4; color: #15803d; padding: 4px 10px;
      border-radius: 9999px; font-size: 0.75rem; font-weight: 600;
      border: 1px solid #bbf7d0; margin: 4px; }
  </style>
</head>
<body>
  <div class="card">
    <h1>🎉 Hello, Playground!</h1>
    <p>Edit this HTML/CSS to see live changes in the preview panel.</p>
    <div>
      <span class="tag">✓ HTML5</span>
      <span class="tag">✓ CSS3</span>
      <span class="tag">✓ Flexbox</span>
    </div>
    <br>
    <button class="btn" onclick="this.textContent='Clicked! 🚀'">
      Click me!
    </button>
  </div>
</body>
</html>`,
  sql: `-- SQL Playground
-- LearnForge Sample Database

-- Create tables
CREATE TABLE students (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT UNIQUE,
  enrolled_at DATE DEFAULT CURRENT_DATE
);

CREATE TABLE courses (
  id INTEGER PRIMARY KEY,
  title TEXT NOT NULL,
  instructor TEXT,
  price DECIMAL(10,2),
  category TEXT
);

CREATE TABLE enrollments (
  student_id INTEGER,
  course_id INTEGER,
  progress INTEGER DEFAULT 0,
  enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (student_id, course_id)
);

-- Insert sample data
INSERT INTO students VALUES
  (1, 'Alice Johnson', 'alice@example.com', '2024-01-15'),
  (2, 'Bob Smith', 'bob@example.com', '2024-02-10'),
  (3, 'Carol White', 'carol@example.com', '2024-03-05');

INSERT INTO courses VALUES
  (1, 'Complete React Developer', 'Andrew Mead', 14.99, 'Web Dev'),
  (2, 'Python for Data Science', 'Sarah Johnson', 16.99, 'Data Science'),
  (3, 'AWS Cloud Practitioner', 'Mike Chen', 12.99, 'Cloud');

INSERT INTO enrollments VALUES
  (1, 1, 68), (1, 2, 34), (2, 1, 45), (3, 3, 85);

-- Query: Students with their courses and progress
SELECT
  s.name,
  c.title AS course,
  e.progress || '%' AS progress,
  c.category
FROM enrollments e
JOIN students s ON s.id = e.student_id
JOIN courses c ON c.id = e.course_id
ORDER BY s.name, e.progress DESC;
`,
};

const MOCK_EXERCISES = [
  { id: '1', title: 'FizzBuzz', language: 'javascript', difficulty: 'Beginner', description: 'Print numbers 1–100. For multiples of 3 print "Fizz", for 5 "Buzz", for both "FizzBuzz".' },
  { id: '2', title: 'Reverse a String', language: 'javascript', difficulty: 'Beginner', description: 'Write a function that reverses a string without using .reverse().' },
  { id: '3', title: 'Two Sum', language: 'python', difficulty: 'Intermediate', description: 'Given an array of integers and a target, return indices of two numbers that add up to target.' },
  { id: '4', title: 'Fibonacci with Memoisation', language: 'javascript', difficulty: 'Intermediate', description: 'Implement an optimised Fibonacci using memoisation to avoid redundant calls.' },
  { id: '5', title: 'Implement a Stack', language: 'typescript', difficulty: 'Intermediate', description: 'Create a generic Stack class with push, pop, peek and isEmpty methods.' },
];

const DIFF_COLORS: Record<string, string> = {
  Beginner: 'bg-primary/10 text-primary border-primary/20',
  Intermediate: 'bg-blue-500/10 text-blue-500 border-blue-500/20',
  Advanced: 'bg-red-500/10 text-red-500 border-red-500/20',
};

export default function PlaygroundPage() {
  const [language, setLanguage] = useState('javascript');
  const [code, setCode] = useState(STARTER_CODE.javascript);
  const [output, setOutput] = useState<string[]>([]);
  const [running, setRunning] = useState(false);
  const [copied, setCopied] = useState(false);
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [fontSize, setFontSize] = useState(14);
  const [showExercises, setShowExercises] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const currentLang = LANGUAGES.find((l) => l.id === language)!;

  const switchLanguage = (id: string) => {
    setLanguage(id);
    setCode(STARTER_CODE[id] || '// Start coding here\n');
    setOutput([]);
    setShowPreview(id === 'html');
  };

  const runCode = async () => {
    setRunning(true);
    setOutput([]);
    await new Promise((r) => setTimeout(r, 600));

    if (language === 'javascript' || language === 'typescript') {
      const logs: string[] = [];
      const fakeConsole = {
        log: (...args: any[]) => logs.push(args.map((a) => typeof a === 'object' ? JSON.stringify(a, null, 2) : String(a)).join(' ')),
        error: (...args: any[]) => logs.push(`❌ ${args.join(' ')}`),
        warn: (...args: any[]) => logs.push(`⚠️  ${args.join(' ')}`),
        info: (...args: any[]) => logs.push(`ℹ️  ${args.join(' ')}`),
      };
      try {
        const fn = new Function('console', code);
        fn(fakeConsole);
        setOutput(logs.length ? logs : ['✓ Code ran successfully (no output)']);
      } catch (err: any) {
        setOutput([`❌ ${err.message}`]);
      }
    } else if (language === 'html') {
      setShowPreview(true);
      setOutput(['✓ Preview updated']);
    } else {
      setOutput([
        '✓ Code submitted for server-side execution',
        language === 'python' ? '→ Python 3.12 runtime' : `→ ${currentLang.label} runtime`,
        '→ Output would appear here in a full deployment',
        '',
        'Note: JS/TS execute client-side. Python/SQL run',
        'server-side via the execution API (requires backend).',
      ]);
    }
    setRunning(false);
  };

  const copyCode = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    toast.success('Code copied!');
    setTimeout(() => setCopied(false), 2000);
  };

  const resetCode = () => {
    setCode(STARTER_CODE[language] || '');
    setOutput([]);
    toast.success('Code reset');
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const ta = e.currentTarget;
      const start = ta.selectionStart;
      const end = ta.selectionEnd;
      const newCode = code.substring(0, start) + '  ' + code.substring(end);
      setCode(newCode);
      requestAnimationFrame(() => {
        ta.selectionStart = ta.selectionEnd = start + 2;
      });
    }
    if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
      e.preventDefault();
      runCode();
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />

      <div className="flex-1 pt-16 flex flex-col">
        {/* Top toolbar */}
        <div className="border-b bg-card px-4 py-2 flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2">
            <Code2 className="w-4 h-4 text-primary" />
            <span className="font-display font-bold text-sm">Coding Playground</span>
          </div>

          <div className="h-4 w-px bg-border" />

          {/* Language selector */}
          <div className="flex gap-1">
            {LANGUAGES.map((lang) => (
              <button
                key={lang.id}
                onClick={() => switchLanguage(lang.id)}
                className={cn(
                  'px-3 py-1.5 text-xs font-medium rounded-lg transition-all',
                  language === lang.id
                    ? 'bg-primary/10 text-primary'
                    : 'text-muted-foreground hover:bg-secondary hover:text-foreground'
                )}
              >
                {lang.label}
              </button>
            ))}
          </div>

          <div className="flex-1" />

          {/* Controls */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowExercises(!showExercises)}
              className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground px-2 py-1.5 rounded-lg hover:bg-secondary transition-colors"
            >
              <BookOpen className="w-3.5 h-3.5" />
              Exercises
            </button>

            <div className="flex items-center gap-1 text-xs text-muted-foreground border rounded-lg overflow-hidden">
              <button
                className="px-2 py-1.5 hover:bg-secondary transition-colors"
                onClick={() => setFontSize((s) => Math.max(11, s - 1))}
              >A-</button>
              <span className="px-1">{fontSize}</span>
              <button
                className="px-2 py-1.5 hover:bg-secondary transition-colors"
                onClick={() => setFontSize((s) => Math.min(20, s + 1))}
              >A+</button>
            </div>

            <Button variant="ghost" size="icon" className="w-8 h-8" onClick={copyCode}>
              {copied ? <Check className="w-3.5 h-3.5 text-primary" /> : <Copy className="w-3.5 h-3.5" />}
            </Button>

            <Button variant="ghost" size="icon" className="w-8 h-8" onClick={resetCode}>
              <RotateCcw className="w-3.5 h-3.5" />
            </Button>

            <Button onClick={runCode} disabled={running} size="sm" className="gap-1.5">
              {running ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5 fill-current" />}
              Run <kbd className="hidden sm:inline text-[10px] opacity-60">⌘↵</kbd>
            </Button>
          </div>
        </div>

        <div className="flex-1 flex overflow-hidden" style={{ height: 'calc(100vh - 8.5rem)' }}>
          {/* Exercises panel */}
          {showExercises && (
            <div className="w-64 border-r bg-card flex flex-col shrink-0 overflow-y-auto">
              <div className="p-3 border-b">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Practice Exercises</p>
              </div>
              <div className="p-2 space-y-1.5">
                {MOCK_EXERCISES.map((ex) => (
                  <button
                    key={ex.id}
                    onClick={() => {
                      switchLanguage(ex.language);
                      setShowExercises(false);
                      toast.success(`Exercise loaded: ${ex.title}`);
                    }}
                    className="w-full text-left p-3 rounded-xl hover:bg-secondary/50 transition-colors border border-transparent hover:border-border"
                  >
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <span className="text-sm font-medium">{ex.title}</span>
                      <Badge className={cn('text-[10px] border shrink-0', DIFF_COLORS[ex.difficulty])}>
                        {ex.difficulty}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground line-clamp-2">{ex.description}</p>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Editor */}
          <div className="flex-1 flex flex-col min-w-0">
            <div
              className={cn('flex-1 overflow-hidden', theme === 'dark' ? 'bg-[#0d1117]' : 'bg-white')}
            >
              <textarea
                ref={textareaRef}
                value={code}
                onChange={(e) => setCode(e.target.value)}
                onKeyDown={handleKeyDown}
                spellCheck={false}
                className={cn(
                  'w-full h-full p-5 font-mono outline-none resize-none leading-relaxed bg-transparent',
                  theme === 'dark' ? 'text-gray-100' : 'text-gray-900'
                )}
                style={{ fontSize, tabSize: 2 }}
                placeholder="// Start coding here..."
              />
            </div>

            {/* Output console */}
            <div className="h-44 border-t bg-[#0d1117] flex flex-col">
              <div className="flex items-center gap-2 px-4 py-2 border-b border-white/10">
                <Terminal className="w-3.5 h-3.5 text-primary" />
                <span className="text-xs font-mono text-gray-400">Output</span>
                {output.length > 0 && (
                  <button
                    onClick={() => setOutput([])}
                    className="ml-auto text-[10px] text-gray-500 hover:text-gray-300"
                  >
                    Clear
                  </button>
                )}
              </div>
              <div className="flex-1 overflow-y-auto p-4 font-mono text-xs space-y-1 scrollbar-hide">
                {output.length === 0 ? (
                  <p className="text-gray-600">Press ▶ Run or ⌘↵ to execute your code</p>
                ) : (
                  output.map((line, i) => (
                    <div
                      key={i}
                      className={cn(
                        'leading-relaxed whitespace-pre-wrap',
                        line.startsWith('❌') ? 'text-red-400' :
                        line.startsWith('⚠️') ? 'text-yellow-400' :
                        line.startsWith('✓') ? 'text-primary' :
                        line.startsWith('→') ? 'text-gray-500' :
                        'text-gray-200'
                      )}
                    >
                      {line || <br />}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* HTML Preview panel */}
          {showPreview && language === 'html' && (
            <div className="w-96 border-l bg-white flex flex-col shrink-0">
              <div className="flex items-center justify-between px-3 py-2 border-b bg-card">
                <span className="text-xs font-semibold text-muted-foreground">Preview</span>
                <button onClick={() => setShowPreview(false)} className="text-muted-foreground hover:text-foreground">
                  <Maximize2 className="w-3.5 h-3.5" />
                </button>
              </div>
              <iframe
                srcDoc={code}
                className="flex-1 border-0"
                sandbox="allow-scripts allow-same-origin"
                title="HTML Preview"
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
