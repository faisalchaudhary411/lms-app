'use client';

import { useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { Navbar } from '@/components/layout/Navbar';
import { Footer } from '@/components/layout/Footer';
import {
  ShoppingCart, Trash2, Tag, ArrowRight, Star,
  Clock, Shield, RotateCcw, BookOpen
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { cn, formatMinutes } from '@/lib/utils';
import toast from 'react-hot-toast';

const MOCK_CART = [
  { id: 'ci1', course: { id: '1', slug: 'nextjs-fullstack', title: 'Full-Stack Next.js 14 & React', thumbnail: 'https://images.unsplash.com/photo-1627398242454-45a1465c2479?w=120&h=68&fit=crop', price: 99.99, discountPrice: 17.99, durationMinutes: 3060, avgRating: 4.7, totalReviews: 7823, instructor: { user: { name: 'Chris Lee' } } } },
  { id: 'ci2', course: { id: '2', slug: 'docker-kubernetes', title: 'Docker & Kubernetes: The Complete Guide', thumbnail: 'https://images.unsplash.com/photo-1605745341112-85968b19335b?w=120&h=68&fit=crop', price: 89.99, discountPrice: 14.99, durationMinutes: 2700, avgRating: 4.6, totalReviews: 5621, instructor: { user: { name: 'Alex Kumar' } } } },
];

export default function CartPage() {
  const [items, setItems] = useState(MOCK_CART);
  const [coupon, setCoupon] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<{ code: string; discount: number } | null>(null);

  const subtotal = items.reduce((s, i) => s + (i.course.discountPrice || i.course.price), 0);
  const couponDiscount = appliedCoupon ? (subtotal * appliedCoupon.discount) / 100 : 0;
  const total = subtotal - couponDiscount;

  const removeItem = (id: string) => {
    setItems((prev) => prev.filter((i) => i.id !== id));
    toast.success('Removed from cart');
  };

  const applyCoupon = () => {
    if (coupon.toUpperCase() === 'SAVE20') {
      setAppliedCoupon({ code: 'SAVE20', discount: 20 });
      toast.success('20% discount applied!');
    } else {
      toast.error('Invalid coupon code');
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="pt-20">
        <div className="container mx-auto px-4 max-w-6xl py-10">
          <h1 className="text-2xl font-display font-bold mb-8 flex items-center gap-3">
            <ShoppingCart className="w-6 h-6 text-primary" />
            Shopping Cart
            <Badge variant="secondary">{items.length} items</Badge>
          </h1>

          {items.length === 0 ? (
            <div className="text-center py-20">
              <ShoppingCart className="w-16 h-16 text-muted-foreground/30 mx-auto mb-4" />
              <h2 className="text-xl font-display font-bold mb-2">Your cart is empty</h2>
              <p className="text-muted-foreground mb-6">Looks like you haven&apos;t added any courses yet.</p>
              <Button asChild><Link href="/courses">Browse Courses</Link></Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
              {/* Cart items */}
              <div className="lg:col-span-2 space-y-4">
                {items.map((item) => (
                  <div key={item.id} className="bg-card border rounded-2xl p-4 flex gap-4 group hover:border-primary/20 transition-colors">
                    <div className="relative w-28 h-18 rounded-xl overflow-hidden bg-secondary shrink-0">
                      <Image src={item.course.thumbnail} alt={item.course.title} fill className="object-cover" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <Link href={`/courses/${item.course.slug}`}>
                        <h3 className="font-semibold text-sm line-clamp-2 hover:text-primary transition-colors mb-1">
                          {item.course.title}
                        </h3>
                      </Link>
                      <p className="text-xs text-muted-foreground mb-2">{item.course.instructor.user.name}</p>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground">
                        <span className="flex items-center gap-0.5 text-amber-500">
                          <Star className="w-2.5 h-2.5 fill-amber-500" />{item.course.avgRating}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-2.5 h-2.5" />{formatMinutes(item.course.durationMinutes)}
                        </span>
                      </div>
                    </div>
                    <div className="flex flex-col items-end justify-between shrink-0">
                      <button
                        onClick={() => removeItem(item.id)}
                        className="text-muted-foreground hover:text-destructive transition-colors p-1"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                      <div className="text-right">
                        <div className="font-bold">${(item.course.discountPrice || item.course.price).toFixed(2)}</div>
                        {item.course.discountPrice && (
                          <div className="text-xs text-muted-foreground line-through">${item.course.price.toFixed(2)}</div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}

                {/* Trust badges */}
                <div className="grid grid-cols-3 gap-3 pt-2">
                  {[
                    { icon: Shield, text: 'Secure checkout' },
                    { icon: RotateCcw, text: '30-day refunds' },
                    { icon: BookOpen, text: 'Lifetime access' },
                  ].map((item) => (
                    <div key={item.text} className="flex items-center gap-2 text-xs text-muted-foreground p-3 bg-secondary/50 rounded-xl">
                      <item.icon className="w-3.5 h-3.5 text-primary shrink-0" />
                      {item.text}
                    </div>
                  ))}
                </div>
              </div>

              {/* Order summary */}
              <div className="lg:col-span-1">
                <div className="bg-card border rounded-2xl p-6 sticky top-24">
                  <h2 className="font-display font-bold mb-4">Order Summary</h2>

                  <div className="space-y-2 text-sm mb-4">
                    <div className="flex justify-between text-muted-foreground">
                      <span>Subtotal</span>
                      <span>${subtotal.toFixed(2)}</span>
                    </div>
                    {appliedCoupon && (
                      <div className="flex justify-between text-primary">
                        <span className="flex items-center gap-1">
                          <Tag className="w-3 h-3" />
                          {appliedCoupon.code} ({appliedCoupon.discount}% off)
                        </span>
                        <span>-${couponDiscount.toFixed(2)}</span>
                      </div>
                    )}
                    <Separator />
                    <div className="flex justify-between font-bold text-base">
                      <span>Total</span>
                      <span>${total.toFixed(2)}</span>
                    </div>
                  </div>

                  <Button size="lg" className="w-full gap-2 mb-4" asChild>
                    <Link href={`/checkout?items=${items.map((i) => i.course.id).join(',')}`}>
                      Checkout <ArrowRight className="w-4 h-4" />
                    </Link>
                  </Button>

                  {/* Coupon */}
                  <div>
                    <p className="text-xs text-muted-foreground mb-2">Have a coupon?</p>
                    <div className="flex gap-2">
                      <Input
                        value={coupon}
                        onChange={(e) => setCoupon(e.target.value.toUpperCase())}
                        placeholder="SAVE20"
                        className="h-9 text-sm"
                      />
                      <Button size="sm" variant="outline" onClick={applyCoupon}>Apply</Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
}
