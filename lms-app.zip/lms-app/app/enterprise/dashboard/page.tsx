'use client';

import { useState } from 'react';
import {
  Users, BookOpen, TrendingUp, Award, Plus, Search,
  Mail, MoreHorizontal, ChevronRight, BarChart2, Shield
} from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from 'recharts';

const TS = { background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '12px', fontSize: '12px' };

const TEAM_MEMBERS = [
  { id: '1', name: 'Alice Johnson', email: 'alice@acme.com', role: 'Frontend Dev', team: 'Engineering', coursesCompleted: 4, inProgress: 2, avgScore: 87, lastActive: '2 hours ago', image: '' },
  { id: '2', name: 'Bob Smith', email: 'bob@acme.com', role: 'Data Analyst', team: 'Data', coursesCompleted: 6, inProgress: 1, avgScore: 92, lastActive: '1 day ago', image: '' },
  { id: '3', name: 'Carol White', email: 'carol@acme.com', role: 'Product Manager', team: 'Product', coursesCompleted: 3, inProgress: 3, avgScore: 78, lastActive: '3 days ago', image: '' },
  { id: '4', name: 'David Lee', email: 'david@acme.com', role: 'Backend Dev', team: 'Engineering', coursesCompleted: 7, inProgress: 0, avgScore: 95, lastActive: '5 hours ago', image: '' },
  { id: '5', name: 'Eva Martinez', email: 'eva@acme.com', role: 'DevOps', team: 'Engineering', coursesCompleted: 5, inProgress: 2, avgScore: 83, lastActive: '12 hours ago', image: '' },
];

const TEAM_PROGRESS = [
  { team: 'Engineering', completions: 42, avg: 88 },
  { team: 'Data', completions: 28, avg: 91 },
  { team: 'Product', completions: 18, avg: 79 },
  { team: 'Design', completions: 15, avg: 84 },
  { team: 'Marketing', completions: 12, avg: 76 },
];

const LEARNING_PATHS = [
  { id: '1', title: 'Full-Stack Web Developer', assignedTo: 12, completed: 5, dueDate: '2024-07-01' },
  { id: '2', title: 'Cloud Architecture', assignedTo: 8, completed: 3, dueDate: '2024-08-15' },
  { id: '3', title: 'Data Science Fundamentals', assignedTo: 6, completed: 6, dueDate: '2024-06-30' },
];

export default function EnterpriseDashboardPage() {
  const [search, setSearch] = useState('');
  const [inviteEmail, setInviteEmail] = useState('');

  const filtered = TEAM_MEMBERS.filter((m) =>
    m.name.toLowerCase().includes(search.toLowerCase()) ||
    m.email.toLowerCase().includes(search.toLowerCase()) ||
    m.team.toLowerCase().includes(search.toLowerCase())
  );

  const totalCompleted = TEAM_MEMBERS.reduce((s, m) => s + m.coursesCompleted, 0);
  const avgScore = Math.round(TEAM_MEMBERS.reduce((s, m) => s + m.avgScore, 0) / TEAM_MEMBERS.length);

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Badge className="bg-violet-500/10 text-violet-500 border-violet-500/20 gap-1.5">
                <Shield className="w-3 h-3" />Acme Corp Enterprise
              </Badge>
            </div>
            <h1 className="text-2xl font-display font-bold">Team Learning Dashboard</h1>
            <p className="text-muted-foreground mt-1">Track and manage learning across your organisation</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="gap-1.5">
              <BarChart2 className="w-3.5 h-3.5" />Reports
            </Button>
            <Button size="sm" className="gap-1.5 bg-violet-500 hover:bg-violet-600">
              <Plus className="w-3.5 h-3.5" />Invite Members
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { label: 'Team Members', value: TEAM_MEMBERS.length, sub: '3 teams', icon: Users, c: 'text-blue-500', bg: 'bg-blue-500/10' },
            { label: 'Courses Completed', value: totalCompleted, sub: 'This quarter', icon: BookOpen, c: 'text-primary', bg: 'bg-primary/10' },
            { label: 'Avg Quiz Score', value: `${avgScore}%`, sub: '+4% vs last month', icon: TrendingUp, c: 'text-violet-500', bg: 'bg-violet-500/10' },
            { label: 'Certificates Earned', value: 18, sub: 'Team-wide', icon: Award, c: 'text-amber-500', bg: 'bg-amber-500/10' },
          ].map((s) => (
            <div key={s.label} className="bg-card border rounded-xl p-5">
              <div className={cn('w-9 h-9 rounded-lg flex items-center justify-center mb-3', s.bg)}>
                <s.icon className={cn('w-4 h-4', s.c)} />
              </div>
              <div className="text-2xl font-display font-bold">{s.value}</div>
              <div className="text-xs text-muted-foreground mt-0.5">{s.label}</div>
              <div className={cn('text-xs mt-1 font-medium', s.c)}>{s.sub}</div>
            </div>
          ))}
        </div>

        {/* Team progress chart */}
        <div className="bg-card border rounded-xl p-6">
          <h3 className="font-display font-bold mb-5">Completions by Team</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={TEAM_PROGRESS} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="team" tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={TS} />
              <Bar name="Completions" dataKey="completions" fill="hsl(var(--primary))" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Assigned learning paths */}
        <div className="bg-card border rounded-xl p-6">
          <div className="flex items-center justify-between mb-5">
            <h3 className="font-display font-bold">Assigned Learning Paths</h3>
            <Button size="sm" variant="outline" className="gap-1.5">
              <Plus className="w-3.5 h-3.5" />Assign Path
            </Button>
          </div>
          <div className="space-y-3">
            {LEARNING_PATHS.map((path) => {
              const pct = Math.round((path.completed / path.assignedTo) * 100);
              return (
                <div key={path.id} className="flex items-center gap-4 p-4 border rounded-xl hover:border-primary/20 transition-colors">
                  <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center shrink-0">
                    <BookOpen className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1.5">
                      <p className="font-medium text-sm">{path.title}</p>
                      <span className="text-xs text-muted-foreground shrink-0 ml-4">Due {path.dueDate}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="flex-1 h-1.5 bg-secondary rounded-full overflow-hidden">
                        <div className="h-full bg-primary rounded-full" style={{ width: `${pct}%` }} />
                      </div>
                      <span className="text-xs text-muted-foreground shrink-0">
                        {path.completed}/{path.assignedTo} completed ({pct}%)
                      </span>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" className="w-8 h-8 shrink-0">
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                </div>
              );
            })}
          </div>
        </div>

        {/* Team members table */}
        <div className="bg-card border rounded-xl overflow-hidden">
          <div className="flex items-center justify-between p-5 border-b gap-4">
            <h3 className="font-display font-bold">Team Members</h3>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search members…" className="pl-8 h-8 text-xs w-52" />
              </div>
              <div className="flex gap-2 bg-secondary rounded-xl px-3 py-1">
                <input
                  value={inviteEmail}
                  onChange={(e) => setInviteEmail(e.target.value)}
                  placeholder="email@company.com"
                  className="bg-transparent text-xs outline-none w-40"
                />
                <Button size="sm" className="h-6 text-xs px-2" onClick={() => { setInviteEmail(''); }}>
                  <Mail className="w-3 h-3 mr-1" />Invite
                </Button>
              </div>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-secondary/20">
                  {['Member', 'Team', 'Completed', 'In Progress', 'Avg Score', 'Last Active', ''].map((h) => (
                    <th key={h} className="text-left px-5 py-3 text-xs font-semibold text-muted-foreground">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-border/50">
                {filtered.map((m) => (
                  <tr key={m.id} className="hover:bg-secondary/20 transition-colors">
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-3">
                        <Avatar className="w-8 h-8">
                          <AvatarFallback className="bg-primary/20 text-primary text-xs font-bold">
                            {m.name.split(' ').map((n) => n[0]).join('')}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium text-sm">{m.name}</p>
                          <p className="text-xs text-muted-foreground">{m.role}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-4">
                      <Badge variant="secondary" className="text-xs">{m.team}</Badge>
                    </td>
                    <td className="px-5 py-4 font-medium text-primary">{m.coursesCompleted}</td>
                    <td className="px-5 py-4 text-muted-foreground">{m.inProgress}</td>
                    <td className="px-5 py-4">
                      <span className={cn('font-bold', m.avgScore >= 90 ? 'text-primary' : m.avgScore >= 75 ? 'text-blue-500' : 'text-amber-500')}>
                        {m.avgScore}%
                      </span>
                    </td>
                    <td className="px-5 py-4 text-xs text-muted-foreground">{m.lastActive}</td>
                    <td className="px-5 py-4">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="w-8 h-8">
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>View Profile</DropdownMenuItem>
                          <DropdownMenuItem>Assign Course</DropdownMenuItem>
                          <DropdownMenuItem>Send Message</DropdownMenuItem>
                          <DropdownMenuItem className="text-destructive">Remove</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
