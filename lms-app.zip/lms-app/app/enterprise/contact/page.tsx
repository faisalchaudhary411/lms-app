'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import {
  Building2, Users, CheckCircle2, Loader2, Mail, Phone,
  GraduationCap, ChevronLeft, ArrowRight
} from 'lucide-react';
import { Navbar } from '@/components/layout/Navbar';
import { Footer } from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import toast from 'react-hot-toast';

const schema = z.object({
  firstName: z.string().min(2),
  lastName: z.string().min(2),
  email: z.string().email(),
  phone: z.string().optional(),
  company: z.string().min(2),
  jobTitle: z.string().min(2),
  teamSize: z.string().min(1),
  useCase: z.string().min(1),
  message: z.string().optional(),
});

type Form = z.infer<typeof schema>;

const TEAM_SIZES = ['1–10', '11–50', '51–200', '201–500', '500+'];
const USE_CASES = ['Employee Training', 'Onboarding', 'Certification Programs', 'Skill Development', 'Leadership Training', 'Technical Upskilling', 'Other'];

const FEATURES = [
  'Unlimited course access for all team members',
  'Custom branded learning portal',
  'Dedicated customer success manager',
  'SSO & SCIM provisioning',
  'Advanced analytics & reporting',
  'Custom learning paths',
  'API access & integrations',
  'Priority 24/7 support',
];

const LOGOS = ['Accenture', 'Deloitte', 'Microsoft', 'Salesforce', 'Shopify', 'Stripe'];

export default function EnterpriseContactPage() {
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const { register, handleSubmit, formState: { errors } } = useForm<Form>({
    resolver: zodResolver(schema),
    defaultValues: { teamSize: '', useCase: '' },
  });

  const onSubmit = async (data: Form) => {
    setLoading(true);
    try {
      await fetch('/api/enterprise/demo-request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      setSubmitted(true);
    } catch {
      toast.error('Failed to submit. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="pt-20">
        <div className="container mx-auto px-4 max-w-6xl py-12">
          <Button variant="ghost" size="sm" asChild className="mb-8 -ml-2 gap-1.5">
            <Link href="/enterprise"><ChevronLeft className="w-4 h-4" />Back to Enterprise</Link>
          </Button>

          {submitted ? (
            /* Success state */
            <div className="max-w-2xl mx-auto text-center py-16 space-y-6">
              <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-10 h-10 text-primary" />
              </div>
              <h2 className="text-3xl font-display font-bold">Request received!</h2>
              <p className="text-muted-foreground text-lg">
                Thanks for your interest in LearnForge Enterprise. Our team will reach out within 1 business day to schedule your personalised demo.
              </p>
              <div className="flex gap-3 justify-center">
                <Button asChild>
                  <Link href="/enterprise">Back to Enterprise</Link>
                </Button>
                <Button variant="outline" asChild>
                  <Link href="/">Go to Home</Link>
                </Button>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-12">
              {/* Form */}
              <div className="lg:col-span-3">
                <div className="mb-8">
                  <Badge className="mb-3 bg-violet-500/10 text-violet-500 border-violet-500/20">Enterprise</Badge>
                  <h1 className="text-3xl font-display font-bold mb-2">Schedule a Demo</h1>
                  <p className="text-muted-foreground">
                    See how LearnForge Enterprise can transform learning at your organisation. Takes 30 minutes.
                  </p>
                </div>

                <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>First Name *</Label>
                      <Input {...register('firstName')} placeholder="John" className="h-11" />
                      {errors.firstName && <p className="text-xs text-destructive">{errors.firstName.message}</p>}
                    </div>
                    <div className="space-y-2">
                      <Label>Last Name *</Label>
                      <Input {...register('lastName')} placeholder="Doe" className="h-11" />
                      {errors.lastName && <p className="text-xs text-destructive">{errors.lastName.message}</p>}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Work Email *</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input {...register('email')} type="email" placeholder="you@company.com" className="pl-10 h-11" />
                      </div>
                      {errors.email && <p className="text-xs text-destructive">{errors.email.message}</p>}
                    </div>
                    <div className="space-y-2">
                      <Label>Phone</Label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input {...register('phone')} placeholder="+1 555 000 0000" className="pl-10 h-11" />
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Company *</Label>
                      <div className="relative">
                        <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input {...register('company')} placeholder="Acme Corp" className="pl-10 h-11" />
                      </div>
                      {errors.company && <p className="text-xs text-destructive">{errors.company.message}</p>}
                    </div>
                    <div className="space-y-2">
                      <Label>Job Title *</Label>
                      <Input {...register('jobTitle')} placeholder="L&D Manager" className="h-11" />
                      {errors.jobTitle && <p className="text-xs text-destructive">{errors.jobTitle.message}</p>}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Team Size *</Label>
                    <div className="flex flex-wrap gap-2">
                      {TEAM_SIZES.map((size) => (
                        <label key={size} className="flex items-center gap-2 cursor-pointer">
                          <input type="radio" value={size} {...register('teamSize')} className="sr-only" />
                          <div className={cn(
                            'px-4 py-2 border rounded-xl text-sm font-medium cursor-pointer transition-all',
                            'hover:border-primary/40'
                          )}>
                            {size}
                          </div>
                        </label>
                      ))}
                    </div>
                    {errors.teamSize && <p className="text-xs text-destructive">{errors.teamSize.message}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label>Primary Use Case *</Label>
                    <select
                      {...register('useCase')}
                      className="w-full h-11 px-3 text-sm bg-background border rounded-xl outline-none focus:ring-2 ring-primary/30"
                    >
                      <option value="">Select primary use case</option>
                      {USE_CASES.map((uc) => <option key={uc}>{uc}</option>)}
                    </select>
                    {errors.useCase && <p className="text-xs text-destructive">{errors.useCase.message}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label>Additional Details</Label>
                    <textarea
                      {...register('message')}
                      placeholder="Tell us about your learning goals, current challenges, or anything else you'd like us to know…"
                      className="w-full px-3 py-2.5 text-sm bg-background border rounded-xl outline-none focus:ring-2 ring-primary/30 resize-none h-24"
                    />
                  </div>

                  <Button type="submit" size="lg" className="w-full gap-2 h-12 bg-violet-500 hover:bg-violet-600" disabled={loading}>
                    {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <ArrowRight className="w-4 h-4" />}
                    {loading ? 'Submitting…' : 'Request a Demo'}
                  </Button>

                  <p className="text-xs text-muted-foreground text-center">
                    By submitting you agree to our{' '}
                    <Link href="/privacy" className="text-primary hover:underline">Privacy Policy</Link>
                  </p>
                </form>
              </div>

              {/* Right panel */}
              <div className="lg:col-span-2 space-y-6">
                {/* What's included */}
                <div className="bg-card border rounded-2xl p-6">
                  <h3 className="font-display font-bold mb-4">What&apos;s included</h3>
                  <ul className="space-y-3">
                    {FEATURES.map((f) => (
                      <li key={f} className="flex items-start gap-3 text-sm">
                        <CheckCircle2 className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Social proof */}
                <div className="bg-secondary/30 rounded-2xl p-5">
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-4">Trusted by</p>
                  <div className="grid grid-cols-3 gap-3">
                    {LOGOS.map((logo) => (
                      <div key={logo} className="text-sm font-display font-bold text-muted-foreground/50 text-center py-2 bg-background rounded-lg">
                        {logo}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { value: '500+', label: 'Enterprise clients' },
                    { value: '2.1M', label: 'Employees trained' },
                    { value: '94%', label: 'Retention rate' },
                    { value: '4.2×', label: 'Average ROI' },
                  ].map((s) => (
                    <div key={s.label} className="bg-card border rounded-xl p-4 text-center">
                      <div className="text-xl font-display font-bold text-violet-500">{s.value}</div>
                      <div className="text-xs text-muted-foreground">{s.label}</div>
                    </div>
                  ))}
                </div>

                {/* Direct contact */}
                <div className="bg-card border rounded-2xl p-5">
                  <p className="text-sm font-semibold mb-2">Prefer to talk?</p>
                  <p className="text-sm text-muted-foreground mb-3">
                    Speak directly with our enterprise team
                  </p>
                  <a href="mailto:enterprise@learnforge.com" className="text-sm text-primary hover:underline flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5" />
                    enterprise@learnforge.com
                  </a>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
}
