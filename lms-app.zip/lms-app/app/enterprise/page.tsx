import Link from 'next/link';
import { Navbar } from '@/components/layout/Navbar';
import { Footer } from '@/components/layout/Footer';
import { Building2, Users, BarChart2, Shield, BookOpen, Zap,
  CheckCircle2, ArrowRight, Globe } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

const FEATURES = [
  { icon: Users, title: 'Team Dashboards', description: 'Manage learning across entire teams with role-based access and progress tracking.' },
  { icon: BarChart2, title: 'Analytics & Reporting', description: 'Deep insights into employee skill development, engagement, and ROI metrics.' },
  { icon: Shield, title: 'SSO & Security', description: 'Enterprise-grade security with SAML SSO, SOC 2 compliance, and data encryption.' },
  { icon: BookOpen, title: 'Custom Learning Paths', description: 'Build tailored curriculums aligned with your business goals and role requirements.' },
  { icon: Zap, title: 'Bulk Enrollment', description: 'Enroll entire departments into courses with a single click. Auto-assign by role.' },
  { icon: Globe, title: 'Multi-language Support', description: 'Content available in 14 languages to support your global workforce.' },
];

const LOGOS = ['Accenture', 'Deloitte', 'Microsoft', 'Salesforce', 'Shopify', 'Stripe'];

export default function EnterprisePage() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="pt-20">
        {/* Hero */}
        <section className="py-24 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-violet-500/5 via-background to-background" />
          <div className="container mx-auto px-4 max-w-6xl relative">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
              <div>
                <Badge className="mb-6 gap-2 bg-violet-500/10 text-violet-500 border-violet-500/20">
                  <Building2 className="w-3.5 h-3.5" />
                  Enterprise Learning
                </Badge>
                <h1 className="text-4xl sm:text-5xl font-display font-bold leading-[1.1] mb-6">
                  Scale learning across your entire{' '}
                  <span className="text-violet-500">organization</span>
                </h1>
                <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                  Empower your workforce with LearnForge Enterprise. Track skills, reduce turnover, and build a culture of continuous learning.
                </p>
                <div className="flex gap-3">
                  <Button size="lg" className="gap-2 bg-violet-500 hover:bg-violet-600" asChild>
                    <Link href="/enterprise/contact">
                      Get a Demo <ArrowRight className="w-4 h-4" />
                    </Link>
                  </Button>
                  <Button size="lg" variant="outline" asChild>
                    <Link href="/enterprise/pricing">View Pricing</Link>
                  </Button>
                </div>
                <div className="flex items-center gap-6 mt-8 text-sm text-muted-foreground">
                  {['No credit card', 'Free 30-day trial', 'Dedicated onboarding'].map((item) => (
                    <div key={item} className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-primary" />
                      {item}
                    </div>
                  ))}
                </div>
              </div>

              {/* Stats card */}
              <div className="grid grid-cols-2 gap-4">
                {[
                  { value: '500+', label: 'Enterprise clients', color: 'text-violet-500' },
                  { value: '2.1M', label: 'Employees trained', color: 'text-primary' },
                  { value: '94%', label: 'Retention improvement', color: 'text-amber-500' },
                  { value: '4.2x', label: 'ROI on avg', color: 'text-blue-500' },
                ].map((stat) => (
                  <div key={stat.label} className="bg-card border rounded-2xl p-6">
                    <div className={`text-3xl font-display font-bold ${stat.color} mb-1`}>{stat.value}</div>
                    <div className="text-sm text-muted-foreground">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Trust logos */}
        <section className="py-12 border-y bg-secondary/20">
          <div className="container mx-auto px-4 max-w-6xl">
            <p className="text-center text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-8">
              Trusted by leading companies
            </p>
            <div className="flex items-center justify-center flex-wrap gap-8">
              {LOGOS.map((logo) => (
                <div key={logo} className="text-lg font-display font-bold text-muted-foreground/40 hover:text-muted-foreground transition-colors">
                  {logo}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Features */}
        <section className="py-24">
          <div className="container mx-auto px-4 max-w-6xl">
            <div className="text-center mb-14">
              <h2 className="text-3xl font-display font-bold mb-4">Everything your team needs</h2>
              <p className="text-muted-foreground max-w-lg mx-auto">
                Built for HR, L&D, and operations teams to drive measurable learning outcomes.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {FEATURES.map((feature) => (
                <div key={feature.title} className="bg-card border rounded-2xl p-6 hover:border-violet-500/30 hover:shadow-md transition-all">
                  <div className="w-10 h-10 bg-violet-500/10 rounded-xl flex items-center justify-center mb-4">
                    <feature.icon className="w-5 h-5 text-violet-500" />
                  </div>
                  <h3 className="font-display font-bold mb-2">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-20 bg-gradient-to-r from-violet-500/10 via-primary/5 to-background">
          <div className="container mx-auto px-4 max-w-3xl text-center">
            <h2 className="text-3xl font-display font-bold mb-4">Ready to transform your team?</h2>
            <p className="text-muted-foreground mb-8">
              Talk to our enterprise team and get a custom plan for your organization.
            </p>
            <Button size="lg" className="bg-violet-500 hover:bg-violet-600 gap-2" asChild>
              <Link href="/enterprise/contact">
                Schedule a Demo <ArrowRight className="w-4 h-4" />
              </Link>
            </Button>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
