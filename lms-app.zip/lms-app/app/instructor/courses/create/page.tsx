'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import {
  BookOpen, Video, FileText, HelpCircle, Code, ChevronDown,
  ChevronUp, Plus, Trash2, GripVertical, Upload, Save,
  Eye, Send, ArrowLeft, AlertCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';
import toast from 'react-hot-toast';
import Link from 'next/link';

const STEPS = [
  { id: 'basics', label: 'Course Info' },
  { id: 'curriculum', label: 'Curriculum' },
  { id: 'pricing', label: 'Pricing' },
  { id: 'publish', label: 'Publish' },
];

const LESSON_TYPES = [
  { type: 'VIDEO', label: 'Video', icon: Video, color: 'text-blue-500' },
  { type: 'READING', label: 'Article', icon: FileText, color: 'text-green-500' },
  { type: 'QUIZ', label: 'Quiz', icon: HelpCircle, color: 'text-amber-500' },
  { type: 'ASSIGNMENT', label: 'Assignment', icon: BookOpen, color: 'text-violet-500' },
  { type: 'CODING', label: 'Coding', icon: Code, color: 'text-pink-500' },
];

type Section = {
  id: string;
  title: string;
  expanded: boolean;
  lessons: { id: string; title: string; type: string }[];
};

const basicSchema = z.object({
  title: z.string().min(10, 'Title must be at least 10 characters'),
  shortDescription: z.string().min(20, 'Short description must be at least 20 characters'),
  description: z.string().min(50, 'Description must be at least 50 characters'),
  category: z.string().min(1, 'Please select a category'),
  level: z.enum(['BEGINNER', 'INTERMEDIATE', 'ADVANCED', 'ALL_LEVELS']),
  language: z.string().min(1, 'Please select a language'),
  outcomes: z.array(z.string()).min(4, 'Please add at least 4 learning outcomes'),
  requirements: z.array(z.string()).min(1, 'Please add at least 1 requirement'),
  tags: z.array(z.string()),
});

type BasicForm = z.infer<typeof basicSchema>;

export default function CreateCoursePage() {
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [saving, setSaving] = useState(false);
  const [courseId, setCourseId] = useState<string | null>(null);
  const [thumbnail, setThumbnail] = useState<string | null>(null);
  const [sections, setSections] = useState<Section[]>([
    { id: '1', title: 'Getting Started', expanded: true, lessons: [] },
  ]);
  const [outcomeInput, setOutcomeInput] = useState('');
  const [requirementInput, setRequirementInput] = useState('');
  const [tagInput, setTagInput] = useState('');
  const [price, setPrice] = useState('');
  const [isFree, setIsFree] = useState(false);
  const [discountPrice, setDiscountPrice] = useState('');

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    getValues,
    formState: { errors },
  } = useForm<BasicForm>({
    resolver: zodResolver(basicSchema),
    defaultValues: {
      level: 'ALL_LEVELS',
      language: 'English',
      outcomes: [],
      requirements: [],
      tags: [],
    },
  });

  const outcomes = watch('outcomes');
  const requirements = watch('requirements');
  const tags = watch('tags');

  const addItem = (field: 'outcomes' | 'requirements' | 'tags', value: string, setter: (v: string) => void) => {
    if (!value.trim()) return;
    const current = getValues(field);
    setValue(field, [...current, value.trim()]);
    setter('');
  };

  const removeItem = (field: 'outcomes' | 'requirements' | 'tags', index: number) => {
    const current = getValues(field);
    setValue(field, current.filter((_, i) => i !== index));
  };

  // Section management
  const addSection = () => {
    setSections((prev) => [
      ...prev,
      { id: Date.now().toString(), title: 'New Section', expanded: true, lessons: [] },
    ]);
  };

  const updateSection = (id: string, title: string) => {
    setSections((prev) => prev.map((s) => s.id === id ? { ...s, title } : s));
  };

  const toggleSection = (id: string) => {
    setSections((prev) => prev.map((s) => s.id === id ? { ...s, expanded: !s.expanded } : s));
  };

  const removeSection = (id: string) => {
    if (sections.length === 1) { toast.error('A course must have at least one section'); return; }
    setSections((prev) => prev.filter((s) => s.id !== id));
  };

  const addLesson = (sectionId: string, type: string) => {
    setSections((prev) => prev.map((s) =>
      s.id === sectionId
        ? { ...s, lessons: [...s.lessons, { id: Date.now().toString(), title: `New ${type.toLowerCase()} lesson`, type }] }
        : s
    ));
  };

  const updateLesson = (sectionId: string, lessonId: string, title: string) => {
    setSections((prev) => prev.map((s) =>
      s.id === sectionId
        ? { ...s, lessons: s.lessons.map((l) => l.id === lessonId ? { ...l, title } : l) }
        : s
    ));
  };

  const removeLesson = (sectionId: string, lessonId: string) => {
    setSections((prev) => prev.map((s) =>
      s.id === sectionId ? { ...s, lessons: s.lessons.filter((l) => l.id !== lessonId) } : s
    ));
  };

  const saveDraft = async () => {
    setSaving(true);
    try {
      const formData = getValues();
      const res = await fetch('/api/instructor/courses', {
        method: courseId ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...formData, sections, id: courseId, status: 'DRAFT' }),
      });
      const data = await res.json();
      if (data.id) setCourseId(data.id);
      toast.success('Draft saved!');
    } catch {
      toast.error('Failed to save draft');
    } finally {
      setSaving(false);
    }
  };

  const submitForReview = async () => {
    setSaving(true);
    try {
      await fetch(`/api/instructor/courses/${courseId}/submit`, { method: 'POST' });
      toast.success('Course submitted for review! 🎉');
      router.push('/instructor');
    } catch {
      toast.error('Submission failed');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-card sticky top-0 z-40">
        <div className="container mx-auto px-4 max-w-6xl h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/instructor">
                <ArrowLeft className="w-4 h-4 mr-1" />
                Back
              </Link>
            </Button>
            <Separator orientation="vertical" className="h-5" />
            <h1 className="font-display font-bold">Create New Course</h1>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={saveDraft} disabled={saving}>
              <Save className="w-4 h-4 mr-1.5" />
              {saving ? 'Saving...' : 'Save Draft'}
            </Button>
            {step === STEPS.length - 1 && (
              <Button size="sm" onClick={submitForReview} disabled={saving}>
                <Send className="w-4 h-4 mr-1.5" />
                Submit for Review
              </Button>
            )}
          </div>
        </div>

        {/* Step indicator */}
        <div className="border-t">
          <div className="container mx-auto px-4 max-w-6xl">
            <div className="flex">
              {STEPS.map((s, i) => (
                <button
                  key={s.id}
                  onClick={() => setStep(i)}
                  className={cn(
                    'flex-1 py-3 text-sm font-medium border-b-2 transition-colors',
                    i === step
                      ? 'border-primary text-primary'
                      : i < step
                      ? 'border-primary/30 text-muted-foreground hover:text-foreground'
                      : 'border-transparent text-muted-foreground hover:text-foreground'
                  )}
                >
                  <span className="hidden sm:inline">{i + 1}. </span>{s.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 max-w-4xl py-8">
        {/* STEP 0: Course Info */}
        {step === 0 && (
          <div className="space-y-8">
            <div>
              <h2 className="text-xl font-display font-bold mb-1">Course Information</h2>
              <p className="text-sm text-muted-foreground">Set the stage for what students will learn</p>
            </div>

            {/* Thumbnail upload */}
            <div className="space-y-2">
              <Label>Course Thumbnail</Label>
              <div
                className={cn(
                  'border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-colors hover:border-primary/50 hover:bg-primary/5',
                  thumbnail ? 'border-primary/40' : 'border-border'
                )}
                onClick={() => document.getElementById('thumbnail-upload')?.click()}
              >
                {thumbnail ? (
                  <div className="relative w-full aspect-video max-w-xs mx-auto rounded-lg overflow-hidden">
                    <img src={thumbnail} alt="Thumbnail" className="w-full h-full object-cover" />
                  </div>
                ) : (
                  <div>
                    <Upload className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                    <p className="text-sm font-medium">Click to upload thumbnail</p>
                    <p className="text-xs text-muted-foreground mt-1">PNG, JPG up to 10MB. 1280×720 recommended.</p>
                  </div>
                )}
              </div>
              <input
                id="thumbnail-upload"
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) setThumbnail(URL.createObjectURL(file));
                }}
              />
            </div>

            {/* Title */}
            <div className="space-y-2">
              <Label htmlFor="title">Course Title <span className="text-destructive">*</span></Label>
              <Input
                id="title"
                placeholder="e.g., The Complete React Developer Course"
                {...register('title')}
                className="h-11"
              />
              {errors.title && <p className="text-xs text-destructive">{errors.title.message}</p>}
              <p className="text-xs text-muted-foreground">Your title should be compelling and keyword-rich</p>
            </div>

            {/* Short description */}
            <div className="space-y-2">
              <Label htmlFor="shortDescription">Short Description <span className="text-destructive">*</span></Label>
              <textarea
                id="shortDescription"
                placeholder="In 1-2 sentences, describe what students will achieve in this course..."
                {...register('shortDescription')}
                className="w-full px-3 py-2.5 text-sm bg-background border rounded-lg outline-none focus:ring-2 ring-primary/30 resize-none h-20"
              />
              {errors.shortDescription && <p className="text-xs text-destructive">{errors.shortDescription.message}</p>}
            </div>

            {/* Full description */}
            <div className="space-y-2">
              <Label>Full Description <span className="text-destructive">*</span></Label>
              <textarea
                placeholder="Provide a detailed overview of your course content, what students will learn, and why they should enroll..."
                {...register('description')}
                className="w-full px-3 py-2.5 text-sm bg-background border rounded-lg outline-none focus:ring-2 ring-primary/30 resize-none h-40"
              />
              {errors.description && <p className="text-xs text-destructive">{errors.description.message}</p>}
            </div>

            {/* Row: Category, Level, Language */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Category <span className="text-destructive">*</span></Label>
                <select
                  {...register('category')}
                  className="w-full px-3 py-2.5 text-sm bg-background border rounded-lg outline-none focus:ring-2 ring-primary/30"
                >
                  <option value="">Select category</option>
                  {['Web Development', 'Data Science', 'AI & ML', 'Business', 'Design', 'Marketing', 'Photography', 'Music'].map((c) => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
                {errors.category && <p className="text-xs text-destructive">{errors.category.message}</p>}
              </div>

              <div className="space-y-2">
                <Label>Level</Label>
                <select
                  {...register('level')}
                  className="w-full px-3 py-2.5 text-sm bg-background border rounded-lg outline-none focus:ring-2 ring-primary/30"
                >
                  <option value="ALL_LEVELS">All Levels</option>
                  <option value="BEGINNER">Beginner</option>
                  <option value="INTERMEDIATE">Intermediate</option>
                  <option value="ADVANCED">Advanced</option>
                </select>
              </div>

              <div className="space-y-2">
                <Label>Language</Label>
                <select
                  {...register('language')}
                  className="w-full px-3 py-2.5 text-sm bg-background border rounded-lg outline-none focus:ring-2 ring-primary/30"
                >
                  {['English', 'Spanish', 'French', 'German', 'Portuguese', 'Hindi', 'Japanese', 'Chinese'].map((l) => (
                    <option key={l}>{l}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Learning outcomes */}
            <div className="space-y-3">
              <div>
                <Label>What students will learn <span className="text-destructive">*</span></Label>
                <p className="text-xs text-muted-foreground mt-0.5">Add at least 4 learning outcomes (displayed as bullets)</p>
              </div>
              <div className="space-y-2">
                {outcomes.map((outcome, i) => (
                  <div key={i} className="flex items-center gap-2 p-2.5 bg-secondary/50 rounded-lg">
                    <div className="w-1.5 h-1.5 bg-primary rounded-full shrink-0" />
                    <span className="flex-1 text-sm">{outcome}</span>
                    <button
                      type="button"
                      onClick={() => removeItem('outcomes', i)}
                      className="text-muted-foreground hover:text-destructive transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
                <div className="flex gap-2">
                  <Input
                    value={outcomeInput}
                    onChange={(e) => setOutcomeInput(e.target.value)}
                    placeholder="Students will be able to..."
                    onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addItem('outcomes', outcomeInput, setOutcomeInput))}
                    className="h-9"
                  />
                  <Button type="button" size="sm" variant="outline" onClick={() => addItem('outcomes', outcomeInput, setOutcomeInput)}>
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Requirements */}
            <div className="space-y-3">
              <div>
                <Label>Requirements <span className="text-destructive">*</span></Label>
                <p className="text-xs text-muted-foreground mt-0.5">What should students know before taking this course?</p>
              </div>
              <div className="space-y-2">
                {requirements.map((req, i) => (
                  <div key={i} className="flex items-center gap-2 p-2.5 bg-secondary/50 rounded-lg">
                    <span className="flex-1 text-sm">{req}</span>
                    <button type="button" onClick={() => removeItem('requirements', i)} className="text-muted-foreground hover:text-destructive transition-colors">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
                <div className="flex gap-2">
                  <Input
                    value={requirementInput}
                    onChange={(e) => setRequirementInput(e.target.value)}
                    placeholder="e.g., Basic JavaScript knowledge"
                    onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addItem('requirements', requirementInput, setRequirementInput))}
                    className="h-9"
                  />
                  <Button type="button" size="sm" variant="outline" onClick={() => addItem('requirements', requirementInput, setRequirementInput)}>
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Tags */}
            <div className="space-y-3">
              <Label>Tags</Label>
              <div className="flex flex-wrap gap-2 mb-2">
                {tags.map((tag, i) => (
                  <Badge key={i} variant="secondary" className="gap-1.5 pl-3">
                    {tag}
                    <button type="button" onClick={() => removeItem('tags', i)} className="hover:text-destructive">
                      <Trash2 className="w-2.5 h-2.5" />
                    </button>
                  </Badge>
                ))}
              </div>
              <div className="flex gap-2">
                <Input
                  value={tagInput}
                  onChange={(e) => setTagInput(e.target.value)}
                  placeholder="Add a tag (e.g., React, JavaScript)"
                  onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addItem('tags', tagInput, setTagInput))}
                  className="h-9"
                />
                <Button type="button" size="sm" variant="outline" onClick={() => addItem('tags', tagInput, setTagInput)}>
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <Button type="button" onClick={() => setStep(1)} className="w-full">
              Continue to Curriculum
            </Button>
          </div>
        )}

        {/* STEP 1: Curriculum */}
        {step === 1 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-display font-bold mb-1">Course Curriculum</h2>
              <p className="text-sm text-muted-foreground">
                Build your course structure with sections and lessons
              </p>
            </div>

            <div className="space-y-4">
              {sections.map((section, si) => (
                <div key={section.id} className="border rounded-xl overflow-hidden">
                  {/* Section header */}
                  <div className="flex items-center gap-3 p-4 bg-secondary/30">
                    <GripVertical className="w-4 h-4 text-muted-foreground cursor-grab" />
                    <span className="text-xs font-semibold text-muted-foreground shrink-0">
                      Section {si + 1}
                    </span>
                    <input
                      value={section.title}
                      onChange={(e) => updateSection(section.id, e.target.value)}
                      className="flex-1 bg-transparent text-sm font-medium outline-none border-b border-transparent focus:border-primary/40 transition-colors"
                      placeholder="Section title"
                    />
                    <div className="flex items-center gap-1">
                      <span className="text-xs text-muted-foreground">{section.lessons.length} lessons</span>
                      <button
                        onClick={() => toggleSection(section.id)}
                        className="p-1 text-muted-foreground hover:text-foreground"
                      >
                        {section.expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </button>
                      <button
                        onClick={() => removeSection(section.id)}
                        className="p-1 text-muted-foreground hover:text-destructive"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Lessons */}
                  {section.expanded && (
                    <div className="p-4 space-y-2">
                      {section.lessons.map((lesson) => {
                        const lessonType = LESSON_TYPES.find((t) => t.type === lesson.type);
                        return (
                          <div key={lesson.id} className="flex items-center gap-3 p-3 bg-background border rounded-lg">
                            <GripVertical className="w-3.5 h-3.5 text-muted-foreground cursor-grab" />
                            {lessonType && <lessonType.icon className={cn('w-4 h-4 shrink-0', lessonType.color)} />}
                            <input
                              value={lesson.title}
                              onChange={(e) => updateLesson(section.id, lesson.id, e.target.value)}
                              className="flex-1 text-sm bg-transparent outline-none"
                              placeholder="Lesson title"
                            />
                            <Badge variant="outline" className="text-xs shrink-0">{lesson.type}</Badge>
                            <button
                              onClick={() => removeLesson(section.id, lesson.id)}
                              className="text-muted-foreground hover:text-destructive transition-colors"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        );
                      })}

                      {/* Add lesson */}
                      <div className="flex flex-wrap gap-2 pt-1">
                        {LESSON_TYPES.map((type) => (
                          <button
                            key={type.type}
                            onClick={() => addLesson(section.id, type.type)}
                            className={cn(
                              'flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-lg border border-dashed transition-colors hover:bg-secondary',
                              'text-muted-foreground hover:text-foreground'
                            )}
                          >
                            <type.icon className={cn('w-3.5 h-3.5', type.color)} />
                            + {type.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>

            <Button type="button" variant="outline" onClick={addSection} className="w-full gap-2">
              <Plus className="w-4 h-4" />
              Add Section
            </Button>

            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setStep(0)} className="flex-1">Back</Button>
              <Button onClick={() => setStep(2)} className="flex-1">Continue to Pricing</Button>
            </div>
          </div>
        )}

        {/* STEP 2: Pricing */}
        {step === 2 && (
          <div className="space-y-8">
            <div>
              <h2 className="text-xl font-display font-bold mb-1">Course Pricing</h2>
              <p className="text-sm text-muted-foreground">Set the price for your course</p>
            </div>

            <div className="grid gap-6">
              {/* Free toggle */}
              <div className="flex items-center justify-between p-4 border rounded-xl">
                <div>
                  <p className="font-medium">Free Course</p>
                  <p className="text-sm text-muted-foreground">Make this course free for all students</p>
                </div>
                <button
                  onClick={() => setIsFree(!isFree)}
                  className={cn(
                    'w-12 h-6 rounded-full transition-colors relative',
                    isFree ? 'bg-primary' : 'bg-secondary'
                  )}
                >
                  <span className={cn(
                    'absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform',
                    isFree ? 'translate-x-6' : 'translate-x-0.5'
                  )} />
                </button>
              </div>

              {!isFree && (
                <>
                  <div className="space-y-2">
                    <Label>Course Price (USD)</Label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                      <Input
                        type="number"
                        value={price}
                        onChange={(e) => setPrice(e.target.value)}
                        placeholder="0.00"
                        className="pl-7 h-11"
                        min="0"
                        step="0.01"
                      />
                    </div>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {[9.99, 14.99, 19.99, 29.99, 49.99, 89.99, 119.99, 199.99].map((p) => (
                        <button
                          key={p}
                          type="button"
                          onClick={() => setPrice(String(p))}
                          className={cn(
                            'px-3 py-1 text-xs rounded-lg border transition-colors',
                            price === String(p)
                              ? 'border-primary bg-primary/10 text-primary'
                              : 'border-border hover:bg-secondary'
                          )}
                        >
                          ${p}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Promotional Price (Optional)</Label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                      <Input
                        type="number"
                        value={discountPrice}
                        onChange={(e) => setDiscountPrice(e.target.value)}
                        placeholder="0.00"
                        className="pl-7 h-11"
                      />
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Set a lower promotional price. You can run promotions from your instructor dashboard.
                    </p>
                  </div>
                </>
              )}

              {/* Certificate toggle */}
              <div className="flex items-start gap-4 p-4 bg-primary/5 border border-primary/20 rounded-xl">
                <div className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center shrink-0">
                  <BookOpen className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="font-medium">Certificate of Completion</p>
                  <p className="text-sm text-muted-foreground mt-0.5">
                    Students who complete this course will automatically receive a verified certificate. This increases course value and completion rates.
                  </p>
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setStep(1)} className="flex-1">Back</Button>
              <Button onClick={() => setStep(3)} className="flex-1">Continue to Publish</Button>
            </div>
          </div>
        )}

        {/* STEP 3: Publish */}
        {step === 3 && (
          <div className="space-y-8">
            <div>
              <h2 className="text-xl font-display font-bold mb-1">Ready to Publish?</h2>
              <p className="text-sm text-muted-foreground">Review your course before submitting for review</p>
            </div>

            <div className="space-y-4">
              {[
                { label: 'Course title set', ok: true },
                { label: 'Thumbnail uploaded', ok: !!thumbnail },
                { label: 'Description written', ok: true },
                { label: 'Learning outcomes added (4+)', ok: outcomes.length >= 4 },
                { label: 'Curriculum created (1+ section)', ok: sections.length >= 1 },
                { label: 'Lessons added', ok: sections.some((s) => s.lessons.length > 0) },
                { label: 'Pricing configured', ok: isFree || !!price },
              ].map((item) => (
                <div key={item.label} className="flex items-center gap-3 p-3 rounded-lg bg-secondary/30">
                  <div className={cn(
                    'w-5 h-5 rounded-full flex items-center justify-center shrink-0',
                    item.ok ? 'bg-primary/20 text-primary' : 'bg-muted text-muted-foreground'
                  )}>
                    {item.ok ? (
                      <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                      </svg>
                    ) : (
                      <AlertCircle className="w-3 h-3" />
                    )}
                  </div>
                  <span className={cn('text-sm', item.ok ? 'text-foreground' : 'text-muted-foreground')}>
                    {item.label}
                  </span>
                  {!item.ok && (
                    <Badge variant="outline" className="ml-auto text-xs text-amber-500 border-amber-500/30">
                      Required
                    </Badge>
                  )}
                </div>
              ))}
            </div>

            <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-4 text-sm text-muted-foreground">
              <p className="font-medium text-foreground mb-1">📋 Review Process</p>
              <p>Once submitted, our team will review your course within 1-3 business days. You&apos;ll receive an email notification when it&apos;s approved or if changes are needed.</p>
            </div>

            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setStep(2)} className="flex-1">Back</Button>
              <Button
                onClick={submitForReview}
                disabled={saving || !thumbnail || outcomes.length < 4}
                className="flex-1 gap-2"
              >
                <Send className="w-4 h-4" />
                {saving ? 'Submitting...' : 'Submit for Review'}
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
