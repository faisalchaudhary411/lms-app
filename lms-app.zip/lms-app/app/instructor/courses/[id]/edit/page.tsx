'use client';

import { useState } from 'react';
import Link from 'next/link';
import { ArrowLeft, Save, Eye, Video, FileText, HelpCircle, Upload, Trash2, Plus, GripVertical, ChevronDown, ChevronUp } from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';
import toast from 'react-hot-toast';

const LESSON_ICONS: Record<string, any> = { VIDEO: Video, READING: FileText, QUIZ: HelpCircle };
const LESSON_COLORS: Record<string, string> = { VIDEO: 'text-blue-500', READING: 'text-primary', QUIZ: 'text-amber-500' };

const INITIAL_SECTIONS = [
  {
    id: 's1', title: 'Getting Started', expanded: true,
    lessons: [
      { id: 'l1', title: 'Course Introduction', type: 'VIDEO', uploaded: true },
      { id: 'l2', title: 'Setting Up Your Environment', type: 'VIDEO', uploaded: true },
    ],
  },
  {
    id: 's2', title: 'React Fundamentals', expanded: true,
    lessons: [
      { id: 'l3', title: 'Understanding JSX', type: 'VIDEO', uploaded: false },
      { id: 'l4', title: 'Props & State', type: 'VIDEO', uploaded: false },
      { id: 'l5', title: 'Fundamentals Quiz', type: 'QUIZ', uploaded: false },
    ],
  },
];

export default function EditCoursePage({ params }: { params: { id: string } }) {
  const [saving, setSaving] = useState(false);
  const [sections, setSections] = useState(INITIAL_SECTIONS);
  const [activeTab, setActiveTab] = useState<'content' | 'settings' | 'pricing'>('content');

  const TABS = [
    { id: 'content', label: 'Content' },
    { id: 'settings', label: 'Settings' },
    { id: 'pricing', label: 'Pricing' },
  ] as const;

  const addLesson = (sectionId: string, type: string) => {
    setSections((prev) => prev.map((s) =>
      s.id === sectionId
        ? { ...s, lessons: [...s.lessons, { id: Date.now().toString(), title: `New ${type.toLowerCase()}`, type, uploaded: false }] }
        : s
    ));
  };

  const removeLesson = (sectionId: string, lessonId: string) => {
    setSections((prev) => prev.map((s) =>
      s.id === sectionId ? { ...s, lessons: s.lessons.filter((l) => l.id !== lessonId) } : s
    ));
  };

  const toggleSection = (id: string) => {
    setSections((prev) => prev.map((s) => s.id === id ? { ...s, expanded: !s.expanded } : s));
  };

  const updateLesson = (sectionId: string, lessonId: string, title: string) => {
    setSections((prev) => prev.map((s) =>
      s.id === sectionId
        ? { ...s, lessons: s.lessons.map((l) => l.id === lessonId ? { ...l, title } : l) }
        : s
    ));
  };

  const save = async () => {
    setSaving(true);
    await new Promise((r) => setTimeout(r, 800));
    toast.success('Course saved!');
    setSaving(false);
  };

  return (
    <DashboardLayout>
      <div className="space-y-0">
        {/* Sticky top bar */}
        <div className="sticky top-16 z-30 bg-background border-b -mx-6 lg:-mx-8 px-6 lg:px-8 py-3 flex items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" asChild className="gap-1.5">
              <Link href="/instructor"><ArrowLeft className="w-4 h-4" />Back</Link>
            </Button>
            <Separator orientation="vertical" className="h-5" />
            <div className="flex border rounded-xl overflow-hidden">
              {TABS.map((tab) => (
                <button key={tab.id} onClick={() => setActiveTab(tab.id)}
                  className={cn('px-4 py-1.5 text-sm font-medium transition-colors',
                    activeTab === tab.id ? 'bg-primary/10 text-primary' : 'text-muted-foreground hover:text-foreground')}>
                  {tab.label}
                </button>
              ))}
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" asChild className="gap-1.5">
              <Link href="/courses/complete-react-developer" target="_blank">
                <Eye className="w-3.5 h-3.5" />Preview
              </Link>
            </Button>
            <Button size="sm" onClick={save} disabled={saving} className="gap-1.5">
              <Save className="w-3.5 h-3.5" />
              {saving ? 'Saving…' : 'Save'}
            </Button>
          </div>
        </div>

        {/* CONTENT TAB */}
        {activeTab === 'content' && (
          <div className="space-y-4">
            <div>
              <h2 className="text-lg font-display font-bold mb-1">Course Curriculum</h2>
              <p className="text-sm text-muted-foreground">Drag to reorder sections and lessons. Click a lesson to upload content.</p>
            </div>

            {sections.map((section, si) => (
              <div key={section.id} className="border rounded-xl overflow-hidden">
                {/* Section header */}
                <div className="flex items-center gap-3 p-4 bg-secondary/30">
                  <GripVertical className="w-4 h-4 text-muted-foreground cursor-grab" />
                  <span className="text-xs font-semibold text-muted-foreground shrink-0">Section {si + 1}</span>
                  <input
                    value={section.title}
                    onChange={(e) => setSections((prev) => prev.map((s) => s.id === section.id ? { ...s, title: e.target.value } : s))}
                    className="flex-1 bg-transparent text-sm font-semibold outline-none border-b border-transparent focus:border-primary/40"
                  />
                  <div className="flex items-center gap-1 shrink-0">
                    <Badge variant="secondary" className="text-[10px]">{section.lessons.length} lessons</Badge>
                    <button onClick={() => toggleSection(section.id)} className="p-1 text-muted-foreground hover:text-foreground">
                      {section.expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </button>
                    <button
                      onClick={() => setSections((prev) => prev.filter((s) => s.id !== section.id))}
                      className="p-1 text-muted-foreground hover:text-destructive"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {section.expanded && (
                  <div className="p-3 space-y-2">
                    {section.lessons.map((lesson) => {
                      const Icon = LESSON_ICONS[lesson.type] || Video;
                      return (
                        <div key={lesson.id} className="flex items-center gap-3 p-3 bg-background border rounded-lg group">
                          <GripVertical className="w-3.5 h-3.5 text-muted-foreground cursor-grab shrink-0" />
                          <Icon className={cn('w-4 h-4 shrink-0', LESSON_COLORS[lesson.type])} />
                          <input
                            value={lesson.title}
                            onChange={(e) => updateLesson(section.id, lesson.id, e.target.value)}
                            className="flex-1 text-sm bg-transparent outline-none"
                          />
                          <div className="flex items-center gap-2 shrink-0">
                            {lesson.type === 'VIDEO' && (
                              <Button size="sm" variant={lesson.uploaded ? 'outline' : 'default'} className={cn('h-7 px-2 text-xs gap-1', lesson.uploaded && 'text-primary border-primary/30')}>
                                <Upload className="w-3 h-3" />
                                {lesson.uploaded ? 'Uploaded' : 'Upload'}
                              </Button>
                            )}
                            <Badge variant="outline" className="text-[10px]">{lesson.type}</Badge>
                            <button onClick={() => removeLesson(section.id, lesson.id)} className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive transition-all">
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      );
                    })}

                    {/* Add lesson buttons */}
                    <div className="flex flex-wrap gap-2 pt-1">
                      {Object.entries(LESSON_ICONS).map(([type, Icon]) => (
                        <button key={type} onClick={() => addLesson(section.id, type)}
                          className="flex items-center gap-1.5 px-3 py-1.5 text-xs border border-dashed rounded-lg text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                          <Icon className={cn('w-3 h-3', LESSON_COLORS[type])} />
                          + {type.charAt(0) + type.slice(1).toLowerCase()}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}

            <Button variant="outline" className="w-full gap-2"
              onClick={() => setSections((prev) => [...prev, { id: Date.now().toString(), title: 'New Section', expanded: true, lessons: [] }])}>
              <Plus className="w-4 h-4" />Add Section
            </Button>
          </div>
        )}

        {/* SETTINGS TAB */}
        {activeTab === 'settings' && (
          <div className="space-y-6 max-w-2xl">
            <div className="bg-card border rounded-xl p-6 space-y-4">
              <h2 className="font-display font-bold">Basic Information</h2>
              <div className="space-y-2">
                <Label>Course Title</Label>
                <Input defaultValue="The Complete React Developer Course" className="h-11" />
              </div>
              <div className="space-y-2">
                <Label>Short Description</Label>
                <Input defaultValue="Build powerful React apps. Master Hooks, Redux, TypeScript, Testing." className="h-11" />
              </div>
              <div className="space-y-2">
                <Label>Full Description</Label>
                <textarea defaultValue="Become a professional React developer..." className="w-full px-3 py-2.5 text-sm bg-background border rounded-xl outline-none focus:ring-2 ring-primary/30 resize-none h-32" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Category</Label>
                  <select className="w-full px-3 py-2.5 text-sm bg-background border rounded-xl outline-none">
                    <option>Web Development</option><option>Data Science</option><option>Design</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <Label>Level</Label>
                  <select className="w-full px-3 py-2.5 text-sm bg-background border rounded-xl outline-none">
                    <option>BEGINNER</option><option>INTERMEDIATE</option><option>ADVANCED</option><option>ALL_LEVELS</option>
                  </select>
                </div>
              </div>
            </div>
            <Button onClick={save} disabled={saving} className="gap-2">
              <Save className="w-4 h-4" />{saving ? 'Saving…' : 'Save Settings'}
            </Button>
          </div>
        )}

        {/* PRICING TAB */}
        {activeTab === 'pricing' && (
          <div className="space-y-5 max-w-md">
            <div className="bg-card border rounded-xl p-6 space-y-4">
              <h2 className="font-display font-bold">Pricing</h2>
              <div className="flex items-center justify-between p-3 bg-secondary/50 rounded-lg">
                <div>
                  <p className="text-sm font-medium">Free Course</p>
                  <p className="text-xs text-muted-foreground">Remove all pricing</p>
                </div>
                <button className="w-10 h-5 bg-secondary border rounded-full relative">
                  <span className="absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full shadow" />
                </button>
              </div>
              <div className="space-y-2">
                <Label>Regular Price (USD)</Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                  <Input defaultValue="89.99" className="pl-7 h-11" type="number" />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Promotional Price (USD)</Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                  <Input defaultValue="14.99" className="pl-7 h-11" type="number" />
                </div>
                <p className="text-xs text-muted-foreground">Sets shown-to-students price. Run timed promotions from the dashboard.</p>
              </div>
            </div>
            <Button onClick={save} disabled={saving} className="gap-2">
              <Save className="w-4 h-4" />{saving ? 'Saving…' : 'Save Pricing'}
            </Button>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
