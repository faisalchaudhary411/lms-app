'use client';

import { useState } from 'react';
import Link from 'next/link';
import {
  AreaChart, Area, BarChart, Bar, LineChart, Line,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend
} from 'recharts';
import {
  Users, DollarSign, Star, Eye, Clock, TrendingUp,
  ArrowLeft, BookOpen, MessageSquare, Award, ChevronDown
} from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

const TS = { background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '12px', fontSize: '12px' };

const REVENUE = [
  { month: 'Jan', revenue: 820, enrollments: 18 },
  { month: 'Feb', revenue: 1240, enrollments: 27 },
  { month: 'Mar', revenue: 980, enrollments: 21 },
  { month: 'Apr', revenue: 1680, enrollments: 36 },
  { month: 'May', revenue: 2100, enrollments: 45 },
  { month: 'Jun', revenue: 1850, enrollments: 40 },
  { month: 'Jul', revenue: 2340, enrollments: 51 },
  { month: 'Aug', revenue: 2780, enrollments: 60 },
  { month: 'Sep', revenue: 3100, enrollments: 67 },
  { month: 'Oct', revenue: 2900, enrollments: 63 },
  { month: 'Nov', revenue: 3480, enrollments: 75 },
  { month: 'Dec', revenue: 3200, enrollments: 69 },
];

const DROP_OFF = [
  { section: 'S1: Basics', completions: 100 },
  { section: 'S2: Components', completions: 87 },
  { section: 'S3: State', completions: 79 },
  { section: 'S4: Effects', completions: 68 },
  { section: 'S5: Context', completions: 58 },
  { section: 'S6: Redux', completions: 47 },
  { section: 'S7: Router', completions: 42 },
  { section: 'S8: Testing', completions: 35 },
];

const DEVICE_DATA = [
  { name: 'Desktop', value: 52, color: '#22c55e' },
  { name: 'Mobile', value: 31, color: '#3b82f6' },
  { name: 'Tablet', value: 17, color: '#f59e0b' },
];

const COUNTRY_DATA = [
  { country: '🇺🇸 USA', students: 1842, pct: 37 },
  { country: '🇮🇳 India', students: 1124, pct: 23 },
  { country: '🇬🇧 UK', students: 542, pct: 11 },
  { country: '🇩🇪 Germany', students: 387, pct: 8 },
  { country: '🇧🇷 Brazil', students: 298, pct: 6 },
  { country: '🇨🇦 Canada', students: 247, pct: 5 },
];

const RATING_DIST = [
  { stars: '5★', count: 892, pct: 72 },
  { stars: '4★', count: 198, pct: 16 },
  { stars: '3★', count: 74, pct: 6 },
  { stars: '2★', count: 37, pct: 3 },
  { stars: '1★', count: 37, pct: 3 },
];

export default function InstructorAnalyticsPage({ params }: { params: { id: string } }) {
  const [period, setPeriod] = useState<'3m' | '6m' | '12m'>('12m');

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex items-start justify-between gap-4">
          <div>
            <Button variant="ghost" size="sm" asChild className="mb-3 -ml-2 gap-1.5">
              <Link href="/instructor"><ArrowLeft className="w-4 h-4" />Back to Hub</Link>
            </Button>
            <h1 className="text-2xl font-display font-bold">Course Analytics</h1>
            <p className="text-muted-foreground mt-1">The Complete React Developer Course</p>
          </div>
          <div className="flex items-center gap-1 bg-secondary rounded-xl p-1">
            {(['3m', '6m', '12m'] as const).map((p) => (
              <button key={p} onClick={() => setPeriod(p)}
                className={cn('px-3 py-1.5 text-xs font-medium rounded-lg transition-all',
                  period === p ? 'bg-card shadow-sm text-foreground' : 'text-muted-foreground hover:text-foreground')}>
                {p}
              </button>
            ))}
          </div>
        </div>

        {/* KPI cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { label: 'Total Revenue', value: '$24,850', delta: '+18.2%', icon: DollarSign, color: 'text-primary', bg: 'bg-primary/10' },
            { label: 'Total Students', value: '4,923', delta: '+124 this month', icon: Users, color: 'text-blue-500', bg: 'bg-blue-500/10' },
            { label: 'Avg Rating', value: '4.8 / 5', delta: '1,238 reviews', icon: Star, color: 'text-amber-500', bg: 'bg-amber-500/10' },
            { label: 'Completion Rate', value: '71%', delta: '+3% vs avg', icon: Award, color: 'text-violet-500', bg: 'bg-violet-500/10' },
          ].map((s) => (
            <div key={s.label} className="bg-card border rounded-xl p-5">
              <div className={cn('w-9 h-9 rounded-lg flex items-center justify-center mb-3', s.bg)}>
                <s.icon className={cn('w-4 h-4', s.color)} />
              </div>
              <div className="text-2xl font-display font-bold">{s.value}</div>
              <div className="text-xs text-muted-foreground mt-0.5">{s.label}</div>
              <div className={cn('text-xs mt-1 font-medium', s.color)}>{s.delta}</div>
            </div>
          ))}
        </div>

        {/* Revenue + Enrollments chart */}
        <div className="bg-card border rounded-xl p-6">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 className="font-display font-bold">Revenue & Enrollments</h3>
              <p className="text-sm text-muted-foreground mt-0.5">Monthly breakdown</p>
            </div>
            <div className="text-right">
              <p className="text-xl font-bold">$24,850</p>
              <p className="text-xs text-primary flex items-center gap-1 justify-end">
                <TrendingUp className="w-3 h-3" />+18.2% YoY
              </p>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={240}>
            <AreaChart data={REVENUE} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(142,71%,45%)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="hsl(142,71%,45%)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} tickFormatter={(v) => `$${v >= 1000 ? `${v / 1000}k` : v}`} />
              <Tooltip contentStyle={TS} formatter={(v: any, n) => [n === 'revenue' ? `$${v}` : v, n === 'revenue' ? 'Revenue' : 'Enrollments']} />
              <Area type="monotone" dataKey="revenue" stroke="hsl(142,71%,45%)" strokeWidth={2.5} fill="url(#revGrad)" dot={false} activeDot={{ r: 5 }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Two column row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Completion funnel */}
          <div className="bg-card border rounded-xl p-6">
            <h3 className="font-display font-bold mb-1">Completion Funnel</h3>
            <p className="text-sm text-muted-foreground mb-4">Section-by-section drop-off rate</p>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={DROP_OFF} layout="vertical" margin={{ top: 0, right: 30, left: 0, bottom: 0 }}>
                <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v}%`} />
                <YAxis type="category" dataKey="section" tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} width={100} />
                <Tooltip contentStyle={TS} formatter={(v: any) => [`${v}%`, 'Students completing']} />
                <Bar dataKey="completions" radius={[0, 4, 4, 0]}>
                  {DROP_OFF.map((entry, i) => (
                    <Cell key={i} fill={`hsl(142,71%,${35 + (i * 2)}%)`} opacity={1 - i * 0.07} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Device breakdown */}
          <div className="bg-card border rounded-xl p-6">
            <h3 className="font-display font-bold mb-1">Device Breakdown</h3>
            <p className="text-sm text-muted-foreground mb-4">How students access your course</p>
            <div className="flex items-center gap-8">
              <ResponsiveContainer width={160} height={160}>
                <PieChart>
                  <Pie data={DEVICE_DATA} cx="50%" cy="50%" innerRadius={48} outerRadius={72} paddingAngle={4} dataKey="value">
                    {DEVICE_DATA.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                  </Pie>
                  <Tooltip contentStyle={TS} formatter={(v: any) => [`${v}%`, '']} />
                </PieChart>
              </ResponsiveContainer>
              <div className="flex-1 space-y-3">
                {DEVICE_DATA.map((d) => (
                  <div key={d.name} className="flex items-center gap-3">
                    <div className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: d.color }} />
                    <span className="text-sm flex-1">{d.name}</span>
                    <span className="text-sm font-bold">{d.value}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Geographic distribution */}
        <div className="bg-card border rounded-xl p-6">
          <h3 className="font-display font-bold mb-5">Top Countries</h3>
          <div className="space-y-3">
            {COUNTRY_DATA.map((c) => (
              <div key={c.country} className="flex items-center gap-4">
                <span className="text-sm w-28 shrink-0">{c.country}</span>
                <div className="flex-1 h-2 bg-secondary rounded-full overflow-hidden">
                  <div className="h-full bg-primary rounded-full" style={{ width: `${c.pct}%` }} />
                </div>
                <div className="flex gap-3 shrink-0 text-xs text-right">
                  <span className="text-muted-foreground w-12">{c.students.toLocaleString()}</span>
                  <span className="font-semibold w-8">{c.pct}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Rating distribution */}
        <div className="bg-card border rounded-xl p-6">
          <div className="flex items-start gap-8">
            <div className="text-center shrink-0">
              <div className="text-5xl font-display font-bold text-amber-400">4.8</div>
              <div className="flex justify-center gap-0.5 mt-1">
                {[...Array(5)].map((_, i) => (
                  <svg key={i} className="w-4 h-4 text-amber-400 fill-amber-400" viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
              <div className="text-xs text-muted-foreground mt-1.5">1,238 ratings</div>
            </div>
            <div className="flex-1 space-y-2">
              {RATING_DIST.map((r) => (
                <div key={r.stars} className="flex items-center gap-3">
                  <span className="text-xs font-medium w-7 shrink-0 text-right">{r.stars}</span>
                  <div className="flex-1 h-2 bg-secondary rounded-full overflow-hidden">
                    <div className="h-full bg-amber-400 rounded-full" style={{ width: `${r.pct}%` }} />
                  </div>
                  <span className="text-xs text-muted-foreground w-6 shrink-0">{r.pct}%</span>
                  <span className="text-xs text-muted-foreground w-10 text-right shrink-0">{r.count}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Watch time heatmap by hour */}
        <div className="bg-card border rounded-xl p-6">
          <h3 className="font-display font-bold mb-1">Peak Learning Hours</h3>
          <p className="text-sm text-muted-foreground mb-5">When students watch your videos (UTC)</p>
          <div className="grid grid-cols-12 gap-1">
            {Array.from({ length: 7 }, (_, day) =>
              Array.from({ length: 24 }, (_, hour) => {
                const intensity = Math.random();
                const bg = intensity > 0.8 ? 'bg-primary' : intensity > 0.6 ? 'bg-primary/60' : intensity > 0.4 ? 'bg-primary/30' : intensity > 0.2 ? 'bg-primary/15' : 'bg-secondary';
                return (
                  <div
                    key={`${day}-${hour}`}
                    className={cn('h-5 rounded-sm', bg)}
                    title={`${['Sun','Mon','Tue','Wed','Thu','Fri','Sat'][day]} ${hour}:00`}
                  />
                );
              })
            ).flat().slice(0, 84)}
          </div>
          <div className="flex items-center justify-between mt-2 text-xs text-muted-foreground">
            <span>12am</span><span>6am</span><span>12pm</span><span>6pm</span><span>11pm</span>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
