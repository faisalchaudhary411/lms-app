import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { redirect } from 'next/navigation';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { InstructorStats } from '@/components/instructor/InstructorStats';
import { RevenueChart } from '@/components/instructor/RevenueChart';
import {
  InstructorCourseList,
  StudentEngagement,
} from '@/components/instructor/InstructorComponents';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { Plus } from 'lucide-react';

export const metadata = { title: 'Instructor Dashboard' };

export default async function InstructorPage() {
  const session = await getServerSession(authOptions);
  if (!session) redirect('/auth/login');
  // In real app, check if user has instructor role

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-display font-bold">Instructor Hub</h1>
            <p className="text-muted-foreground mt-1">Manage your courses and track performance</p>
          </div>
          <Button asChild className="gap-2">
            <Link href="/instructor/courses/create">
              <Plus className="w-4 h-4" />
              Create Course
            </Link>
          </Button>
        </div>

        {/* Stats */}
        <InstructorStats />

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <RevenueChart />
          <StudentEngagement />
        </div>

        {/* Courses */}
        <InstructorCourseList />
      </div>
    </DashboardLayout>
  );
}
