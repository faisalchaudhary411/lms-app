'use client';

import { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { loadStripe } from '@stripe/stripe-js';
import {
  Elements, CardElement, useStripe, useElements
} from '@stripe/react-stripe-js';
import Image from 'next/image';
import Link from 'next/link';
import {
  Lock, ArrowLeft, CreditCard, Shield, CheckCircle2, Loader2,
  AlertCircle, ChevronDown, Tag
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';
import toast from 'react-hot-toast';

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY || '');

// Mock course data
const MOCK_COURSE = {
  id: '1',
  title: 'The Complete React Developer Course',
  instructor: 'Andrew Mead',
  thumbnail: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=200&h=120&fit=crop',
  price: 89.99,
  discountPrice: 14.99,
  durationMinutes: 4380,
};

function CheckoutForm({ course, couponCode }: { course: typeof MOCK_COURSE; couponCode: string }) {
  const stripe = useStripe();
  const elements = useElements();
  const router = useRouter();
  const [processing, setProcessing] = useState(false);
  const [cardError, setCardError] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'paypal'>('card');

  const price = course.discountPrice || course.price;
  const tax = price * 0.08;
  const total = price + tax;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!stripe || !elements) return;

    setProcessing(true);
    setCardError('');

    try {
      // 1. Create payment intent on server
      const res = await fetch('/api/payments/create-intent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ courseId: course.id, couponCode }),
      });
      const { clientSecret } = await res.json();

      // 2. Confirm payment
      const { error, paymentIntent } = await stripe.confirmCardPayment(clientSecret, {
        payment_method: {
          card: elements.getElement(CardElement)!,
        },
      });

      if (error) {
        setCardError(error.message || 'Payment failed');
        toast.error(error.message || 'Payment failed');
      } else if (paymentIntent.status === 'succeeded') {
        // 3. Confirm order on server
        await fetch('/api/orders/confirm', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ paymentIntentId: paymentIntent.id, courseId: course.id }),
        });
        toast.success('Payment successful! Enrolling you now...');
        router.push(`/learn/${course.id}?enrolled=true`);
      }
    } catch {
      toast.error('Something went wrong. Please try again.');
    } finally {
      setProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Payment methods */}
      <div>
        <label className="text-sm font-semibold mb-3 block">Payment Method</label>
        <div className="grid grid-cols-2 gap-3">
          {[
            { id: 'card', label: 'Credit/Debit Card', icon: CreditCard },
            { id: 'paypal', label: 'PayPal', icon: null },
          ].map((method) => (
            <button
              key={method.id}
              type="button"
              onClick={() => setPaymentMethod(method.id as 'card' | 'paypal')}
              className={cn(
                'flex items-center justify-center gap-2 p-3 border-2 rounded-xl text-sm font-medium transition-all',
                paymentMethod === method.id
                  ? 'border-primary bg-primary/5 text-primary'
                  : 'border-border hover:border-primary/40'
              )}
            >
              {method.icon && <method.icon className="w-4 h-4" />}
              {!method.icon && (
                <svg className="w-14 h-4" viewBox="0 0 60 16" fill="none">
                  <text y="12" fontSize="12" fill="currentColor" fontWeight="bold">PayPal</text>
                </svg>
              )}
              {method.icon && method.label}
            </button>
          ))}
        </div>
      </div>

      {/* Card details */}
      {paymentMethod === 'card' && (
        <div className="space-y-3">
          <div className="space-y-2">
            <label className="text-sm font-medium">Name on Card</label>
            <Input placeholder="John Doe" className="h-11" />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Card Details</label>
            <div className="border rounded-xl px-4 py-3.5 bg-background focus-within:ring-2 ring-primary/30">
              <CardElement
                options={{
                  style: {
                    base: {
                      fontSize: '14px',
                      color: 'hsl(var(--foreground))',
                      '::placeholder': { color: 'hsl(var(--muted-foreground))' },
                    },
                    invalid: { color: 'hsl(var(--destructive))' },
                  },
                }}
                onChange={(e) => setCardError(e.error?.message || '')}
              />
            </div>
            {cardError && (
              <p className="text-xs text-destructive flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                {cardError}
              </p>
            )}
          </div>
        </div>
      )}

      {/* Order summary */}
      <div className="bg-secondary/50 rounded-xl p-4 space-y-2 text-sm">
        <div className="flex justify-between">
          <span className="text-muted-foreground">Original price</span>
          <span className="line-through text-muted-foreground">${course.price.toFixed(2)}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-muted-foreground">Discount</span>
          <span className="text-primary">-${(course.price - price).toFixed(2)}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-muted-foreground">Tax (8%)</span>
          <span>${tax.toFixed(2)}</span>
        </div>
        <Separator />
        <div className="flex justify-between font-bold text-base">
          <span>Total</span>
          <span>${total.toFixed(2)}</span>
        </div>
      </div>

      <Button
        type="submit"
        size="lg"
        className="w-full gap-2 text-base h-12"
        disabled={!stripe || processing}
      >
        {processing ? (
          <Loader2 className="w-5 h-5 animate-spin" />
        ) : (
          <Lock className="w-4 h-4" />
        )}
        {processing ? 'Processing...' : `Complete Purchase · $${total.toFixed(2)}`}
      </Button>

      <div className="flex items-center justify-center gap-6 text-xs text-muted-foreground">
        <div className="flex items-center gap-1">
          <Shield className="w-3.5 h-3.5" />
          SSL Secured
        </div>
        <div className="flex items-center gap-1">
          <CheckCircle2 className="w-3.5 h-3.5" />
          30-day guarantee
        </div>
        <div className="flex items-center gap-1">
          <Lock className="w-3.5 h-3.5" />
          Encrypted
        </div>
      </div>
    </form>
  );
}

export default function CheckoutPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const courseId = searchParams.get('courseId');
  const couponParam = searchParams.get('coupon') || '';
  const [couponCode, setCouponCode] = useState(couponParam);
  const [couponInput, setCouponInput] = useState('');
  const [showCoupon, setShowCoupon] = useState(false);

  const course = MOCK_COURSE; // In real app, fetch by courseId

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 max-w-5xl h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-7 h-7 bg-primary rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-xs">LF</span>
            </div>
            <span className="font-display font-bold">LearnForge</span>
          </Link>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Lock className="w-3.5 h-3.5" />
            Secure checkout
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 max-w-5xl py-10">
        <Button variant="ghost" size="sm" className="mb-6 gap-2" onClick={() => router.back()}>
          <ArrowLeft className="w-4 h-4" />
          Back
        </Button>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-10">
          {/* Left: Form */}
          <div className="lg:col-span-3">
            <h1 className="text-2xl font-display font-bold mb-6">Complete your purchase</h1>

            <Elements
              stripe={stripePromise}
              options={{
                appearance: {
                  theme: 'stripe',
                  variables: {
                    colorPrimary: '#22c55e',
                    borderRadius: '12px',
                  },
                },
              }}
            >
              <CheckoutForm course={course} couponCode={couponCode} />
            </Elements>

            <p className="text-xs text-center text-muted-foreground mt-4">
              By completing your purchase you agree to our{' '}
              <Link href="/terms" className="text-primary hover:underline">Terms of Service</Link>
            </p>
          </div>

          {/* Right: Order summary */}
          <div className="lg:col-span-2">
            <div className="bg-card border rounded-2xl p-6 sticky top-6">
              <h2 className="font-display font-bold mb-4">Order Summary</h2>

              {/* Course card */}
              <div className="flex gap-3 mb-4 pb-4 border-b">
                <div className="relative w-24 h-16 rounded-lg overflow-hidden shrink-0 bg-secondary">
                  <Image src={course.thumbnail} alt={course.title} fill className="object-cover" />
                </div>
                <div>
                  <p className="text-sm font-medium line-clamp-2">{course.title}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{course.instructor}</p>
                  <div className="flex items-center gap-1.5 mt-1">
                    <Badge variant="secondary" className="text-[10px]">Bestseller</Badge>
                    <span className="text-[10px] text-muted-foreground">
                      {Math.round(course.durationMinutes / 60)}h total
                    </span>
                  </div>
                </div>
              </div>

              {/* Coupon */}
              <div className="mb-4">
                <button
                  onClick={() => setShowCoupon(!showCoupon)}
                  className="flex items-center gap-2 text-sm text-primary hover:underline"
                >
                  <Tag className="w-3.5 h-3.5" />
                  Apply coupon code
                  <ChevronDown className={cn('w-3.5 h-3.5 transition-transform', showCoupon && 'rotate-180')} />
                </button>
                {showCoupon && (
                  <div className="mt-2 flex gap-2">
                    <Input
                      value={couponInput}
                      onChange={(e) => setCouponInput(e.target.value.toUpperCase())}
                      placeholder="SAVE20"
                      className="h-9 text-sm"
                    />
                    <Button size="sm" variant="outline" onClick={() => {
                      if (couponInput) {
                        setCouponCode(couponInput);
                        toast.success('Coupon applied!');
                      }
                    }}>Apply</Button>
                  </div>
                )}
              </div>

              {/* What's included */}
              <div>
                <p className="text-xs font-semibold text-muted-foreground mb-2">INCLUDED</p>
                <ul className="space-y-1.5">
                  {[
                    'Lifetime access',
                    'Certificate of completion',
                    'Access on all devices',
                    '30-day money-back guarantee',
                  ].map((item) => (
                    <li key={item} className="flex items-center gap-2 text-xs text-muted-foreground">
                      <CheckCircle2 className="w-3.5 h-3.5 text-primary shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
