import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { redirect } from 'next/navigation';
import {
  AdminStats,
  AdminUserTable,
  AdminCourseApprovals,
} from '@/components/admin/AdminComponents';
import {
  AdminRevenueOverview,
  AdminLayout,
} from '@/components/instructor/InstructorComponents';

export const metadata = { title: 'Admin Panel' };

export default async function AdminPage() {
  const session = await getServerSession(authOptions);
  if (!session) redirect('/auth/login');
  // Check admin role in real app

  return (
    <AdminLayout>
      <div className="space-y-8">
        <div>
          <h1 className="text-2xl font-display font-bold">Admin Dashboard</h1>
          <p className="text-muted-foreground mt-1">Platform overview and management</p>
        </div>

        <AdminStats />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <AdminRevenueOverview />
          <AdminCourseApprovals />
        </div>

        <AdminUserTable />
      </div>
    </AdminLayout>
  );
}
