'use client';

import { useState } from 'react';
import { Plus, Edit, Trash2, Search, BookOpen, FolderOpen, Hash } from 'lucide-react';
import { AdminLayout } from '@/components/instructor/InstructorComponents';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import toast from 'react-hot-toast';

const ICONS = ['💻', '📊', '🤖', '🎨', '📸', '🎵', '📣', '☁️', '📱', '🔒', '💼', '🌐', '⚙️', '🎯', '📚'];

const INITIAL_CATEGORIES = [
  { id: '1', name: 'Web Development', slug: 'web-development', icon: '💻', courseCount: 3420, description: 'HTML, CSS, JavaScript, React, Node.js and more', children: [
    { id: '1a', name: 'Frontend', slug: 'frontend', icon: '🖥️', courseCount: 1240 },
    { id: '1b', name: 'Backend', slug: 'backend', icon: '⚙️', courseCount: 980 },
    { id: '1c', name: 'Full Stack', slug: 'full-stack', icon: '🌐', courseCount: 1200 },
  ]},
  { id: '2', name: 'Data Science', slug: 'data-science', icon: '📊', courseCount: 2180, description: 'Python, R, Machine Learning, Statistics', children: [] },
  { id: '3', name: 'AI & Machine Learning', slug: 'ai-ml', icon: '🤖', courseCount: 1890, description: 'Deep Learning, NLP, Computer Vision', children: [] },
  { id: '4', name: 'UI/UX Design', slug: 'design', icon: '🎨', courseCount: 1560, description: 'Figma, Adobe XD, User Research', children: [] },
  { id: '5', name: 'Business', slug: 'business', icon: '💼', courseCount: 2340, description: 'Entrepreneurship, Management, Strategy', children: [] },
  { id: '6', name: 'Photography', slug: 'photography', icon: '📸', courseCount: 890, description: 'DSLR, Editing, Lightroom, Portraits', children: [] },
  { id: '7', name: 'Music', slug: 'music', icon: '🎵', courseCount: 720, description: 'Guitar, Piano, Music Theory, Production', children: [] },
  { id: '8', name: 'Marketing', slug: 'marketing', icon: '📣', courseCount: 1340, description: 'SEO, Social Media, Email Marketing', children: [] },
];

type Category = typeof INITIAL_CATEGORIES[0];

export default function AdminCategoriesPage() {
  const [categories, setCategories] = useState(INITIAL_CATEGORIES);
  const [search, setSearch] = useState('');
  const [showCreate, setShowCreate] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>('1');
  const [form, setForm] = useState({ name: '', slug: '', icon: '💻', description: '', parentId: '' });

  const filtered = categories.filter((c) =>
    c.name.toLowerCase().includes(search.toLowerCase())
  );

  const slugify = (s: string) =>
    s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');

  const handleCreate = () => {
    if (!form.name.trim()) { toast.error('Name is required'); return; }
    const newCat: Category = {
      id: Date.now().toString(),
      name: form.name,
      slug: form.slug || slugify(form.name),
      icon: form.icon,
      description: form.description,
      courseCount: 0,
      children: [],
    };
    setCategories((prev) => [...prev, newCat]);
    setForm({ name: '', slug: '', icon: '💻', description: '', parentId: '' });
    setShowCreate(false);
    toast.success(`Category "${newCat.name}" created!`);
  };

  const handleDelete = (id: string) => {
    setCategories((prev) => prev.filter((c) => c.id !== id));
    toast.success('Category deleted');
  };

  const totalCourses = categories.reduce((s, c) => s + c.courseCount, 0);

  return (
    <AdminLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-display font-bold">Category Management</h1>
            <p className="text-muted-foreground mt-1">Organise courses into browsable categories</p>
          </div>
          <Button onClick={() => setShowCreate(!showCreate)} className="gap-2">
            <Plus className="w-4 h-4" />New Category
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[
            { label: 'Total Categories', value: categories.length },
            { label: 'Sub-categories', value: categories.reduce((s, c) => s + c.children.length, 0) },
            { label: 'Total Courses', value: totalCourses.toLocaleString() },
            { label: 'Avg per Category', value: Math.round(totalCourses / categories.length) },
          ].map((s) => (
            <div key={s.label} className="bg-card border rounded-xl p-4">
              <div className="text-2xl font-display font-bold">{s.value}</div>
              <div className="text-xs text-muted-foreground mt-0.5">{s.label}</div>
            </div>
          ))}
        </div>

        {/* Create form */}
        {showCreate && (
          <div className="bg-card border rounded-2xl p-6 animate-fade-up">
            <h3 className="font-display font-bold mb-4">Create Category</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Category Name *</Label>
                <Input
                  value={form.name}
                  onChange={(e) => setForm((p) => ({ ...p, name: e.target.value, slug: slugify(e.target.value) }))}
                  placeholder="e.g. Cloud Computing"
                  className="h-10"
                />
              </div>
              <div className="space-y-2">
                <Label>Slug</Label>
                <Input
                  value={form.slug}
                  onChange={(e) => setForm((p) => ({ ...p, slug: e.target.value }))}
                  placeholder="cloud-computing"
                  className="h-10 font-mono text-sm"
                />
              </div>
              <div className="space-y-2">
                <Label>Icon</Label>
                <div className="flex flex-wrap gap-2">
                  {ICONS.map((icon) => (
                    <button
                      key={icon}
                      onClick={() => setForm((p) => ({ ...p, icon }))}
                      className={cn(
                        'w-9 h-9 text-lg rounded-lg border transition-all',
                        form.icon === icon ? 'border-primary bg-primary/10 ring-1 ring-primary' : 'border-border hover:border-primary/40 hover:bg-secondary'
                      )}
                    >
                      {icon}
                    </button>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <Label>Parent Category (optional)</Label>
                <select
                  value={form.parentId}
                  onChange={(e) => setForm((p) => ({ ...p, parentId: e.target.value }))}
                  className="w-full h-10 px-3 text-sm bg-background border rounded-xl outline-none"
                >
                  <option value="">None (top-level)</option>
                  {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div className="space-y-2 sm:col-span-2">
                <Label>Description</Label>
                <Input
                  value={form.description}
                  onChange={(e) => setForm((p) => ({ ...p, description: e.target.value }))}
                  placeholder="Brief description of this category"
                  className="h-10"
                />
              </div>
            </div>
            <div className="flex gap-2 mt-4">
              <Button onClick={handleCreate}>Create Category</Button>
              <Button variant="ghost" onClick={() => setShowCreate(false)}>Cancel</Button>
            </div>
          </div>
        )}

        {/* Search */}
        <div className="relative max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search categories..." className="pl-9 h-9" />
        </div>

        {/* Category list */}
        <div className="space-y-3">
          {filtered.map((cat) => (
            <div key={cat.id} className="bg-card border rounded-2xl overflow-hidden">
              {/* Category row */}
              <div className="flex items-center gap-4 p-4 hover:bg-secondary/20 transition-colors">
                {/* Icon + name */}
                <div
                  className="w-11 h-11 bg-secondary rounded-xl flex items-center justify-center text-xl shrink-0 cursor-pointer hover:bg-secondary/80"
                  onClick={() => setExpandedId(expandedId === cat.id ? null : cat.id)}
                >
                  {cat.icon}
                </div>
                <div className="flex-1 min-w-0" onClick={() => setExpandedId(expandedId === cat.id ? null : cat.id)}>
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold cursor-pointer hover:text-primary transition-colors">{cat.name}</h3>
                    {cat.children.length > 0 && (
                      <Badge variant="secondary" className="text-[10px]">{cat.children.length} sub-cats</Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-3 mt-0.5">
                    <span className="text-xs text-muted-foreground font-mono">/{cat.slug}</span>
                    {cat.description && <span className="text-xs text-muted-foreground hidden sm:block truncate max-w-xs">{cat.description}</span>}
                  </div>
                </div>

                {/* Course count bar */}
                <div className="hidden md:flex items-center gap-2 w-40 shrink-0">
                  <div className="flex-1 h-1.5 bg-secondary rounded-full overflow-hidden">
                    <div className="h-full bg-primary rounded-full" style={{ width: `${Math.min(100, (cat.courseCount / totalCourses) * 300)}%` }} />
                  </div>
                  <span className="text-xs font-medium text-muted-foreground w-16 text-right">
                    {cat.courseCount.toLocaleString()} courses
                  </span>
                </div>

                {/* Actions */}
                <div className="flex gap-1 shrink-0">
                  <Button variant="ghost" size="icon" className="w-8 h-8 text-muted-foreground hover:text-foreground">
                    <Edit className="w-3.5 h-3.5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="w-8 h-8 text-muted-foreground hover:text-destructive" onClick={() => handleDelete(cat.id)}>
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
              </div>

              {/* Sub-categories */}
              {expandedId === cat.id && cat.children.length > 0 && (
                <div className="border-t bg-secondary/10 p-3 pl-8 space-y-2">
                  {cat.children.map((sub) => (
                    <div key={sub.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-secondary/50 transition-colors">
                      <span className="text-base">{sub.icon}</span>
                      <span className="text-sm font-medium flex-1">{sub.name}</span>
                      <span className="text-xs text-muted-foreground font-mono hidden sm:block">/{sub.slug}</span>
                      <span className="text-xs text-muted-foreground">{sub.courseCount.toLocaleString()} courses</span>
                      <Button variant="ghost" size="icon" className="w-7 h-7 text-muted-foreground hover:text-destructive">
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  ))}
                  <button
                    className="flex items-center gap-2 text-xs text-primary hover:underline pl-1 mt-1"
                    onClick={() => {
                      setForm((p) => ({ ...p, parentId: cat.id }));
                      setShowCreate(true);
                    }}
                  >
                    <Plus className="w-3 h-3" />Add sub-category
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </AdminLayout>
  );
}
