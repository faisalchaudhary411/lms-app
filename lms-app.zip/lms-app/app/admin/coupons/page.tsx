'use client';

import { useState } from 'react';
import { Plus, Tag, Trash2, Edit, Copy, Check, Search, Calendar } from 'lucide-react';
import { AdminLayout } from '@/components/instructor/InstructorComponents';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { format, isAfter, isBefore } from 'date-fns';
import toast from 'react-hot-toast';

const MOCK_COUPONS = [
  { id: '1', code: 'WELCOME20', type: 'PERCENTAGE', value: 20, maxUses: 1000, usedCount: 347, validFrom: new Date('2024-01-01'), validTo: new Date('2024-12-31'), isActive: true, courses: [] },
  { id: '2', code: 'SAVE10', type: 'FIXED', value: 10, maxUses: 500, usedCount: 500, validFrom: new Date('2024-03-01'), validTo: new Date('2024-05-31'), isActive: false, courses: ['Complete React Developer'] },
  { id: '3', code: 'FLASHSALE', type: 'PERCENTAGE', value: 50, maxUses: 200, usedCount: 127, validFrom: new Date('2024-05-25'), validTo: new Date('2024-06-01'), isActive: true, courses: [] },
  { id: '4', code: 'NEWUSER15', type: 'PERCENTAGE', value: 15, maxUses: 2000, usedCount: 892, validFrom: new Date('2024-01-01'), validTo: new Date('2024-12-31'), isActive: true, courses: [] },
];

export default function AdminCouponsPage() {
  const [coupons, setCoupons] = useState(MOCK_COUPONS);
  const [search, setSearch] = useState('');
  const [showCreate, setShowCreate] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);
  const [newCoupon, setNewCoupon] = useState({ code: '', type: 'PERCENTAGE', value: '', maxUses: '', validFrom: '', validTo: '' });

  const filtered = coupons.filter((c) => c.code.toLowerCase().includes(search.toLowerCase()));

  const copyCoupon = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopied(code);
    toast.success('Coupon code copied!');
    setTimeout(() => setCopied(null), 2000);
  };

  const toggleActive = (id: string) => {
    setCoupons((prev) => prev.map((c) => c.id === id ? { ...c, isActive: !c.isActive } : c));
  };

  const deleteCoupon = (id: string) => {
    setCoupons((prev) => prev.filter((c) => c.id !== id));
    toast.success('Coupon deleted');
  };

  const createCoupon = () => {
    if (!newCoupon.code || !newCoupon.value) { toast.error('Please fill required fields'); return; }
    setCoupons((prev) => [...prev, {
      id: Date.now().toString(), code: newCoupon.code.toUpperCase(),
      type: newCoupon.type, value: Number(newCoupon.value),
      maxUses: Number(newCoupon.maxUses) || 100, usedCount: 0,
      validFrom: new Date(newCoupon.validFrom || Date.now()),
      validTo: new Date(newCoupon.validTo || Date.now() + 30 * 24 * 60 * 60 * 1000),
      isActive: true, courses: [],
    }]);
    setShowCreate(false);
    setNewCoupon({ code: '', type: 'PERCENTAGE', value: '', maxUses: '', validFrom: '', validTo: '' });
    toast.success('Coupon created!');
  };

  const getCouponStatus = (coupon: (typeof MOCK_COUPONS)[0]) => {
    const now = new Date();
    if (!coupon.isActive) return { label: 'Inactive', cls: 'text-muted-foreground bg-secondary' };
    if (coupon.usedCount >= coupon.maxUses) return { label: 'Used Up', cls: 'text-red-500 bg-red-500/10' };
    if (isAfter(now, coupon.validTo)) return { label: 'Expired', cls: 'text-red-500 bg-red-500/10' };
    if (isBefore(now, coupon.validFrom)) return { label: 'Scheduled', cls: 'text-amber-500 bg-amber-500/10' };
    return { label: 'Active', cls: 'text-primary bg-primary/10' };
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-display font-bold">Coupon Management</h1>
            <p className="text-muted-foreground mt-1">Create and manage discount codes</p>
          </div>
          <Button onClick={() => setShowCreate(!showCreate)} className="gap-2">
            <Plus className="w-4 h-4" />Create Coupon
          </Button>
        </div>

        {/* Create form */}
        {showCreate && (
          <div className="bg-card border rounded-2xl p-6 animate-fade-up">
            <h3 className="font-display font-bold mb-4">New Coupon</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Coupon Code *</Label>
                <Input value={newCoupon.code} onChange={(e) => setNewCoupon((p) => ({ ...p, code: e.target.value.toUpperCase() }))} placeholder="e.g. SAVE20" className="h-10 uppercase" />
              </div>
              <div className="space-y-2">
                <Label>Discount Type</Label>
                <select value={newCoupon.type} onChange={(e) => setNewCoupon((p) => ({ ...p, type: e.target.value }))} className="w-full h-10 px-3 text-sm bg-background border rounded-xl outline-none">
                  <option value="PERCENTAGE">Percentage (%)</option>
                  <option value="FIXED">Fixed ($)</option>
                </select>
              </div>
              <div className="space-y-2">
                <Label>Discount Value *</Label>
                <Input type="number" value={newCoupon.value} onChange={(e) => setNewCoupon((p) => ({ ...p, value: e.target.value }))} placeholder={newCoupon.type === 'PERCENTAGE' ? '20' : '10.00'} className="h-10" />
              </div>
              <div className="space-y-2">
                <Label>Max Uses</Label>
                <Input type="number" value={newCoupon.maxUses} onChange={(e) => setNewCoupon((p) => ({ ...p, maxUses: e.target.value }))} placeholder="100" className="h-10" />
              </div>
              <div className="space-y-2">
                <Label>Valid From</Label>
                <Input type="date" value={newCoupon.validFrom} onChange={(e) => setNewCoupon((p) => ({ ...p, validFrom: e.target.value }))} className="h-10" />
              </div>
              <div className="space-y-2">
                <Label>Valid To</Label>
                <Input type="date" value={newCoupon.validTo} onChange={(e) => setNewCoupon((p) => ({ ...p, validTo: e.target.value }))} className="h-10" />
              </div>
            </div>
            <div className="flex gap-2 mt-4">
              <Button onClick={createCoupon}>Create Coupon</Button>
              <Button variant="ghost" onClick={() => setShowCreate(false)}>Cancel</Button>
            </div>
          </div>
        )}

        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[
            { label: 'Total Coupons', value: coupons.length },
            { label: 'Active', value: coupons.filter((c) => c.isActive).length },
            { label: 'Total Uses', value: coupons.reduce((s, c) => s + c.usedCount, 0).toLocaleString() },
            { label: 'Est. Discount Given', value: '$14,280' },
          ].map((s) => (
            <div key={s.label} className="bg-card border rounded-xl p-4">
              <div className="text-xl font-bold">{s.value}</div>
              <div className="text-xs text-muted-foreground">{s.label}</div>
            </div>
          ))}
        </div>

        {/* Search */}
        <div className="relative max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search coupons..." className="pl-9 h-9" />
        </div>

        {/* Coupons table */}
        <div className="bg-card border rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-secondary/20">
                  <th className="text-left px-5 py-3 text-xs font-semibold text-muted-foreground">Code</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground">Discount</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground">Usage</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground">Validity</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground">Status</th>
                  <th className="px-4 py-3"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/50">
                {filtered.map((coupon) => {
                  const status = getCouponStatus(coupon);
                  const usagePct = Math.min(100, Math.round((coupon.usedCount / coupon.maxUses) * 100));
                  return (
                    <tr key={coupon.id} className="hover:bg-secondary/20 transition-colors">
                      <td className="px-5 py-4">
                        <div className="flex items-center gap-2">
                          <code className="font-mono font-bold text-sm bg-secondary px-2 py-0.5 rounded">{coupon.code}</code>
                          <button onClick={() => copyCoupon(coupon.code)} className="text-muted-foreground hover:text-foreground">
                            {copied === coupon.code ? <Check className="w-3.5 h-3.5 text-primary" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      </td>
                      <td className="px-4 py-4 font-bold text-primary">
                        {coupon.type === 'PERCENTAGE' ? `${coupon.value}%` : `$${coupon.value}`} off
                      </td>
                      <td className="px-4 py-4">
                        <div className="space-y-1.5">
                          <div className="flex justify-between text-xs text-muted-foreground">
                            <span>{coupon.usedCount.toLocaleString()} / {coupon.maxUses.toLocaleString()}</span>
                            <span>{usagePct}%</span>
                          </div>
                          <div className="h-1.5 bg-secondary rounded-full overflow-hidden w-24">
                            <div className={cn('h-full rounded-full', usagePct >= 100 ? 'bg-red-500' : 'bg-primary')} style={{ width: `${usagePct}%` }} />
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-4 text-xs text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {format(coupon.validFrom, 'MMM d')} – {format(coupon.validTo, 'MMM d, yyyy')}
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <Badge className={cn('text-[10px] border-0', status.cls)}>{status.label}</Badge>
                      </td>
                      <td className="px-4 py-4">
                        <div className="flex gap-1">
                          <Button variant="ghost" size="icon" className="w-8 h-8" onClick={() => toggleActive(coupon.id)}>
                            <Tag className="w-3.5 h-3.5" />
                          </Button>
                          <Button variant="ghost" size="icon" className="w-8 h-8 text-destructive hover:text-destructive" onClick={() => deleteCoupon(coupon.id)}>
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
