'use client';

import {
  AreaChart, Area, BarChart, Bar, LineChart, Line,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell
} from 'recharts';
import { DollarSign, Users, BookOpen, TrendingUp, Star, Award, Globe, Zap } from 'lucide-react';
import { AdminLayout } from '@/components/instructor/InstructorComponents';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

const TS = { background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '12px', fontSize: '12px' };

const PLATFORM_REVENUE = Array.from({ length: 12 }, (_, i) => ({
  month: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][i],
  revenue: [84200, 97800, 113400, 142600, 168900, 198400, 221700, 247300, 268900, 245600, 284000, 312400][i],
  instructorPayouts: [42100, 48900, 56700, 71300, 84450, 99200, 110850, 123650, 134450, 122800, 142000, 156200][i],
}));

const USER_GROWTH = Array.from({ length: 12 }, (_, i) => ({
  month: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][i],
  students: [82000, 98000, 118000, 145000, 178000, 215000, 258000, 308000, 362000, 419000, 489000, 568000][i],
  instructors: [6200, 6800, 7400, 8100, 8900, 9700, 10600, 11600, 12700, 13900, 15200, 16700][i],
}));

const CATEGORY_DIST = [
  { name: 'Web Dev', value: 28, color: '#3b82f6' },
  { name: 'Data Science', value: 18, color: '#8b5cf6' },
  { name: 'Business', value: 15, color: '#f59e0b' },
  { name: 'Design', value: 12, color: '#ec4899' },
  { name: 'AI/ML', value: 11, color: '#22c55e' },
  { name: 'Other', value: 16, color: '#6b7280' },
];

const TOP_COURSES = [
  { title: 'Complete JavaScript Course', instructor: 'Colt Steele', revenue: '$284K', students: '178K', rating: 4.9 },
  { title: 'Machine Learning A-Z', instructor: 'Dr. Smith', revenue: '$221K', students: '112K', rating: 4.8 },
  { title: 'Complete React Developer', instructor: 'Andrew Mead', revenue: '$187K', students: '94K', rating: 4.7 },
  { title: 'Python for Data Science', instructor: 'Sarah Johnson', revenue: '$164K', students: '82K', rating: 4.6 },
  { title: 'AWS Cloud Practitioner', instructor: 'Mike Chen', revenue: '$142K', students: '71K', rating: 4.8 },
];

export default function AdminAnalyticsPage() {
  return (
    <AdminLayout>
      <div className="space-y-8">
        <div>
          <h1 className="text-2xl font-display font-bold">Platform Analytics</h1>
          <p className="text-muted-foreground mt-1">Comprehensive platform-wide metrics</p>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { label: 'Annual Revenue', value: '$2.18M', delta: '+27.3%', icon: DollarSign, c: 'text-primary', bg: 'bg-primary/10' },
            { label: 'Total Users', value: '1.24M', delta: '+18.4%', icon: Users, c: 'text-blue-500', bg: 'bg-blue-500/10' },
            { label: 'Active Courses', value: '15,432', delta: '+3.2%', icon: BookOpen, c: 'text-violet-500', bg: 'bg-violet-500/10' },
            { label: 'Certificates Issued', value: '512K', delta: '+41%', icon: Award, c: 'text-amber-500', bg: 'bg-amber-500/10' },
          ].map((s) => (
            <div key={s.label} className="bg-card border rounded-xl p-5">
              <div className={cn('w-9 h-9 rounded-lg flex items-center justify-center mb-3', s.bg)}>
                <s.icon className={cn('w-4 h-4', s.c)} />
              </div>
              <div className="text-2xl font-display font-bold">{s.value}</div>
              <div className="text-xs text-muted-foreground mt-0.5">{s.label}</div>
              <div className={cn('text-xs mt-1 font-medium', s.c)}>{s.delta} YoY</div>
            </div>
          ))}
        </div>

        {/* Revenue chart */}
        <div className="bg-card border rounded-xl p-6">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 className="font-display font-bold">Revenue vs Instructor Payouts</h3>
              <p className="text-sm text-muted-foreground mt-0.5">Platform keeps ~50% revenue share</p>
            </div>
            <Badge className="bg-primary/10 text-primary border-0">2024</Badge>
          </div>
          <ResponsiveContainer width="100%" height={240}>
            <AreaChart data={PLATFORM_REVENUE} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="totalRev" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(142,71%,45%)" stopOpacity={0.3} /><stop offset="95%" stopColor="hsl(142,71%,45%)" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="payoutRev" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(217,91%,60%)" stopOpacity={0.3} /><stop offset="95%" stopColor="hsl(217,91%,60%)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} tickFormatter={(v) => `$${v / 1000}k`} />
              <Tooltip contentStyle={TS} formatter={(v: any) => [`$${(v / 1000).toFixed(1)}k`, '']} />
              <Area name="Total Revenue" type="monotone" dataKey="revenue" stroke="hsl(142,71%,45%)" strokeWidth={2} fill="url(#totalRev)" dot={false} />
              <Area name="Instructor Payouts" type="monotone" dataKey="instructorPayouts" stroke="hsl(217,91%,60%)" strokeWidth={2} fill="url(#payoutRev)" dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* User growth + category split */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-card border rounded-xl p-6">
            <h3 className="font-display font-bold mb-1">User Growth</h3>
            <p className="text-sm text-muted-foreground mb-4">Students & instructors over time</p>
            <ResponsiveContainer width="100%" height={220}>
              <LineChart data={USER_GROWTH} margin={{ top: 0, right: 5, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} tickFormatter={(v) => v >= 1000 ? `${v / 1000}k` : v} />
                <Tooltip contentStyle={TS} formatter={(v: any) => [Number(v).toLocaleString(), '']} />
                <Line name="Students" dataKey="students" stroke="hsl(142,71%,45%)" strokeWidth={2.5} dot={false} />
                <Line name="Instructors" dataKey="instructors" stroke="hsl(217,91%,60%)" strokeWidth={2.5} dot={false} strokeDasharray="4 2" />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="bg-card border rounded-xl p-6">
            <h3 className="font-display font-bold mb-1">Revenue by Category</h3>
            <p className="text-sm text-muted-foreground mb-4">Share of annual revenue per category</p>
            <div className="flex items-center gap-6">
              <ResponsiveContainer width={160} height={160}>
                <PieChart>
                  <Pie data={CATEGORY_DIST} cx="50%" cy="50%" innerRadius={50} outerRadius={72} paddingAngle={3} dataKey="value">
                    {CATEGORY_DIST.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                  </Pie>
                  <Tooltip contentStyle={TS} formatter={(v: any) => [`${v}%`, '']} />
                </PieChart>
              </ResponsiveContainer>
              <div className="flex-1 space-y-2">
                {CATEGORY_DIST.map((d) => (
                  <div key={d.name} className="flex items-center gap-2.5">
                    <div className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: d.color }} />
                    <span className="text-sm flex-1">{d.name}</span>
                    <span className="text-sm font-bold">{d.value}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Top performing courses */}
        <div className="bg-card border rounded-xl overflow-hidden">
          <div className="p-6 border-b">
            <h3 className="font-display font-bold">Top Performing Courses</h3>
            <p className="text-sm text-muted-foreground mt-0.5">Ranked by total revenue</p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-secondary/20">
                  <th className="text-left px-6 py-3 text-xs font-semibold text-muted-foreground">#</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground">Course</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground">Instructor</th>
                  <th className="text-right px-4 py-3 text-xs font-semibold text-muted-foreground">Students</th>
                  <th className="text-right px-4 py-3 text-xs font-semibold text-muted-foreground">Revenue</th>
                  <th className="text-right px-4 py-3 text-xs font-semibold text-muted-foreground">Rating</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/50">
                {TOP_COURSES.map((course, i) => (
                  <tr key={course.title} className="hover:bg-secondary/20 transition-colors">
                    <td className="px-6 py-4 text-muted-foreground font-mono text-xs">{i + 1}</td>
                    <td className="px-4 py-4 font-medium">{course.title}</td>
                    <td className="px-4 py-4 text-muted-foreground">{course.instructor}</td>
                    <td className="px-4 py-4 text-right">{course.students}</td>
                    <td className="px-4 py-4 text-right font-bold text-primary">{course.revenue}</td>
                    <td className="px-4 py-4 text-right">
                      <span className="flex items-center justify-end gap-1 text-amber-500">
                        <svg className="w-3 h-3 fill-amber-500" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" /></svg>
                        {course.rating}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
