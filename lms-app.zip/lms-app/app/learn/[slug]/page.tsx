'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import {
  ChevronLeft, ChevronRight, CheckCircle2, Circle, Play,
  FileText, HelpCircle, BookOpen, Code, ChevronDown,
  ChevronUp, Menu, X, GraduationCap, MessageSquare,
  Download, Wifi, WifiOff
} from 'lucide-react';
import { VideoPlayer } from '@/components/video/VideoPlayer';
import { Quiz } from '@/components/quiz/Quiz';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import toast from 'react-hot-toast';
import Confetti from 'react-confetti';

const LESSON_ICONS: Record<string, any> = {
  VIDEO: Play, READING: FileText, QUIZ: HelpCircle,
  ASSIGNMENT: BookOpen, CODING: Code, LIVE: Wifi,
};

const LESSON_COLORS: Record<string, string> = {
  VIDEO: 'text-blue-500', READING: 'text-emerald-500', QUIZ: 'text-amber-500',
  ASSIGNMENT: 'text-violet-500', CODING: 'text-pink-500', LIVE: 'text-red-500',
};

// Mock course data
const MOCK_LEARN = {
  id: '1', slug: 'complete-react-developer',
  title: 'The Complete React Developer Course',
  totalLessons: 12,
  sections: [
    {
      id: 's1', title: 'Getting Started', expanded: true,
      lessons: [
        { id: 'l1', title: 'Course Introduction', type: 'VIDEO', videoDuration: 180, isCompleted: true, isPreview: true, videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4' },
        { id: 'l2', title: 'Setting Up Your Environment', type: 'VIDEO', videoDuration: 420, isCompleted: true, isPreview: false, videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4' },
        { id: 'l3', title: 'Your First React App', type: 'VIDEO', videoDuration: 840, isCompleted: false, isPreview: false, videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4' },
      ],
    },
    {
      id: 's2', title: 'React Components', expanded: true,
      lessons: [
        { id: 'l4', title: 'Understanding JSX', type: 'VIDEO', videoDuration: 600, isCompleted: false, isPreview: false, videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4' },
        { id: 'l5', title: 'Props & State', type: 'VIDEO', videoDuration: 900, isCompleted: false, isPreview: false, videoUrl: '' },
        { id: 'l6', title: 'Component Quiz', type: 'QUIZ', isCompleted: false, isPreview: false, videoUrl: '' },
        { id: 'l7', title: 'Components Reading', type: 'READING', isCompleted: false, content: '<h2>React Components</h2><p>Components are the building blocks of any React application...</p>', videoUrl: '' },
      ],
    },
    {
      id: 's3', title: 'React Hooks', expanded: false,
      lessons: [
        { id: 'l8', title: 'useState Hook', type: 'VIDEO', videoDuration: 1200, isCompleted: false, isPreview: false, videoUrl: '' },
        { id: 'l9', title: 'useEffect Hook', type: 'VIDEO', videoDuration: 1500, isCompleted: false, isPreview: false, videoUrl: '' },
        { id: 'l10', title: 'Custom Hooks', type: 'VIDEO', videoDuration: 900, isCompleted: false, isPreview: false, videoUrl: '' },
        { id: 'l11', title: 'Hooks Assignment', type: 'ASSIGNMENT', isCompleted: false, isPreview: false, videoUrl: '' },
        { id: 'l12', title: 'Hooks Final Quiz', type: 'QUIZ', isCompleted: false, isPreview: false, videoUrl: '' },
      ],
    },
  ],
};

const MOCK_QUIZ = {
  id: 'q1', title: 'React Components Quiz', passingScore: 70, maxAttempts: 3, attemptNumber: 1,
  timeLimit: 10,
  questions: [
    {
      id: 'q1', text: 'What is JSX in React?', type: 'MCQ' as const, points: 1,
      options: [
        { id: 'a', text: 'A JavaScript XML syntax extension' },
        { id: 'b', text: 'A separate programming language' },
        { id: 'c', text: 'A CSS framework for React' },
        { id: 'd', text: 'A build tool for React' },
      ],
    },
    {
      id: 'q2', text: 'Which of these is a valid React component name?', type: 'MCQ' as const, points: 1,
      options: [
        { id: 'a', text: 'myComponent' },
        { id: 'b', text: 'MyComponent' },
        { id: 'c', text: 'my-component' },
        { id: 'd', text: 'my_component' },
      ],
    },
    {
      id: 'q3', text: 'Props in React are:', type: 'MCQ' as const, points: 1,
      options: [
        { id: 'a', text: 'Mutable state values' },
        { id: 'b', text: 'Read-only inputs passed to components' },
        { id: 'c', text: 'CSS class names' },
        { id: 'd', text: 'Event handlers' },
      ],
    },
  ],
};

export default function LearnPage({ params }: { params: { slug: string } }) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [course] = useState(MOCK_LEARN);
  const [sections, setSections] = useState(course.sections);
  const [currentLessonId, setCurrentLessonId] = useState(
    searchParams.get('lesson') || 'l3'
  );
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [completedLessons, setCompletedLessons] = useState<Set<string>>(
    new Set(['l1', 'l2'])
  );
  const [showConfetti, setShowConfetti] = useState(false);

  const allLessons = sections.flatMap((s) => s.lessons);
  const currentLesson = allLessons.find((l) => l.id === currentLessonId) || allLessons[0];
  const currentIndex = allLessons.findIndex((l) => l.id === currentLessonId);
  const prevLesson = allLessons[currentIndex - 1];
  const nextLesson = allLessons[currentIndex + 1];
  const progress = Math.round((completedLessons.size / allLessons.length) * 100);

  const markComplete = async (lessonId: string) => {
    if (completedLessons.has(lessonId)) return;
    setCompletedLessons((prev) => new Set([...prev, lessonId]));
    try {
      await fetch('/api/lessons/progress', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ lessonId, position: 0, isCompleted: true }),
      });
    } catch {}
    toast.success('Lesson completed! +10 XP', { icon: '⚡' });
    if (completedLessons.size + 1 === allLessons.length) {
      setShowConfetti(true);
      setTimeout(() => setShowConfetti(false), 6000);
      toast.success('🎉 Course completed! Certificate issued!', { duration: 6000 });
    }
  };

  const toggleSection = (sectionId: string) => {
    setSections((prev) => prev.map((s) =>
      s.id === sectionId ? { ...s, expanded: !s.expanded } : s
    ));
  };

  const formatDur = (seconds: number) => {
    if (!seconds) return '';
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {showConfetti && <Confetti recycle={false} numberOfPieces={300} />}

      {/* Top bar */}
      <header className="h-14 border-b bg-card flex items-center gap-4 px-4 z-40 sticky top-0">
        <Button variant="ghost" size="sm" asChild className="gap-1.5">
          <Link href="/dashboard">
            <ChevronLeft className="w-4 h-4" />
            <span className="hidden sm:inline">Dashboard</span>
          </Link>
        </Button>

        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold truncate">{course.title}</p>
          <div className="flex items-center gap-2 mt-0.5">
            <div className="w-24 h-1 bg-secondary rounded-full overflow-hidden">
              <div className="h-full bg-primary rounded-full" style={{ width: `${progress}%` }} />
            </div>
            <span className="text-[10px] text-muted-foreground">{progress}% complete</span>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <Button
            variant="ghost"
            size="sm"
            className={cn('gap-1.5', completedLessons.has(currentLesson?.id) && 'text-primary')}
            onClick={() => markComplete(currentLesson?.id)}
            disabled={completedLessons.has(currentLesson?.id)}
          >
            <CheckCircle2 className="w-4 h-4" />
            <span className="hidden sm:inline">
              {completedLessons.has(currentLesson?.id) ? 'Completed' : 'Mark complete'}
            </span>
          </Button>
          <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setSidebarOpen(!sidebarOpen)}>
            {sidebarOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          </Button>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Main content */}
        <main className={cn('flex-1 overflow-y-auto transition-all', sidebarOpen ? 'lg:mr-80' : '')}>
          <div className="max-w-4xl mx-auto px-4 py-6">
            {/* Lesson content */}
            {currentLesson?.type === 'VIDEO' && currentLesson.videoUrl && (
              <div className="mb-6">
                <VideoPlayer
                  videoUrl={currentLesson.videoUrl}
                  title={currentLesson.title}
                  lessonId={currentLesson.id}
                  onComplete={() => markComplete(currentLesson.id)}
                />
              </div>
            )}

            {currentLesson?.type === 'READING' && (
              <div className="mb-6 bg-card border rounded-xl p-8 prose prose-sm max-w-none dark:prose-invert"
                dangerouslySetInnerHTML={{ __html: currentLesson.content || '<p>Reading material coming soon.</p>' }}
              />
            )}

            {currentLesson?.type === 'QUIZ' && (
              <div className="mb-6">
                <Quiz
                  quizId={MOCK_QUIZ.id}
                  title={MOCK_QUIZ.title}
                  questions={MOCK_QUIZ.questions}
                  timeLimit={MOCK_QUIZ.timeLimit}
                  passingScore={MOCK_QUIZ.passingScore}
                  maxAttempts={MOCK_QUIZ.maxAttempts}
                  attemptNumber={MOCK_QUIZ.attemptNumber}
                  onComplete={(score, passed) => {
                    if (passed) markComplete(currentLesson.id);
                  }}
                />
              </div>
            )}

            {currentLesson?.type === 'ASSIGNMENT' && (
              <div className="mb-6 bg-card border rounded-xl p-6">
                <h2 className="text-xl font-display font-bold mb-2">Assignment</h2>
                <p className="text-muted-foreground text-sm mb-4">
                  Complete the assignment below and submit your work for grading.
                </p>
                <div className="space-y-4">
                  <div className="bg-secondary/50 rounded-lg p-4 text-sm text-muted-foreground">
                    Assignment details will appear here once loaded.
                  </div>
                  <Button onClick={() => markComplete(currentLesson.id)}>Submit Assignment</Button>
                </div>
              </div>
            )}

            {/* Lesson title & navigation */}
            <div className="bg-card border rounded-xl p-6">
              <div className="flex items-start justify-between gap-4 mb-4">
                <div>
                  <h1 className="text-xl font-display font-bold">{currentLesson?.title}</h1>
                  <div className="flex items-center gap-3 mt-1">
                    {currentLesson?.type && (
                      <Badge variant="secondary" className="text-xs gap-1">
                        {(() => {
                          const Icon = LESSON_ICONS[currentLesson.type] || Play;
                          return <Icon className={cn('w-3 h-3', LESSON_COLORS[currentLesson.type])} />;
                        })()}
                        {currentLesson.type}
                      </Badge>
                    )}
                    {currentLesson?.videoDuration && (
                      <span className="text-xs text-muted-foreground">
                        {formatDur(currentLesson.videoDuration)}
                      </span>
                    )}
                  </div>
                </div>
                {completedLessons.has(currentLesson?.id) && (
                  <div className="flex items-center gap-1.5 text-primary text-xs font-medium shrink-0">
                    <CheckCircle2 className="w-4 h-4" />
                    Completed
                  </div>
                )}
              </div>

              {/* Prev / Next */}
              <div className="flex items-center justify-between pt-4 border-t">
                <Button
                  variant="outline"
                  size="sm"
                  disabled={!prevLesson}
                  onClick={() => prevLesson && setCurrentLessonId(prevLesson.id)}
                  className="gap-1.5"
                >
                  <ChevronLeft className="w-4 h-4" />
                  Previous
                </Button>
                <span className="text-xs text-muted-foreground">
                  {currentIndex + 1} / {allLessons.length}
                </span>
                <Button
                  size="sm"
                  disabled={!nextLesson}
                  onClick={() => {
                    if (!completedLessons.has(currentLesson?.id)) markComplete(currentLesson?.id);
                    if (nextLesson) setCurrentLessonId(nextLesson.id);
                  }}
                  className="gap-1.5"
                >
                  Next
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Discussion CTA */}
            <div className="mt-4 p-4 bg-secondary/30 border rounded-xl flex items-center gap-3">
              <MessageSquare className="w-5 h-5 text-primary shrink-0" />
              <div className="flex-1">
                <p className="text-sm font-medium">Have a question?</p>
                <p className="text-xs text-muted-foreground">Ask in the discussion forum below</p>
              </div>
              <Button variant="outline" size="sm" asChild>
                <Link href="#discussion">Ask Question</Link>
              </Button>
            </div>
          </div>
        </main>

        {/* Sidebar curriculum */}
        <aside className={cn(
          'fixed right-0 top-14 bottom-0 w-80 bg-card border-l z-30 flex flex-col transition-transform duration-300',
          sidebarOpen ? 'translate-x-0' : 'translate-x-full',
          'hidden lg:flex'
        )}>
          {/* Sidebar header */}
          <div className="p-4 border-b">
            <div className="flex items-center justify-between mb-2">
              <h2 className="text-sm font-semibold">Course Content</h2>
              <Button variant="ghost" size="icon" className="w-7 h-7" onClick={() => setSidebarOpen(false)}>
                <X className="w-3.5 h-3.5" />
              </Button>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex-1 h-1.5 bg-secondary rounded-full overflow-hidden">
                <div className="h-full bg-primary rounded-full" style={{ width: `${progress}%` }} />
              </div>
              <span className="text-xs text-muted-foreground whitespace-nowrap">
                {completedLessons.size}/{allLessons.length} lessons
              </span>
            </div>
          </div>

          {/* Section/lesson list */}
          <div className="flex-1 overflow-y-auto scrollbar-hide">
            {sections.map((section, si) => (
              <div key={section.id}>
                <button
                  onClick={() => toggleSection(section.id)}
                  className="w-full flex items-center gap-2 px-4 py-3 bg-secondary/30 hover:bg-secondary/50 transition-colors text-left"
                >
                  {section.expanded ? <ChevronUp className="w-3.5 h-3.5 shrink-0" /> : <ChevronDown className="w-3.5 h-3.5 shrink-0" />}
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold truncate">
                      Section {si + 1}: {section.title}
                    </p>
                    <p className="text-[10px] text-muted-foreground">
                      {section.lessons.filter((l) => completedLessons.has(l.id)).length}/{section.lessons.length} complete
                    </p>
                  </div>
                </button>

                {section.expanded && (
                  <div>
                    {section.lessons.map((lesson, li) => {
                      const Icon = LESSON_ICONS[lesson.type] || Play;
                      const isActive = lesson.id === currentLessonId;
                      const isDone = completedLessons.has(lesson.id);

                      return (
                        <button
                          key={lesson.id}
                          onClick={() => setCurrentLessonId(lesson.id)}
                          className={cn(
                            'w-full flex items-start gap-3 px-4 py-3 text-left transition-colors border-l-2',
                            isActive
                              ? 'border-primary bg-primary/5'
                              : 'border-transparent hover:bg-secondary/30'
                          )}
                        >
                          {/* Status icon */}
                          <div className="mt-0.5 shrink-0">
                            {isDone ? (
                              <CheckCircle2 className="w-4 h-4 text-primary" />
                            ) : isActive ? (
                              <div className="w-4 h-4 rounded-full border-2 border-primary flex items-center justify-center">
                                <div className="w-1.5 h-1.5 bg-primary rounded-full" />
                              </div>
                            ) : (
                              <Circle className="w-4 h-4 text-muted-foreground/40" />
                            )}
                          </div>

                          <div className="flex-1 min-w-0">
                            <p className={cn(
                              'text-xs font-medium leading-relaxed line-clamp-2',
                              isActive ? 'text-primary' : isDone ? 'text-muted-foreground' : 'text-foreground'
                            )}>
                              {lesson.title}
                            </p>
                            <div className="flex items-center gap-1.5 mt-1">
                              <Icon className={cn('w-3 h-3', LESSON_COLORS[lesson.type])} />
                              <span className="text-[10px] text-muted-foreground">
                                {lesson.type.charAt(0) + lesson.type.slice(1).toLowerCase()}
                                {lesson.videoDuration ? ` · ${formatDur(lesson.videoDuration)}` : ''}
                              </span>
                            </div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Certificate button */}
          {progress === 100 && (
            <div className="p-4 border-t">
              <Button className="w-full gap-2" asChild>
                <Link href="/dashboard/certificates">
                  <GraduationCap className="w-4 h-4" />
                  View Certificate
                </Link>
              </Button>
            </div>
          )}
        </aside>
      </div>
    </div>
  );
}
