'use client';

import { useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { Navbar } from '@/components/layout/Navbar';
import { Footer } from '@/components/layout/Footer';
import {
  Video, Calendar, Clock, Users, Wifi, Bell, Play,
  ChevronRight, Search, Filter, ArrowRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';
import { format, formatDistanceToNow, addDays, addHours } from 'date-fns';

const MOCK_LIVE = [
  {
    id: '1', status: 'LIVE', title: 'Advanced TypeScript Patterns & Generics',
    description: 'Deep dive into complex TypeScript patterns used in production codebases.',
    instructor: { name: 'Chris Lee', initials: 'CL', rating: 4.9 },
    course: 'TypeScript: The Complete Guide',
    scheduledAt: new Date(),
    duration: 90, participants: 243, maxParticipants: 500,
    thumbnail: 'https://images.unsplash.com/photo-1627398242454-45a1465c2479?w=400&h=225&fit=crop',
    zoomJoinUrl: 'https://zoom.us/j/example',
    isRegistered: true,
  },
  {
    id: '2', status: 'SCHEDULED', title: 'Building a SaaS with Next.js 14 & Stripe',
    description: 'Live coding session: Build a complete SaaS product from scratch with authentication, payments, and dashboard.',
    instructor: { name: 'Andrew Mead', initials: 'AM', rating: 4.8 },
    course: 'Full-Stack Next.js 14',
    scheduledAt: addHours(new Date(), 3),
    duration: 120, participants: 412, maxParticipants: 600,
    thumbnail: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=400&h=225&fit=crop',
    zoomJoinUrl: 'https://zoom.us/j/example2',
    isRegistered: false,
  },
  {
    id: '3', status: 'SCHEDULED', title: 'Machine Learning Model Deployment with AWS SageMaker',
    description: 'Learn how to deploy ML models at scale using AWS SageMaker and monitoring best practices.',
    instructor: { name: 'Dr. Sarah Johnson', initials: 'SJ', rating: 4.9 },
    course: 'Machine Learning A-Z',
    scheduledAt: addDays(new Date(), 1),
    duration: 90, participants: 287, maxParticipants: 400,
    thumbnail: 'https://images.unsplash.com/photo-1509228468518-180b8ef8ade0?w=400&h=225&fit=crop',
    zoomJoinUrl: '',
    isRegistered: true,
  },
  {
    id: '4', status: 'SCHEDULED', title: 'Docker Compose & Microservices Architecture',
    description: 'Hands-on session building a microservices application with Docker Compose and Nginx.',
    instructor: { name: 'Alex Kumar', initials: 'AK', rating: 4.7 },
    course: 'Docker & Kubernetes',
    scheduledAt: addDays(new Date(), 2),
    duration: 75, participants: 198, maxParticipants: 300,
    thumbnail: 'https://images.unsplash.com/photo-1605745341112-85968b19335b?w=400&h=225&fit=crop',
    zoomJoinUrl: '',
    isRegistered: false,
  },
  {
    id: '5', status: 'ENDED', title: 'React Performance Optimization Deep Dive',
    description: 'Recorded session covering React.memo, virtualization, code splitting, and profiling.',
    instructor: { name: 'Emma Wilson', initials: 'EW', rating: 4.8 },
    course: 'Complete React Developer',
    scheduledAt: addDays(new Date(), -1),
    duration: 90, participants: 521, maxParticipants: 500,
    thumbnail: 'https://images.unsplash.com/photo-1558655146-9f40138edfeb?w=400&h=225&fit=crop',
    recordingUrl: 'https://example.com/recording',
    zoomJoinUrl: '',
    isRegistered: true,
  },
];

export default function LiveClassesPage() {
  const [search, setSearch] = useState('');
  const [registered, setRegistered] = useState<Set<string>>(new Set(['1', '3', '5']));

  const live = MOCK_LIVE.filter((c) => c.status === 'LIVE');
  const upcoming = MOCK_LIVE.filter((c) => c.status === 'SCHEDULED' && c.title.toLowerCase().includes(search.toLowerCase()));
  const past = MOCK_LIVE.filter((c) => c.status === 'ENDED');

  const toggleRegister = (id: string) => {
    setRegistered((prev) => {
      const n = new Set(prev);
      if (n.has(id)) {
        n.delete(id);
      } else {
        n.add(id);
      }
      return n;
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="pt-20">
        {/* Hero */}
        <section className="bg-gradient-to-b from-red-500/10 to-background py-16 border-b">
          <div className="container mx-auto px-4 max-w-6xl">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
              <span className="text-sm font-semibold text-red-500">LIVE CLASSES</span>
            </div>
            <h1 className="text-4xl font-display font-bold mb-3">Learn live with experts</h1>
            <p className="text-muted-foreground max-w-xl mb-8">
              Join real-time sessions, ask questions, and learn alongside thousands of students worldwide.
            </p>
            <div className="flex items-center gap-3 max-w-md">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search live classes..."
                  className="pl-9 h-11"
                />
              </div>
            </div>
          </div>
        </section>

        <div className="container mx-auto px-4 max-w-6xl py-10 space-y-12">
          {/* Live now */}
          {live.length > 0 && (
            <section>
              <div className="flex items-center gap-2 mb-5">
                <div className="w-2.5 h-2.5 bg-red-500 rounded-full animate-pulse" />
                <h2 className="text-xl font-display font-bold">Live Now</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {live.map((cls) => (
                  <LiveClassCard key={cls.id} cls={cls} isRegistered={registered.has(cls.id)} onToggleRegister={toggleRegister} />
                ))}
              </div>
            </section>
          )}

          {/* Upcoming */}
          <section>
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-xl font-display font-bold">Upcoming Classes</h2>
              <Button variant="ghost" size="sm" className="gap-1 text-primary">
                View calendar <ChevronRight className="w-3.5 h-3.5" />
              </Button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
              {upcoming.map((cls) => (
                <LiveClassCard key={cls.id} cls={cls} isRegistered={registered.has(cls.id)} onToggleRegister={toggleRegister} />
              ))}
            </div>
          </section>

          {/* Past / Recordings */}
          {past.length > 0 && (
            <section>
              <h2 className="text-xl font-display font-bold mb-5">Past Recordings</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {past.map((cls) => (
                  <LiveClassCard key={cls.id} cls={cls} isRegistered={registered.has(cls.id)} onToggleRegister={toggleRegister} />
                ))}
              </div>
            </section>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
}

function LiveClassCard({
  cls,
  isRegistered,
  onToggleRegister,
}: {
  cls: (typeof MOCK_LIVE)[0];
  isRegistered: boolean;
  onToggleRegister: (id: string) => void;
}) {
  const isLive = cls.status === 'LIVE';
  const isEnded = cls.status === 'ENDED';
  const fillPct = Math.round((cls.participants / cls.maxParticipants) * 100);

  return (
    <div className={cn(
      'bg-card border rounded-2xl overflow-hidden hover:border-primary/30 hover:shadow-md transition-all',
      isLive && 'border-red-500/30 ring-1 ring-red-500/10'
    )}>
      {/* Thumbnail */}
      <div className="relative aspect-video overflow-hidden bg-secondary">
        <Image src={cls.thumbnail} alt={cls.title} fill className="object-cover" />
        <div className="absolute inset-0 bg-black/30" />

        {/* Status badge */}
        <div className="absolute top-3 left-3">
          {isLive ? (
            <div className="flex items-center gap-1.5 bg-red-500 text-white text-xs font-bold px-2.5 py-1 rounded-full">
              <div className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" />
              LIVE
            </div>
          ) : isEnded ? (
            <Badge className="bg-black/60 text-white border-0">Recorded</Badge>
          ) : (
            <Badge className="bg-black/60 text-white border-0 text-xs">
              {formatDistanceToNow(cls.scheduledAt, { addSuffix: true })}
            </Badge>
          )}
        </div>

        {/* Participants */}
        <div className="absolute bottom-3 right-3 flex items-center gap-1.5 bg-black/60 text-white text-xs px-2 py-1 rounded-full">
          <Users className="w-3 h-3" />
          {cls.participants.toLocaleString()}
          {isLive && ' watching'}
        </div>
      </div>

      <div className="p-5">
        <h3 className="font-display font-bold text-sm leading-snug mb-1">{cls.title}</h3>
        <p className="text-xs text-muted-foreground line-clamp-2 mb-3">{cls.description}</p>

        <div className="flex items-center gap-3 mb-3 text-xs text-muted-foreground">
          <Avatar className="w-5 h-5">
            <AvatarFallback className="bg-primary/20 text-primary text-[10px] font-bold">
              {cls.instructor.initials}
            </AvatarFallback>
          </Avatar>
          <span>{cls.instructor.name}</span>
          <span className="flex items-center gap-1">
            <Clock className="w-3 h-3" />{cls.duration} min
          </span>
          {!isEnded && (
            <span className="flex items-center gap-1">
              <Calendar className="w-3 h-3" />{format(cls.scheduledAt, 'MMM d, h:mm a')}
            </span>
          )}
        </div>

        {/* Capacity bar */}
        {!isEnded && (
          <div className="mb-3">
            <div className="flex justify-between text-xs text-muted-foreground mb-1">
              <span>{cls.participants.toLocaleString()} registered</span>
              <span>{fillPct}% full</span>
            </div>
            <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
              <div
                className={cn('h-full rounded-full transition-all', fillPct > 80 ? 'bg-red-500' : 'bg-primary')}
                style={{ width: `${fillPct}%` }}
              />
            </div>
          </div>
        )}

        {/* CTA */}
        {isLive ? (
          <Button className="w-full gap-2 bg-red-500 hover:bg-red-600 text-white" asChild>
            <a href={cls.zoomJoinUrl} target="_blank" rel="noopener noreferrer">
              <Wifi className="w-4 h-4" />
              Join Live Now
            </a>
          </Button>
        ) : isEnded ? (
          <Button variant="outline" className="w-full gap-2" asChild>
            <a href={(cls as any).recordingUrl} target="_blank" rel="noopener noreferrer">
              <Play className="w-4 h-4" />
              Watch Recording
            </a>
          </Button>
        ) : isRegistered ? (
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="flex-1 gap-1.5" onClick={() => onToggleRegister(cls.id)}>
              <Bell className="w-3.5 h-3.5 text-primary" />
              Registered
            </Button>
            <Button size="sm" className="flex-1 gap-1.5" asChild>
              <a href={cls.zoomJoinUrl || '#'} target="_blank" rel="noopener noreferrer">
                <ArrowRight className="w-3.5 h-3.5" />
                Join Link
              </a>
            </Button>
          </div>
        ) : (
          <Button className="w-full gap-2" onClick={() => onToggleRegister(cls.id)}>
            <Bell className="w-4 h-4" />
            Register &amp; Get Notified
          </Button>
        )}
      </div>
    </div>
  );
}
