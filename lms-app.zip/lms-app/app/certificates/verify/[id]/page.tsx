import { notFound } from 'next/navigation';
import { prisma } from '@/lib/prisma';
import { format } from 'date-fns';
import { CheckCircle2, Award, ExternalLink, Shield, Calendar, Clock, BookOpen } from 'lucide-react';
import { Certificate } from '@/components/dashboard/Certificate';
import { Badge } from '@/components/ui/badge';
import Link from 'next/link';

export const metadata = {
  title: 'Certificate Verification',
};

interface Props {
  params: { id: string };
}

async function getCertificate(id: string) {
  return await prisma.certificate.findUnique({
    where: { verificationId: id },
    include: {
      user: { select: { name: true, email: true } },
      course: {
        include: {
          instructor: { include: { user: { select: { name: true } } } },
        },
      },
    },
  });
}

export default async function CertificateVerifyPage({ params }: Props) {
  const certificate = await getCertificate(params.id).catch(() => null);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 max-w-5xl h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-7 h-7 bg-primary rounded-lg flex items-center justify-center">
              <Award className="w-4 h-4 text-white" />
            </div>
            <span className="font-display font-bold">LearnForge</span>
          </Link>
          <Badge className="gap-1.5 bg-primary/10 text-primary border-0">
            <Shield className="w-3 h-3" />
            Certificate Verification
          </Badge>
        </div>
      </header>

      <main className="container mx-auto px-4 max-w-4xl py-12">
        {!certificate ? (
          /* Invalid certificate */
          <div className="text-center py-20">
            <div className="w-20 h-20 bg-destructive/10 rounded-full flex items-center justify-center mx-auto mb-6">
              <Shield className="w-10 h-10 text-destructive" />
            </div>
            <h1 className="text-2xl font-display font-bold mb-3">Certificate Not Found</h1>
            <p className="text-muted-foreground mb-6 max-w-md mx-auto">
              The certificate with ID <code className="font-mono text-sm bg-secondary px-2 py-0.5 rounded">{params.id}</code> could not be found or may have been revoked.
            </p>
            <Link href="/" className="text-primary hover:underline text-sm">
              Return to LearnForge
            </Link>
          </div>
        ) : (
          /* Valid certificate */
          <div className="space-y-8">
            {/* Verification banner */}
            <div className="flex items-center gap-4 p-4 bg-primary/10 border border-primary/20 rounded-2xl">
              <div className="w-12 h-12 bg-primary/20 rounded-xl flex items-center justify-center shrink-0">
                <CheckCircle2 className="w-6 h-6 text-primary" />
              </div>
              <div>
                <p className="font-bold text-primary">✓ Verified Certificate</p>
                <p className="text-sm text-muted-foreground">
                  This certificate is authentic and was issued by LearnForge
                </p>
              </div>
            </div>

            {/* Certificate details */}
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
              <div className="lg:col-span-3">
                <Certificate certificate={certificate as any} preview />
              </div>

              {/* Details panel */}
              <div className="lg:col-span-2 space-y-4">
                <div className="bg-card border rounded-2xl p-5">
                  <h2 className="font-display font-bold mb-4">Certificate Details</h2>
                  <dl className="space-y-3">
                    {[
                      {
                        label: 'Issued To',
                        value: certificate.user.name,
                        icon: Award,
                      },
                      {
                        label: 'Course',
                        value: certificate.course.title,
                        icon: BookOpen,
                      },
                      {
                        label: 'Instructor',
                        value: certificate.course.instructor.user.name,
                        icon: Award,
                      },
                      {
                        label: 'Issue Date',
                        value: format(new Date(certificate.issuedAt), 'MMMM d, yyyy'),
                        icon: Calendar,
                      },
                      {
                        label: 'Duration',
                        value: `${Math.round(certificate.course.durationMinutes / 60)} hours`,
                        icon: Clock,
                      },
                    ].map((item) => (
                      <div key={item.label} className="flex items-start gap-3">
                        <item.icon className="w-4 h-4 text-muted-foreground shrink-0 mt-0.5" />
                        <div>
                          <dt className="text-xs text-muted-foreground">{item.label}</dt>
                          <dd className="text-sm font-medium">{item.value}</dd>
                        </div>
                      </div>
                    ))}
                  </dl>
                </div>

                {/* Skills */}
                {certificate.skills.length > 0 && (
                  <div className="bg-card border rounded-2xl p-5">
                    <h3 className="font-semibold text-sm mb-3">Skills Verified</h3>
                    <div className="flex flex-wrap gap-2">
                      {certificate.skills.map((skill) => (
                        <span
                          key={skill}
                          className="px-2.5 py-0.5 bg-primary/10 text-primary text-xs rounded-full font-medium"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Verification ID */}
                <div className="bg-secondary/50 rounded-2xl p-4">
                  <p className="text-xs text-muted-foreground mb-1">Verification ID</p>
                  <code className="text-xs font-mono font-bold">{certificate.verificationId}</code>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
