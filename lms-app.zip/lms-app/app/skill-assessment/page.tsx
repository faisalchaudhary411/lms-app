'use client';

import { useState, useEffect } from 'react';
import { Navbar } from '@/components/layout/Navbar';
import { Footer } from '@/components/layout/Footer';
import {
  Brain, ChevronRight, Check, X, Loader2, Sparkles,
  Target, TrendingUp, BookOpen, Award, RotateCcw, ArrowRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import Link from 'next/link';

const ASSESSMENT_QUESTIONS = [
  {
    id: 'q1',
    topic: 'JavaScript',
    question: 'Which of the following best describes a closure in JavaScript?',
    options: [
      'A function that runs immediately after being defined',
      'A function that has access to variables from its outer scope even after the outer function returns',
      'A method used to close a browser window',
      'A way to end a loop early',
    ],
    correctIndex: 1,
    explanation: 'A closure is a function that "remembers" the variables from the scope in which it was created, even after that scope has finished executing.',
  },
  {
    id: 'q2',
    topic: 'React',
    question: 'When does a React component re-render?',
    options: [
      'Only when its props change',
      'Only when its state changes',
      'When its props or state change, or when its parent re-renders',
      'Only when you explicitly call render()',
    ],
    correctIndex: 2,
    explanation: 'A React component re-renders when its own state changes, when it receives new props, or when its parent component re-renders.',
  },
  {
    id: 'q3',
    topic: 'CSS',
    question: 'What does "CSS specificity" determine?',
    options: [
      'The speed at which CSS rules are applied',
      'Which CSS rule takes priority when multiple rules target the same element',
      'The order of elements in the HTML document',
      'The total file size of a CSS file',
    ],
    correctIndex: 1,
    explanation: 'CSS specificity is the weight applied to a selector that determines which rule takes precedence when multiple rules apply to the same element.',
  },
  {
    id: 'q4',
    topic: 'Algorithms',
    question: 'What is the time complexity of binary search on a sorted array?',
    options: ['O(n)', 'O(n²)', 'O(log n)', 'O(n log n)'],
    correctIndex: 2,
    explanation: 'Binary search repeatedly halves the search space, giving O(log n) complexity — far more efficient than linear search O(n) for sorted data.',
  },
  {
    id: 'q5',
    topic: 'Databases',
    question: 'What is the purpose of an index in a database?',
    options: [
      'To encrypt database columns',
      'To speed up read queries by providing faster lookup paths',
      'To backup the database automatically',
      'To enforce unique constraints only',
    ],
    correctIndex: 1,
    explanation: 'Database indexes create a separate data structure that speeds up queries by allowing the database to find rows without scanning the entire table.',
  },
];

type Phase = 'intro' | 'quiz' | 'analyzing' | 'results';

interface SkillResult {
  topic: string;
  score: number;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  color: string;
  recommendations: { title: string; slug: string }[];
}

const SKILL_RESULTS: SkillResult[] = [
  { topic: 'JavaScript', score: 85, level: 'Intermediate', color: 'text-yellow-500', recommendations: [{ title: 'Advanced JavaScript Patterns', slug: 'advanced-js' }, { title: 'TypeScript: The Complete Guide', slug: 'typescript-complete' }] },
  { topic: 'React', score: 60, level: 'Beginner', color: 'text-blue-500', recommendations: [{ title: 'The Complete React Developer', slug: 'complete-react-developer' }, { title: 'React Hooks Deep Dive', slug: 'react-hooks' }] },
  { topic: 'CSS', score: 90, level: 'Advanced', color: 'text-primary', recommendations: [{ title: 'Advanced CSS Animations', slug: 'css-animations' }] },
  { topic: 'Algorithms', score: 40, level: 'Beginner', color: 'text-red-500', recommendations: [{ title: 'JavaScript Algorithms & DS', slug: 'js-algorithms' }, { title: 'CS50: Computer Science', slug: 'cs50' }] },
  { topic: 'Databases', score: 70, level: 'Intermediate', color: 'text-violet-500', recommendations: [{ title: 'SQL Mastery Course', slug: 'sql-mastery' }] },
];

export default function SkillAssessmentPage() {
  const [phase, setPhase] = useState<Phase>('intro');
  const [currentQ, setCurrentQ] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [selected, setSelected] = useState<number | null>(null);
  const [showAnswer, setShowAnswer] = useState(false);

  const question = ASSESSMENT_QUESTIONS[currentQ];
  const isCorrect = selected === question?.correctIndex;

  const handleSelect = (i: number) => {
    if (showAnswer) return;
    setSelected(i);
    setShowAnswer(true);
    setAnswers((prev) => [...prev, i]);
  };

  const handleNext = () => {
    setSelected(null);
    setShowAnswer(false);
    if (currentQ + 1 < ASSESSMENT_QUESTIONS.length) {
      setCurrentQ((q) => q + 1);
    } else {
      setPhase('analyzing');
      setTimeout(() => setPhase('results'), 2800);
    }
  };

  const restart = () => {
    setPhase('intro');
    setCurrentQ(0);
    setAnswers([]);
    setSelected(null);
    setShowAnswer(false);
  };

  const score = answers.filter((a, i) => a === ASSESSMENT_QUESTIONS[i]?.correctIndex).length;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="pt-20 pb-20">
        <div className="container mx-auto px-4 max-w-3xl py-12">

          {/* INTRO */}
          {phase === 'intro' && (
            <div className="text-center space-y-8 animate-fade-up">
              <div className="w-20 h-20 bg-primary/10 rounded-3xl flex items-center justify-center mx-auto">
                <Brain className="w-10 h-10 text-primary" />
              </div>
              <div>
                <h1 className="text-4xl font-display font-bold mb-3">Skill Assessment</h1>
                <p className="text-muted-foreground text-lg max-w-lg mx-auto">
                  Answer 5 questions across key topics. We&apos;ll identify your skill gaps and recommend the perfect courses.
                </p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-xl mx-auto">
                {[{ icon: Target, text: '5 adaptive questions', color: 'bg-primary/10 text-primary' }, { icon: Brain, text: 'AI-powered analysis', color: 'bg-violet-500/10 text-violet-500' }, { icon: BookOpen, text: 'Personalized path', color: 'bg-blue-500/10 text-blue-500' }].map((item) => (
                  <div key={item.text} className="bg-card border rounded-xl p-4 text-center">
                    <div className={cn('w-9 h-9 rounded-lg flex items-center justify-center mx-auto mb-2', item.color)}>
                      <item.icon className="w-4 h-4" />
                    </div>
                    <p className="text-sm font-medium">{item.text}</p>
                  </div>
                ))}
              </div>
              <Button size="lg" onClick={() => setPhase('quiz')} className="gap-2 text-base h-12 px-8">
                Start Assessment <ChevronRight className="w-5 h-5" />
              </Button>
            </div>
          )}

          {/* QUIZ */}
          {phase === 'quiz' && question && (
            <div className="animate-fade-up">
              {/* Progress */}
              <div className="flex items-center gap-3 mb-8">
                <div className="flex-1 h-2 bg-secondary rounded-full overflow-hidden">
                  <div className="h-full bg-primary rounded-full transition-all duration-500" style={{ width: `${((currentQ) / ASSESSMENT_QUESTIONS.length) * 100}%` }} />
                </div>
                <span className="text-sm text-muted-foreground shrink-0">{currentQ + 1}/{ASSESSMENT_QUESTIONS.length}</span>
              </div>

              {/* Topic badge */}
              <Badge className="mb-4 bg-primary/10 text-primary border-0">{question.topic}</Badge>

              {/* Question */}
              <h2 className="text-xl font-display font-bold mb-6 leading-snug">{question.question}</h2>

              {/* Options */}
              <div className="space-y-3 mb-6">
                {question.options.map((opt, i) => {
                  let cls = 'border-border hover:border-primary/40 hover:bg-secondary/50';
                  if (showAnswer) {
                    if (i === question.correctIndex) cls = 'border-primary bg-primary/10 text-primary';
                    else if (i === selected) cls = 'border-destructive bg-destructive/10 text-destructive';
                    else cls = 'border-border opacity-50';
                  } else if (selected === i) {
                    cls = 'border-primary bg-primary/10';
                  }
                  return (
                    <button
                      key={i}
                      onClick={() => handleSelect(i)}
                      disabled={showAnswer}
                      className={cn('w-full flex items-center gap-4 p-4 rounded-xl border text-left transition-all duration-150', cls)}
                    >
                      <div className={cn('w-7 h-7 rounded-full border-2 flex items-center justify-center text-xs font-bold shrink-0 transition-all',
                        showAnswer && i === question.correctIndex ? 'border-primary bg-primary text-white' :
                        showAnswer && i === selected && i !== question.correctIndex ? 'border-destructive bg-destructive text-white' :
                        'border-current'
                      )}>
                        {showAnswer && i === question.correctIndex ? <Check className="w-4 h-4" /> :
                         showAnswer && i === selected ? <X className="w-4 h-4" /> :
                         String.fromCharCode(65 + i)}
                      </div>
                      <span className="text-sm">{opt}</span>
                    </button>
                  );
                })}
              </div>

              {/* Explanation */}
              {showAnswer && (
                <div className={cn('p-4 rounded-xl mb-6 text-sm leading-relaxed', isCorrect ? 'bg-primary/10 border border-primary/20' : 'bg-destructive/10 border border-destructive/20')}>
                  <p className={cn('font-semibold mb-1', isCorrect ? 'text-primary' : 'text-destructive')}>
                    {isCorrect ? '✓ Correct!' : '✗ Not quite'}
                  </p>
                  <p className="text-muted-foreground">{question.explanation}</p>
                </div>
              )}

              {showAnswer && (
                <Button onClick={handleNext} className="w-full h-11 gap-2">
                  {currentQ + 1 < ASSESSMENT_QUESTIONS.length ? 'Next Question' : 'See My Results'}
                  <ChevronRight className="w-4 h-4" />
                </Button>
              )}
            </div>
          )}

          {/* ANALYZING */}
          {phase === 'analyzing' && (
            <div className="text-center py-20 space-y-6 animate-fade-up">
              <div className="w-20 h-20 bg-primary/10 rounded-3xl flex items-center justify-center mx-auto">
                <Sparkles className="w-10 h-10 text-primary animate-pulse" />
              </div>
              <h2 className="text-2xl font-display font-bold">Analysing your results…</h2>
              <p className="text-muted-foreground">Our AI is mapping your skill level and preparing personalised recommendations</p>
              <div className="flex justify-center gap-2 pt-4">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: `${i * 150}ms` }} />
                ))}
              </div>
            </div>
          )}

          {/* RESULTS */}
          {phase === 'results' && (
            <div className="space-y-8 animate-fade-up">
              {/* Score header */}
              <div className="text-center">
                <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-3xl font-display font-bold text-primary">{Math.round((score / ASSESSMENT_QUESTIONS.length) * 100)}%</span>
                </div>
                <h2 className="text-2xl font-display font-bold mb-2">Your Skill Profile</h2>
                <p className="text-muted-foreground">
                  You got {score}/{ASSESSMENT_QUESTIONS.length} correct. Here&apos;s what we found:
                </p>
              </div>

              {/* Skill breakdown */}
              <div className="bg-card border rounded-2xl p-6">
                <h3 className="font-display font-bold mb-5">Skill Breakdown</h3>
                <div className="space-y-4">
                  {SKILL_RESULTS.map((skill) => (
                    <div key={skill.topic}>
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="text-sm font-medium">{skill.topic}</span>
                        <div className="flex items-center gap-2">
                          <Badge className={cn('text-[10px] border-0',
                            skill.level === 'Advanced' ? 'bg-primary/10 text-primary' :
                            skill.level === 'Intermediate' ? 'bg-blue-500/10 text-blue-500' :
                            'bg-red-500/10 text-red-500'
                          )}>
                            {skill.level}
                          </Badge>
                          <span className={cn('text-sm font-bold', skill.color)}>{skill.score}%</span>
                        </div>
                      </div>
                      <div className="h-2 bg-secondary rounded-full overflow-hidden">
                        <div
                          className={cn('h-full rounded-full transition-all duration-1000',
                            skill.score >= 80 ? 'bg-primary' : skill.score >= 60 ? 'bg-blue-500' : 'bg-red-500'
                          )}
                          style={{ width: `${skill.score}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recommendations */}
              <div className="bg-card border rounded-2xl p-6">
                <div className="flex items-center gap-2 mb-5">
                  <Sparkles className="w-4 h-4 text-primary" />
                  <h3 className="font-display font-bold">Recommended for You</h3>
                </div>
                <div className="space-y-3">
                  {SKILL_RESULTS.filter((s) => s.level !== 'Advanced').flatMap((s) => s.recommendations).slice(0, 4).map((rec) => (
                    <Link key={rec.slug} href={`/courses/${rec.slug}`}
                      className="flex items-center gap-3 p-3 rounded-xl border hover:border-primary/30 hover:bg-secondary/30 transition-all group">
                      <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center shrink-0">
                        <BookOpen className="w-4 h-4 text-primary" />
                      </div>
                      <span className="text-sm font-medium flex-1 group-hover:text-primary transition-colors">{rec.title}</span>
                      <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
                    </Link>
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-3">
                <Button variant="outline" className="flex-1 gap-2" onClick={restart}>
                  <RotateCcw className="w-4 h-4" />Retake
                </Button>
                <Button className="flex-1 gap-2" asChild>
                  <Link href="/learning-paths">
                    <TrendingUp className="w-4 h-4" />Explore Learning Paths
                  </Link>
                </Button>
              </div>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
}
